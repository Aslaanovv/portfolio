import fs from "fs";
import path from "path";
import { randomBytes } from "crypto";
import { fileURLToPath } from "url";
import type { DB } from "./types.js";
import { buildSeed } from "./seed.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, "..", "data");
const DB_FILE = path.join(DATA_DIR, "db.json");
const SECRET_FILE = path.join(DATA_DIR, ".secret");

export let db: DB;

export function loadDb(): DB {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (fs.existsSync(DB_FILE)) {
    try {
      db = JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));
      return db;
    } catch {
      // corrupted file → reseed
    }
  }
  db = buildSeed();
  saveDb();
  return db;
}

let saveTimer: NodeJS.Timeout | null = null;
export function saveDb() {
  if (saveTimer) return; // debounced
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      const tmp = DB_FILE + ".tmp";
      fs.writeFileSync(tmp, JSON.stringify(db, null, 1));
      fs.renameSync(tmp, DB_FILE);
    } catch (e) {
      console.error("[db] save failed", e);
    }
  }, 120);
}

export function resetDb() {
  db = buildSeed();
  try {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  } catch {}
  saveDb();
  return db;
}

export function getSecret(): string {
  if (fs.existsSync(SECRET_FILE)) return fs.readFileSync(SECRET_FILE, "utf-8").trim();
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  const s = randomBytes(32).toString("hex");
  fs.writeFileSync(SECRET_FILE, s);
  return s;
}
