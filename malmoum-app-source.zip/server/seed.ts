import bcrypt from "bcryptjs";
import type { DB, ServiceDef, Profession } from "./types.js";

// ─── Service catalog (per profession) ──────────────────────────────────────
export const SERVICES: ServiceDef[] = [
  // Plumbing
  { key: "fix-leak", profession: "plumbing", en: "Fix a leak", ar: "إصلاح تسريب", from: 250, to: 600, minutes: 60 },
  { key: "install-faucet", profession: "plumbing", en: "Install faucet / sink", ar: "تركيب حنفية / مغسلة", from: 200, to: 450, minutes: 45 },
  { key: "unclog-drain", profession: "plumbing", en: "Unclog drain", ar: "فتح مجاري مسدودة", from: 180, to: 400, minutes: 40 },
  { key: "water-heater", profession: "plumbing", en: "Water heater repair", ar: "إصلاح سخان مياه", from: 300, to: 800, minutes: 75 },
  // Electrical
  { key: "outlet-install", profession: "electrical", en: "Outlet installation", ar: "تركيب بريزة", from: 150, to: 350, minutes: 30 },
  { key: "light-fixture", profession: "electrical", en: "Light fixture install", ar: "تركيب وحدة إضاءة", from: 180, to: 400, minutes: 45 },
  { key: "wiring-fix", profession: "electrical", en: "Wiring fix", ar: "إصلاح تمديدات كهربائية", from: 250, to: 700, minutes: 70 },
  { key: "breaker-panel", profession: "electrical", en: "Breaker panel service", ar: "صيانة لوحة الكهرباء", from: 300, to: 750, minutes: 60 },
  // Carpentry
  { key: "door-repair", profession: "carpentry", en: "Door repair", ar: "إصلاح باب", from: 200, to: 500, minutes: 60 },
  { key: "furniture-assembly", profession: "carpentry", en: "Furniture assembly", ar: "تجميع أثاث", from: 150, to: 400, minutes: 50 },
  { key: "kitchen-cabinet", profession: "carpentry", en: "Cabinet installation", ar: "تركيب مطبخ", from: 400, to: 1200, minutes: 120 },
  { key: "shelf-mounting", profession: "carpentry", en: "Shelf mounting", ar: "تركيب رفوف", from: 120, to: 300, minutes: 35 },
  // AC
  { key: "ac-service", profession: "ac", en: "AC service & clean", ar: "صيانة وتنظيف تكييف", from: 300, to: 500, minutes: 60 },
  { key: "ac-gas-refill", profession: "ac", en: "AC gas refill", ar: "تعبيئة فريون", from: 600, to: 1400, minutes: 75 },
  { key: "ac-install", profession: "ac", en: "Install AC unit", ar: "تركيب تكييف", from: 800, to: 1600, minutes: 120 },
  { key: "ac-repair", profession: "ac", en: "AC not cooling — repair", ar: "إصلاح تكييف لا يبرد", from: 350, to: 900, minutes: 80 },
  // Painting
  { key: "room-painting", profession: "painting", en: "Room painting", ar: "دهان غرفة", from: 1200, to: 3500, minutes: 300 },
  { key: "wall-touchup", profession: "painting", en: "Wall touch-up", ar: "إصلاح ودهان جزئي", from: 250, to: 700, minutes: 90 },
  { key: "putty-polish", profession: "painting", en: "Putty & polishing", ar: "معجون ومحارة", from: 500, to: 1500, minutes: 180 },
  // Appliances
  { key: "washer-repair", profession: "appliance", en: "Washing machine repair", ar: "إصلاح غسالة", from: 300, to: 800, minutes: 70 },
  { key: "fridge-repair", profession: "appliance", en: "Fridge repair", ar: "إصلاح ثلاجة", from: 350, to: 950, minutes: 80 },
  { key: "dishwasher-install", profession: "appliance", en: "Dishwasher installation", ar: "تركيب غسالة أطباق", from: 400, to: 900, minutes: 90 },
];

// ─── Districts (stylized Cairo map) ────────────────────────────────────────
export const DISTRICTS = [
  { id: "nasr", en: "Nasr City", ar: "مدينة نصر", x: 52, y: 36 },
  { id: "heliopolis", en: "Heliopolis", ar: "مصر الجديدة", x: 66, y: 16 },
  { id: "downtown", en: "Downtown", ar: "وسط البلد", x: 36, y: 60 },
  { id: "zamalek", en: "Zamalek", ar: "الزمالك", x: 29, y: 50 },
  { id: "maadi", en: "Maadi", ar: "المعادي", x: 49, y: 86 },
  { id: "mohandessin", en: "Mohandessin", ar: "المهندسين", x: 17, y: 44 },
  { id: "dokki", en: "Dokki", ar: "الدقي", x: 21, y: 58 },
];

export const PROFESSIONS: { id: Profession; en: string; ar: string; icon: string }[] = [
  { id: "plumbing", en: "Plumbing", ar: "سباكة", icon: "wrench" },
  { id: "electrical", en: "Electrical", ar: "كهرباء", icon: "zap" },
  { id: "carpentry", en: "Carpentry", ar: "نجارة", icon: "hammer" },
  { id: "ac", en: "A/C", ar: "تكييف", icon: "wind" },
  { id: "painting", en: "Painting", ar: "دهانات", icon: "paint-roller" },
  { id: "appliance", en: "Appliances", ar: "أجهزة منزلية", icon: "washing-machine" },
];

// ─── Seed builder ──────────────────────────────────────────────────────────
export function buildSeed(): DB {
  const now = Date.now();
  const hash = (p: string) => bcrypt.hashSync(p, 8);

  const users: DB["users"] = [
    // Demo homeowner
    {
      id: "u-home",
      name: "Nour Hassan",
      nameAr: "نور حسن",
      phone: "+20 100 111 2233",
      email: "homeowner@malmoum.app",
      passwordHash: hash("123456"),
      role: "homeowner",
      avatarColor: "#675FFF",
      language: "en",
      district: "nasr",
      address: "12 Abbas El Akkad St., Nasr City, Cairo",
      createdAt: now - 86400000 * 30,
    },
    // Demo technician (Ahmed — plumber) — the paired demo account
    {
      id: "u-tech1",
      name: "Ahmed Samir",
      nameAr: "أحمد سمير",
      phone: "+20 100 555 1010",
      email: "technician@malmoum.app",
      passwordHash: hash("123456"),
      role: "technician",
      avatar: "/img/techs/ahmed.jpg",
      avatarColor: "#5C57F2",
      language: "en",
      district: "nasr",
      createdAt: now - 86400000 * 200,
    },
    // Other technicians
    {
      id: "u-tech2", name: "Mahmoud Fathy", nameAr: "محمود فتحي", phone: "+20 100 555 2020",
      email: "mahmoud@malmoum.app", passwordHash: hash("123456"), role: "technician",
      avatar: "/img/techs/mahmoud.jpg", avatarColor: "#362D73", language: "ar", district: "nasr", createdAt: now - 86400000 * 400,
    },
    {
      id: "u-tech3", name: "Mostafa Kamel", nameAr: "مصطفى كامل", phone: "+20 100 555 3030",
      email: "mostafa@malmoum.app", passwordHash: hash("123456"), role: "technician",
      avatar: "/img/techs/mostafa.jpg", avatarColor: "#F2AD94", language: "ar", district: "heliopolis", createdAt: now - 86400000 * 350,
    },
    {
      id: "u-tech4", name: "Youssef Adel", nameAr: "يوسف عادل", phone: "+20 100 555 4040",
      email: "youssef@malmoum.app", passwordHash: hash("123456"), role: "technician",
      avatar: "/img/techs/youssef.jpg", avatarColor: "#141C26", language: "en", district: "downtown", createdAt: now - 86400000 * 150,
    },
    {
      id: "u-tech5", name: "Karim Hassan", nameAr: "كريم حسن", phone: "+20 100 555 5050",
      email: "karim@malmoum.app", passwordHash: hash("123456"), role: "technician",
      avatar: "/img/techs/karim.jpg", avatarColor: "#F29999", language: "ar", district: "mohandessin", createdAt: now - 86400000 * 260,
    },
    {
      id: "u-tech6", name: "Hassan Ibrahim", nameAr: "حسن إبراهيم", phone: "+20 100 555 6060",
      email: "hassan@malmoum.app", passwordHash: hash("123456"), role: "technician",
      avatar: "/img/techs/hassan.jpg", avatarColor: "#675FFF", language: "ar", district: "heliopolis", createdAt: now - 86400000 * 500,
    },
  ];

  const technicians: DB["technicians"] = [
    {
      userId: "u-tech1", professions: ["plumbing"],
      bio: "Licensed plumber, 10+ years fixing leaks, heaters and full bathroom plumbing across Nasr City. I bring my own parts van.",
      bioAr: "سباك مرخص، أكثر من ١٠ سنين خبرة في إصلاح التسريبات والسخانات وتمديدات الحمامات في مدينة نصر. بيجيب قطع الغيار معاه.",
      rating: 4.8, ratingCount: 230, experienceYears: 10, visitFee: 100, etaMin: 25,
      completedJobs: 412, verified: true, available: true, mapPos: { x: 46, y: 33 },
    },
    {
      userId: "u-tech2", professions: ["electrical", "appliance"],
      bio: "Electrician & appliance doctor. Breaker panels, wiring, washers and fridges. Same-day service guarantee.",
      bioAr: "فني كهرباء وأجهزة منزلية. لوحات كهرباء وتمديدات وغسالات وثلاجات. خدمة في نفس اليوم.",
      rating: 4.6, ratingCount: 184, experienceYears: 14, visitFee: 80, etaMin: 30,
      completedJobs: 356, verified: true, available: true, mapPos: { x: 58, y: 43 },
    },
    {
      userId: "u-tech3", professions: ["carpentry"],
      bio: "Carpenter specializing in kitchens, doors and custom furniture. Precision work, clean finish.",
      bioAr: "نجار متخصص في المطابخ والأبواب والأثاث حسب الطلب. شغل دقيق وتشطيب نضيف.",
      rating: 4.9, ratingCount: 96, experienceYears: 12, visitFee: 80, etaMin: 40,
      completedJobs: 187, verified: true, available: true, mapPos: { x: 70, y: 28 },
    },
    {
      userId: "u-tech4", professions: ["ac", "appliance"],
      bio: "Certified AC technician — install, gas refill, seasonal service. All brands, warranty on work.",
      bioAr: "فني تكييف معتمد — تركيب وتعبئة فريون وصيانة موسمية. كل الماركات وضمان على الشغل.",
      rating: 4.7, ratingCount: 142, experienceYears: 8, visitFee: 100, etaMin: 35,
      completedJobs: 243, verified: true, available: true, mapPos: { x: 37, y: 55 },
    },
    {
      userId: "u-tech5", professions: ["painting"],
      bio: "Painter & finishing pro. Rooms, façades, putty and polish. Drop cloths and zero mess guaranteed.",
      bioAr: "دهان و تشطيبات. غرف وواجهات ومعجون ومحارة. بنغطي الأثاث ومفيش وساخة.",
      rating: 4.5, ratingCount: 78, experienceYears: 9, visitFee: 60, etaMin: 45,
      completedJobs: 121, verified: false, available: true, mapPos: { x: 21, y: 46 },
    },
    {
      userId: "u-tech6", professions: ["plumbing", "electrical"],
      bio: "Master plumber-electrician, 25 years on the job. The one call that fixes everything older buildings need.",
      bioAr: "سباك وكهربائي محترف، ٢٥ سنة خبرة. مكالمة واحدة تصلح كل احتياجات المباني القديمة.",
      rating: 4.9, ratingCount: 310, experienceYears: 25, visitFee: 120, etaMin: 30,
      completedJobs: 671, verified: true, available: true, mapPos: { x: 63, y: 21 },
    },
  ];

  const stores: DB["stores"] = [
    {
      id: "st-toptools", name: "TopTools Store", nameAr: "توب تولز",
      category: "tools", logoColor: "#F97316", logoText: "TT",
      rating: 4.6, ratingCount: 120, etaMin: 25, deliveryFee: 30, district: "nasr", mapPos: { x: 55, y: 49 },
    },
    {
      id: "st-elamir", name: "El-Amir Plumbing Supplies", nameAr: "الأمير لتجهيزات السباكة",
      category: "plumbing", logoColor: "#5C57F2", logoText: "AM",
      rating: 4.4, ratingCount: 86, etaMin: 20, deliveryFee: 25, district: "nasr", mapPos: { x: 44, y: 27 },
    },
    {
      id: "st-colorland", name: "ColorLand Paints", nameAr: "كلور لاند للدهانات",
      category: "paint", logoColor: "#F29999", logoText: "CL",
      rating: 4.7, ratingCount: 210, etaMin: 35, deliveryFee: 40, district: "heliopolis", mapPos: { x: 28, y: 38 },
    },
    {
      id: "st-electrohub", name: "ElectroHub", nameAr: "إلكترو هَب",
      category: "electrical", logoColor: "#362D73", logoText: "EH",
      rating: 4.5, ratingCount: 154, etaMin: 30, deliveryFee: 30, district: "downtown", mapPos: { x: 66, y: 46 },
    },
  ];

  const products: DB["products"] = [
    // TopTools
    { id: "p1", storeId: "st-toptools", name: "Bosch Drill Machine", nameAr: "دريل بوش", price: 1100, category: "tools", image: "/img/products/drill.jpg", rating: 4.8, ratingCount: 96, inStock: true },
    { id: "p2", storeId: "st-toptools", name: "Toolbox Set 108 pcs", nameAr: "طقم عدة ١٠٨ قطعة", price: 850, category: "tools", image: "/img/products/toolbox.jpg", rating: 4.6, ratingCount: 54, inStock: true },
    { id: "p3", storeId: "st-toptools", name: "LED Bulb Pack (3)", nameAr: "لمبات ليد (٣)", price: 135, category: "electrical", icon: "lightbulb", tint: "#F2AD94", rating: 4.5, ratingCount: 210, inStock: true },
    { id: "p4", storeId: "st-toptools", name: "Multimeter", nameAr: "أفوميتر", price: 380, category: "tools", icon: "activity", tint: "#A9A1FF", rating: 4.4, ratingCount: 33, inStock: true },
    // El-Amir
    { id: "p5", storeId: "st-elamir", name: "Chrome Sink Faucet", nameAr: "حنفية مغسلة كروم", price: 450, category: "plumbing", image: "/img/products/faucet.jpg", rating: 4.5, ratingCount: 61, inStock: true },
    { id: "p6", storeId: "st-elamir", name: "Copper Pipes (1m)", nameAr: "مواسير نحاس (متر)", price: 120, category: "plumbing", icon: "git-branch", tint: "#F29999", rating: 4.6, ratingCount: 88, inStock: true },
    { id: "p7", storeId: "st-elamir", name: "Flexible Hose 60cm", nameAr: "خرطوم مرن ٦٠ سم", price: 65, category: "plumbing", icon: "cable", tint: "#A9A1FF", rating: 4.3, ratingCount: 40, inStock: true },
    { id: "p8", storeId: "st-elamir", name: "Pipe Wrench 14\"", nameAr: "مفتاح مواسير ١٤", price: 220, category: "plumbing", icon: "wrench", tint: "#F2AD94", rating: 4.7, ratingCount: 52, inStock: true },
    // ColorLand
    { id: "p9", storeId: "st-colorland", name: "Interior Paint 25kg", nameAr: "دهان داخلي ٢٥ كجم", price: 700, category: "paint", image: "/img/products/paint.jpg", rating: 4.8, ratingCount: 132, inStock: true },
    { id: "p10", storeId: "st-colorland", name: "Roller & Tray Set", nameAr: "طقم رولة وصينية", price: 160, category: "paint", icon: "paint-roller", tint: "#A9A1FF", rating: 4.4, ratingCount: 47, inStock: true },
    { id: "p11", storeId: "st-colorland", name: "Wall Putty 5kg", nameAr: "معجون حوائط ٥ كجم", price: 190, category: "paint", icon: "layers", tint: "#F2AD94", rating: 4.5, ratingCount: 29, inStock: true },
    { id: "p12", storeId: "st-colorland", name: "Painter's Tape", nameAr: "شريط لاصق للدهان", price: 35, category: "paint", icon: "scissors", tint: "#F29999", rating: 4.6, ratingCount: 75, inStock: true },
    // ElectroHub
    { id: "p13", storeId: "st-electrohub", name: "Smart Switch 2-gang", nameAr: "بريزة ذكية مزدوجة", price: 260, category: "electrical", icon: "plug", tint: "#A9A1FF", rating: 4.5, ratingCount: 64, inStock: true },
    { id: "p14", storeId: "st-electrohub", name: "Cable 2.5mm (10m)", nameAr: "سلك ٢.٥ مم (١٠ متر)", price: 180, category: "electrical", icon: "cable", tint: "#F2AD94", rating: 4.6, ratingCount: 91, inStock: true },
    { id: "p15", storeId: "st-electrohub", name: "Circuit Breaker 32A", nameAr: "قاطع كهربائي ٣٢ أمبير", price: 145, category: "electrical", icon: "zap", tint: "#F29999", rating: 4.7, ratingCount: 58, inStock: true },
    { id: "p16", storeId: "st-electrohub", name: "Doorbell Wireless", nameAr: "جرس باب لاسلكي", price: 210, category: "electrical", icon: "bell", tint: "#A9A1FF", rating: 4.2, ratingCount: 38, inStock: false },
  ];

  // ── Seeded bookings to make both demo sides feel alive ──
  const bookings: DB["bookings"] = [
    // 1) PENDING request waiting for the technician demo account (Ahmed)
    {
      id: "MB-1041", homeownerId: "u-home", technicianId: "u-tech1", profession: "plumbing",
      serviceKey: "fix-leak", notes: "Kitchen sink is leaking from the pipe under the basin. Water is dripping constantly.",
      address: "12 Abbas El Akkad St., Nasr City, Cairo", district: "nasr",
      scheduledAt: now + 3600_000 * 3, estimateMin: 250, estimateMax: 600,
      status: "pending", videoCallDone: true, createdAt: now - 1200_000,
      timeline: [{ status: "requested", at: now - 1200_000 }, { status: "pending", at: now - 1200_000 }],
    },
    // 2) Accepted upcoming job with chat history
    {
      id: "MB-1039", homeownerId: "u-home", technicianId: "u-tech4", profession: "ac",
      serviceKey: "ac-service", notes: "AC hasn't been cleaned since last summer.",
      address: "12 Abbas El Akkad St., Nasr City, Cairo", district: "nasr",
      scheduledAt: now + 86400_000, estimateMin: 300, estimateMax: 500,
      status: "accepted", videoCallDone: false, createdAt: now - 86400_000,
      timeline: [
        { status: "requested", at: now - 86400_000 },
        { status: "pending", at: now - 86400_000 },
        { status: "accepted", at: now - 86000_000 },
      ],
    },
    // 3) Completed job with review
    {
      id: "MB-1022", homeownerId: "u-home", technicianId: "u-tech1", profession: "plumbing",
      serviceKey: "install-faucet", address: "12 Abbas El Akkad St., Nasr City, Cairo", district: "nasr",
      scheduledAt: now - 86400_000 * 6, estimateMin: 200, estimateMax: 450, finalPrice: 380,
      status: "completed", videoCallDone: false, createdAt: now - 86400_000 * 7,
      timeline: [
        { status: "requested", at: now - 86400_000 * 7 },
        { status: "pending", at: now - 86400_000 * 7 },
        { status: "accepted", at: now - 86400_000 * 7 + 1800_000 },
        { status: "enroute", at: now - 86400_000 * 6 },
        { status: "inprogress", at: now - 86400_000 * 6 + 2400_000 },
        { status: "completed", at: now - 86400_000 * 6 + 7200_000 },
      ],
    },
  ];

  const reviews: DB["reviews"] = [
    { id: "r1", bookingId: "MB-1022", technicianId: "u-tech1", homeownerId: "u-home", stars: 5, comment: "Fast, clean work and fair price. The new faucet is perfect.", at: now - 86400_000 * 6 },
    { id: "r2", bookingId: "MB-9008", technicianId: "u-tech1", homeownerId: "u-tech2", stars: 5, comment: "أحمد شاطر جدا و والتزم بالموعد", at: now - 86400_000 * 20 },
    { id: "r3", bookingId: "MB-8955", technicianId: "u-tech1", homeownerId: "u-tech3", stars: 4, comment: "Good work, arrived a bit late but fixed everything.", at: now - 86400_000 * 45 },
  ];

  // Conversation for the accepted AC booking + pending one
  const conversations: DB["conversations"] = [
    { id: "c1", participantIds: ["u-home", "u-tech1"], lastAt: now - 1100_000 },
    { id: "c2", participantIds: ["u-home", "u-tech4"], lastAt: now - 86000_000 },
  ];

  const messages: DB["messages"] = [
    { id: "m1", conversationId: "c1", fromId: "u-home", text: "Hi Ahmed, the kitchen sink is leaking badly. Can you take a look today?", at: now - 1400_000, kind: "text" },
    { id: "m2", conversationId: "c1", fromId: "u-tech1", text: "Welcome! I saw your request. Let's do a quick video call so I can see the leak and give you an accurate price.", at: now - 1300_000, kind: "text" },
    { id: "m3", conversationId: "c1", fromId: "system", text: "📹 Video diagnosis completed — estimate: EGP 250–600", at: now - 1250_000, kind: "system" },
    { id: "m4", conversationId: "c1", fromId: "u-home", text: "Great, I just sent the booking request for 3 PM 🙏", at: now - 1100_000, kind: "text" },
    { id: "m5", conversationId: "c2", fromId: "u-tech4", text: "Good evening! Confirming your AC service tomorrow. I'll call 30 minutes before arrival.", at: now - 86000_000, kind: "text" },
  ];

  return {
    users,
    technicians,
    stores,
    products,
    bookings,
    conversations,
    messages,
    reviews,
    deliveries: [],
    counters: { booking: 1042, delivery: 301 },
  };
}
