// ─── Malmoum shared server types ───────────────────────────────────────────

export type Role = "homeowner" | "technician";
export type Lang = "en" | "ar";

export type Profession =
  | "plumbing"
  | "electrical"
  | "carpentry"
  | "ac"
  | "painting"
  | "appliance";

export interface User {
  id: string;
  name: string;
  nameAr?: string;
  phone: string;
  email: string;
  passwordHash: string;
  role: Role;
  avatar?: string; // image url (technicians)
  avatarColor?: string; // initials tile bg
  language: Lang;
  district: string;
  address?: string;
  createdAt: number;
}

export interface TechnicianProfile {
  userId: string;
  professions: Profession[];
  bio: string;
  bioAr: string;
  rating: number;
  ratingCount: number;
  experienceYears: number;
  visitFee: number; // EGP
  etaMin: number;
  completedJobs: number;
  verified: boolean;
  available: boolean;
  mapPos: { x: number; y: number }; // % coords on stylized map
}

export interface Store {
  id: string;
  name: string;
  nameAr: string;
  category: "tools" | "plumbing" | "electrical" | "paint";
  logoColor: string;
  logoText: string;
  rating: number;
  ratingCount: number;
  etaMin: number;
  deliveryFee: number;
  district: string;
  mapPos: { x: number; y: number };
}

export interface Product {
  id: string;
  storeId: string;
  name: string;
  nameAr: string;
  price: number; // EGP
  category: string;
  image?: string;
  icon?: string;
  tint?: string;
  rating: number;
  ratingCount: number;
  inStock: boolean;
}

export type BookingStatus =
  | "pending"
  | "accepted"
  | "declined"
  | "enroute"
  | "inprogress"
  | "completed"
  | "cancelled";

export interface TimelineEntry {
  status: BookingStatus | "requested";
  at: number;
}

export interface Booking {
  id: string;
  homeownerId: string;
  technicianId: string;
  profession: Profession;
  serviceKey: string;
  notes?: string;
  address: string;
  district: string;
  scheduledAt: number;
  estimateMin: number; // EGP
  estimateMax: number; // EGP
  finalPrice?: number;
  status: BookingStatus;
  videoCallDone: boolean;
  createdAt: number;
  timeline: TimelineEntry[];
}

export interface Conversation {
  id: string;
  participantIds: [string, string];
  lastAt: number;
  lastRead?: Record<string, number>;
}

export interface Message {
  id: string;
  conversationId: string;
  fromId: string; // "system" for system messages
  text: string;
  at: number;
  kind: "text" | "system";
}

export interface Review {
  id: string;
  bookingId: string;
  technicianId: string;
  homeownerId: string;
  stars: number;
  comment: string;
  at: number;
}

export type DeliveryStatus = "confirmed" | "preparing" | "ontheway" | "delivered" | "cancelled";

export interface DeliveryOrder {
  id: string;
  homeownerId: string;
  storeId: string;
  items: { productId: string; name: string; nameAr: string; price: number; qty: number }[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  address: string;
  createdAt: number;
}

export interface DB {
  users: User[];
  technicians: TechnicianProfile[];
  stores: Store[];
  products: Product[];
  bookings: Booking[];
  conversations: Conversation[];
  messages: Message[];
  reviews: Review[];
  deliveries: DeliveryOrder[];
  counters: { booking: number; delivery: number };
}

// Enriched payloads sent to the client
export interface PublicUser {
  id: string;
  name: string;
  nameAr?: string;
  phone: string;
  email: string;
  role: Role;
  avatar?: string;
  avatarColor?: string;
  language: Lang;
  district: string;
  address?: string;
}

export interface PublicTechnician extends TechnicianProfile {
  user: PublicUser;
}

export interface ServiceDef {
  key: string;
  profession: Profession;
  en: string;
  ar: string;
  from: number; // EGP
  to: number; // EGP
  minutes: number;
}
