import jwt from "jsonwebtoken";
import type { Request, Response, NextFunction } from "express";
import type { PublicUser, User } from "./types.js";
import { db } from "./db.js";
import { getSecret } from "./db.js";

export function signToken(userId: string): string {
  return jwt.sign({ uid: userId }, getSecret(), { expiresIn: "30d" });
}

export function verifyToken(token: string): string | null {
  try {
    const payload = jwt.verify(token, getSecret()) as { uid: string };
    return payload.uid;
  } catch {
    return null;
  }
}

export function publicUser(u: User): PublicUser {
  return {
    id: u.id, name: u.name, nameAr: u.nameAr, phone: u.phone, email: u.email,
    role: u.role, avatar: u.avatar, avatarColor: u.avatarColor,
    language: u.language, district: u.district, address: u.address,
  };
}

// Auth middleware — attaches req.user when a valid bearer token is present
export function authRequired(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "unauthorized" });
  const uid = verifyToken(token);
  if (!uid) return res.status(401).json({ error: "unauthorized" });
  const user = db.users.find((u) => u.id === uid);
  if (!user) return res.status(401).json({ error: "unauthorized" });
  (req as any).user = user;
  next();
}

export function authOptional(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (token) {
    const uid = verifyToken(token);
    if (uid) (req as any).user = db.users.find((u) => u.id === uid) || null;
  }
  next();
}
