import express from "express";
import cors from "cors";
import path from "path";
import fs from "fs";
import bcrypt from "bcryptjs";
import { fileURLToPath } from "url";
import { db, loadDb, saveDb } from "./db.js";
import { authRequired, authOptional, publicUser, signToken } from "./auth.js";
import { SERVICES, DISTRICTS, PROFESSIONS } from "./seed.js";
import type {
  Booking, BookingStatus, Conversation, Message, Review, TechnicianProfile, User,
} from "./types.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

loadDb();

// ─── Helpers ───────────────────────────────────────────────────────────────
const now = () => Date.now();

function findUser(id: string): User | undefined {
  return db.users.find((u) => u.id === id);
}
function techProfile(userId: string): TechnicianProfile | undefined {
  return db.technicians.find((t) => t.userId === userId);
}
function serviceByKey(key: string) {
  return SERVICES.find((s) => s.key === key);
}

function ensureConversation(a: string, b: string): Conversation {
  let c = db.conversations.find(
    (x) => x.participantIds.includes(a) && x.participantIds.includes(b)
  );
  if (!c) {
    c = { id: "c" + Math.random().toString(36).slice(2, 9), participantIds: [a, b], lastAt: now(), lastRead: {} } as Conversation;
    db.conversations.push(c);
    saveDb();
  }
  return c;
}

function pushSystemMessage(convId: string, text: string) {
  db.messages.push({ id: "m" + Math.random().toString(36).slice(2, 10), conversationId: convId, fromId: "system", text, at: now(), kind: "system" });
  const c = db.conversations.find((x) => x.id === convId);
  if (c) c.lastAt = now();
  saveDb();
}

function conversationFor(userA: string, userB: string): Conversation | undefined {
  return db.conversations.find(
    (x) => x.participantIds.includes(userA) && x.participantIds.includes(userB)
  );
}

function enrichedBooking(b: Booking, viewerId: string) {
  const homeowner = findUser(b.homeownerId);
  const technician = findUser(b.technicianId);
  const tProfile = techProfile(b.technicianId);
  const service = serviceByKey(b.serviceKey);
  const review = db.reviews.find((r) => r.bookingId === b.id);
  const conv = conversationFor(b.homeownerId, b.technicianId);
  const counterpart = viewerId === b.homeownerId ? technician : homeowner;
  return {
    ...b,
    service: service ? { key: service.key, en: service.en, ar: service.ar, from: service.from, to: service.to, profession: service.profession } : null,
    homeowner: homeowner ? {
      id: homeowner.id, name: homeowner.name, nameAr: homeowner.nameAr,
      phone: homeowner.phone, avatar: homeowner.avatar, avatarColor: homeowner.avatarColor, address: homeowner.address,
    } : null,
    technician: technician ? {
      id: technician.id, name: technician.name, nameAr: technician.nameAr,
      phone: technician.phone, avatar: technician.avatar, avatarColor: technician.avatarColor,
      rating: tProfile?.rating ?? 0, etaMin: tProfile?.etaMin ?? 30,
    } : null,
    review: review ? { stars: review.stars, comment: review.comment } : null,
    conversationId: conv?.id ?? null,
    isMine: b.homeownerId === viewerId,
  };
}

function publicTechnician(t: TechnicianProfile) {
  const u = findUser(t.userId);
  return { ...t, user: u ? publicUser(u) : null };
}

// ─── Auth ──────────────────────────────────────────────────────────────────
app.post("/api/auth/register", (req, res) => {
  const { name, nameAr, phone, email, password, role, district, language } = req.body || {};
  if (!name || !email || !password || !role) return res.status(400).json({ error: "missing_fields" });
  if (!["homeowner", "technician"].includes(role)) return res.status(400).json({ error: "bad_role" });
  const emailNorm = String(email).toLowerCase().trim();
  if (db.users.some((u) => u.email === emailNorm)) return res.status(409).json({ error: "email_exists" });

  const colors = ["#675FFF", "#5C57F2", "#362D73", "#F2AD94", "#F29999"];
  const user: User = {
    id: "u" + Math.random().toString(36).slice(2, 9),
    name: String(name).slice(0, 60),
    nameAr: nameAr ? String(nameAr).slice(0, 60) : undefined,
    phone: phone ? String(phone).slice(0, 24) : "",
    email: emailNorm,
    passwordHash: bcrypt.hashSync(String(password), 8),
    role,
    avatarColor: colors[Math.floor(Math.random() * colors.length)],
    language: language === "ar" ? "ar" : "en",
    district: district || "nasr",
    createdAt: now(),
  };
  db.users.push(user);
  if (role === "technician") {
    db.technicians.push({
      userId: user.id,
      professions: ["plumbing"],
      bio: "New on Malmoum — ready to help!",
      bioAr: "جديد على ملموم — جاهز للمساعدة!",
      rating: 5, ratingCount: 0, experienceYears: 1, visitFee: 80, etaMin: 40,
      completedJobs: 0, verified: false, available: true,
      mapPos: { x: 40 + Math.random() * 20, y: 30 + Math.random() * 20 },
    });
  }
  saveDb();
  res.json({ token: signToken(user.id), user: publicUser(user) });
});

app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body || {};
  const user = db.users.find((u) => u.email === String(email || "").toLowerCase().trim());
  if (!user || !bcrypt.compareSync(String(password || ""), user.passwordHash)) {
    return res.status(401).json({ error: "invalid_credentials" });
  }
  res.json({ token: signToken(user.id), user: publicUser(user) });
});

// One-tap demo login — perfect for graduation-jury walkthroughs
app.post("/api/auth/demo", (req, res) => {
  const role = req.body?.role === "technician" ? "technician" : "homeowner";
  const user = db.users.find((u) => u.email === (role === "technician" ? "technician@malmoum.app" : "homeowner@malmoum.app"));
  if (!user) return res.status(500).json({ error: "demo_missing" });
  res.json({ token: signToken(user.id), user: publicUser(user) });
});

// ─── Catalog (public) ──────────────────────────────────────────────────────
app.get("/api/catalog", (_req, res) => {
  res.json({
    professions: PROFESSIONS,
    services: SERVICES,
    districts: DISTRICTS,
    technicians: db.technicians.map(publicTechnician),
    stores: db.stores.map((s) => ({
      ...s,
      products: db.products.filter((p) => p.storeId === s.id),
    })),
  });
});

// ─── Me / profile ──────────────────────────────────────────────────────────
app.get("/api/me", authRequired, (req, res) => {
  const u = (req as any).user as User;
  const t = u.role === "technician" ? techProfile(u.id) : null;
  res.json({ user: publicUser(u), technician: t });
});

app.patch("/api/me", authRequired, (req, res) => {
  const u = (req as any).user as User;
  const body = req.body || {};
  for (const key of ["name", "nameAr", "phone", "address", "district", "language"] as const) {
    if (body[key] !== undefined) (u as any)[key] = body[key];
  }
  if (u.role === "technician") {
    const t = techProfile(u.id);
    if (t) {
      for (const key of ["bio", "bioAr", "visitFee", "etaMin", "available", "professions"] as const) {
        if (body[key] !== undefined) (t as any)[key] = body[key];
      }
    }
  }
  saveDb();
  res.json({ user: publicUser(u), technician: u.role === "technician" ? techProfile(u.id) : null });
});

// ─── Technician detail ─────────────────────────────────────────────────────
app.get("/api/technicians/:id", authOptional, (req, res) => {
  const t = db.technicians.find((x) => x.userId === req.params.id);
  if (!t) return res.status(404).json({ error: "not_found" });
  const reviews = db.reviews
    .filter((r) => r.technicianId === req.params.id)
    .sort((a, b) => b.at - a.at)
    .slice(0, 10)
    .map((r) => {
      const u = findUser(r.homeownerId);
      return { ...r, author: u ? { name: u.name, nameAr: u.nameAr, avatarColor: u.avatarColor } : null };
    });
  const services = SERVICES.filter((s) => t.professions.includes(s.profession));
  res.json({ technician: publicTechnician(t), reviews, services });
});

// ─── Bookings ──────────────────────────────────────────────────────────────
app.get("/api/bookings", authRequired, (req, res) => {
  const me = (req as any).user as User;
  const mine = db.bookings
    .filter((b) => b.homeownerId === me.id || b.technicianId === me.id)
    .sort((a, b) => b.createdAt - a.createdAt)
    .map((b) => enrichedBooking(b, me.id));
  res.json({ bookings: mine });
});

app.post("/api/bookings", authRequired, (req, res) => {
  const me = (req as any).user as User;
  if (me.role !== "homeowner") return res.status(403).json({ error: "homeowners_only" });
  const { technicianId, serviceKey, notes, address, district, scheduledAt, videoCallDone } = req.body || {};
  const t = techProfile(String(technicianId));
  const s = serviceByKey(String(serviceKey));
  if (!t || !s) return res.status(400).json({ error: "invalid_technician_or_service" });

  const id = "MB-" + (db.counters.booking++ + 1000);
  const booking: Booking = {
    id,
    homeownerId: me.id,
    technicianId: t.userId,
    profession: s.profession,
    serviceKey: s.key,
    notes: notes ? String(notes).slice(0, 500) : undefined,
    address: String(address || "12 Abbas El Akkad St., Nasr City, Cairo"),
    district: String(district || me.district || "nasr"),
    scheduledAt: Number(scheduledAt) || now() + 7200_000,
    estimateMin: s.from,
    estimateMax: s.to,
    status: "pending",
    videoCallDone: !!videoCallDone,
    createdAt: now(),
    timeline: [{ status: "requested", at: now() }, { status: "pending", at: now() }],
  };
  db.bookings.push(booking);

  const conv = ensureConversation(me.id, t.userId);
  pushSystemMessage(conv.id, `📋 New booking request ${id} — ${s.en} · ${new Date(booking.scheduledAt).toLocaleString("en-GB", { weekday: "short", hour: "2-digit", minute: "2-digit" })} · EGP ${s.from}–${s.to}`);
  saveDb();
  res.json({ booking: enrichedBooking(booking, me.id) });
});

const TRANSITIONS: Record<string, { from: BookingStatus[]; role: "technician" | "homeowner" }> = {
  accept:     { from: ["pending"], role: "technician" },
  decline:    { from: ["pending"], role: "technician" },
  enroute:    { from: ["accepted"], role: "technician" },
  inprogress: { from: ["enroute"], role: "technician" },
  complete:   { from: ["inprogress"], role: "technician" },
  cancel:     { from: ["pending", "accepted"], role: "homeowner" },
};

app.patch("/api/bookings/:id", authRequired, (req, res) => {
  const me = (req as any).user as User;
  const b = db.bookings.find((x) => x.id === req.params.id);
  if (!b) return res.status(404).json({ error: "not_found" });
  const action = String(req.body?.action || "");
  const rule = TRANSITIONS[action];
  if (!rule) return res.status(400).json({ error: "unknown_action" });
  if (rule.role !== me.role || b[rule.role === "technician" ? "technicianId" : "homeownerId"] !== me.id) {
    return res.status(403).json({ error: "forbidden" });
  }
  if (!rule.from.includes(b.status)) return res.status(409).json({ error: "bad_state", status: b.status });

  const STATUS_BY_ACTION: Record<string, BookingStatus> = {
    accept: "accepted",
    decline: "declined",
    enroute: "enroute",
    inprogress: "inprogress",
    complete: "completed",
    cancel: "cancelled",
  };
  b.status = STATUS_BY_ACTION[action];
  b.timeline.push({ status: b.status, at: now() });

  if (action === "complete") {
    const price = Number(req.body?.finalPrice);
    b.finalPrice = price && price > 0 ? price : b.estimateMax;
    const t = techProfile(b.technicianId);
    if (t) { t.completedJobs += 1; }
  }

  const conv = ensureConversation(b.homeownerId, b.technicianId);
  const labels: Record<string, string> = {
    accept: "✅ Booking accepted — technician confirmed",
    decline: "❌ Request declined",
    enroute: "🛠️ Technician is on the way",
    inprogress: "🔧 Work started",
    complete: `✅ Job completed${b.finalPrice ? ` — total EGP ${b.finalPrice}` : ""}`,
    cancel: "🚫 Booking cancelled",
  };
  pushSystemMessage(conv.id, labels[action]);
  saveDb();
  res.json({ booking: enrichedBooking(b, me.id) });
});

app.post("/api/bookings/:id/review", authRequired, (req, res) => {
  const me = (req as any).user as User;
  const b = db.bookings.find((x) => x.id === req.params.id);
  if (!b || b.homeownerId !== me.id) return res.status(404).json({ error: "not_found" });
  if (b.status !== "completed") return res.status(409).json({ error: "not_completed" });
  if (db.reviews.some((r) => r.bookingId === b.id)) return res.status(409).json({ error: "already_reviewed" });
  const stars = Math.max(1, Math.min(5, Number(req.body?.stars) || 5));
  const review: Review = {
    id: "r" + Math.random().toString(36).slice(2, 9),
    bookingId: b.id, technicianId: b.technicianId, homeownerId: me.id,
    stars, comment: String(req.body?.comment || "").slice(0, 300), at: now(),
  };
  db.reviews.push(review);
  const t = techProfile(b.technicianId);
  if (t) {
    const newCount = t.ratingCount + 1;
    t.rating = Math.round(((t.rating * t.ratingCount + stars) / newCount) * 10) / 10;
    t.ratingCount = newCount;
  }
  saveDb();
  res.json({ review });
});

// ─── Conversations / messages ──────────────────────────────────────────────
app.get("/api/conversations", authRequired, (req, res) => {
  const me = (req as any).user as User;
  const list = db.conversations
    .filter((c) => c.participantIds.includes(me.id))
    .sort((a, b) => b.lastAt - a.lastAt)
    .map((c) => {
      const otherId = c.participantIds.find((p) => p !== me.id)!;
      const other = findUser(otherId);
      const otherProfile = techProfile(otherId);
      const msgs = db.messages.filter((m) => m.conversationId === c.id);
      const last = msgs[msgs.length - 1];
      const lastRead = (c.lastRead || {})[me.id] || 0;
      const unread = msgs.filter((m) => m.fromId !== me.id && m.at > lastRead).length;
      return {
        id: c.id, lastAt: c.lastAt, unread,
        counterpart: other ? {
          id: other.id, name: other.name, nameAr: other.nameAr, avatar: other.avatar,
          avatarColor: other.avatarColor, role: other.role, rating: otherProfile?.rating,
        } : null,
        lastMessage: last ? { text: last.text, at: last.at, kind: last.kind, fromId: last.fromId } : null,
      };
    });
  res.json({ conversations: list });
});

app.post("/api/conversations", authRequired, (req, res) => {
  const me = (req as any).user as User;
  const withUserId = String(req.body?.withUserId || "");
  if (!findUser(withUserId)) return res.status(404).json({ error: "not_found" });
  const c = ensureConversation(me.id, withUserId);
  res.json({ conversationId: c.id });
});

app.get("/api/conversations/:id/messages", authRequired, (req, res) => {
  const me = (req as any).user as User;
  const c = db.conversations.find((x) => x.id === req.params.id);
  if (!c || !c.participantIds.includes(me.id)) return res.status(404).json({ error: "not_found" });
  const messages = db.messages.filter((m) => m.conversationId === c.id).sort((a, b) => a.at - b.at);
  (c.lastRead ||= {})[me.id] = now();
  saveDb();
  res.json({ messages, counterpartId: c.participantIds.find((p) => p !== me.id) });
});

app.post("/api/conversations/:id/messages", authRequired, (req, res) => {
  const me = (req as any).user as User;
  const c = db.conversations.find((x) => x.id === req.params.id);
  if (!c || !c.participantIds.includes(me.id)) return res.status(404).json({ error: "not_found" });
  const text = String(req.body?.text || "").trim().slice(0, 800);
  if (!text) return res.status(400).json({ error: "empty" });
  const msg: Message = {
    id: "m" + Math.random().toString(36).slice(2, 10),
    conversationId: c.id, fromId: me.id, text, at: now(), kind: "text",
  };
  db.messages.push(msg);
  c.lastAt = msg.at;
  saveDb();
  res.json({ message: msg });
});

// ─── Deliveries (marketplace checkout) ─────────────────────────────────────
function deliveryVirtualStatus(o: { createdAt: number; status?: string }) {
  const mins = (now() - o.createdAt) / 60000;
  if (mins < 0.25) return "confirmed";
  if (mins < 1) return "preparing";
  if (mins < 3) return "ontheway";
  return "delivered";
}

app.get("/api/deliveries", authRequired, (req, res) => {
  const me = (req as any).user as User;
  const list = db.deliveries
    .filter((o) => o.homeownerId === me.id)
    .sort((a, b) => b.createdAt - a.createdAt)
    .map((o) => ({ ...o, status: deliveryVirtualStatus(o) }));
  res.json({ deliveries: list });
});

app.post("/api/deliveries", authRequired, (req, res) => {
  const me = (req as any).user as User;
  const { storeId, items, address } = req.body || {};
  const store = db.stores.find((s) => s.id === String(storeId));
  if (!store || !Array.isArray(items) || items.length === 0) return res.status(400).json({ error: "bad_request" });
  const resolved = items.map((it: any) => {
    const p = db.products.find((x) => x.id === it.productId);
    return p ? { productId: p.id, name: p.name, nameAr: p.nameAr, price: p.price, qty: Math.max(1, Number(it.qty) || 1) } : null;
  }).filter((x): x is { productId: string; name: string; nameAr: string; price: number; qty: number } => !!x);
  if (!resolved.length) return res.status(400).json({ error: "bad_items" });
  const subtotal = resolved.reduce((s: number, it: any) => s + it.price * it.qty, 0);
  const order = {
    id: "DL-" + db.counters.delivery++,
    homeownerId: me.id, storeId: store.id, items: resolved,
    subtotal, deliveryFee: store.deliveryFee, total: subtotal + store.deliveryFee,
    address: String(address || me.address || "Nasr City, Cairo"),
    createdAt: now(),
  };
  db.deliveries.push(order);
  saveDb();
  res.json({ delivery: { ...order, status: deliveryVirtualStatus(order) } });
});

// ─── Technician dashboard stats ────────────────────────────────────────────
app.get("/api/tech/stats", authRequired, (req, res) => {
  const me = (req as any).user as User;
  const t = techProfile(me.id);
  if (!t) return res.status(404).json({ error: "not_technician" });
  const mine = db.bookings.filter((b) => b.technicianId === me.id);
  const weekAgo = now() - 7 * 86400_000;
  const completedWeek = mine.filter((b) => b.status === "completed" && b.timeline.some((e) => e.status === "completed" && e.at > weekAgo));
  const earningsWeek = completedWeek.reduce((s, b) => s + (b.finalPrice || b.estimateMax), 0);
  const pending = mine.filter((b) => b.status === "pending").length;
  const active = mine.filter((b) => ["accepted", "enroute", "inprogress"].includes(b.status)).length;
  const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
  const today = mine.filter((b) => ["accepted", "enroute", "inprogress"].includes(b.status) && b.scheduledAt >= todayStart.getTime());
  res.json({
    rating: t.rating, ratingCount: t.ratingCount, completedJobs: t.completedJobs,
    earningsWeek, completedWeek: completedWeek.length, pending, active,
    todayCount: today.length, available: t.available,
  });
});

// ─── Meta + static (production) ────────────────────────────────────────────
app.get("/api/health", (_req, res) => res.json({ ok: true, name: "malmoum-api", ts: now() }));

const distDir = path.join(__dirname, "..", "dist");
if (fs.existsSync(distDir)) {
  app.use(express.static(distDir));
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api")) return next();
    res.sendFile(path.join(distDir, "index.html"));
  });
}

const PORT = Number(process.env.PORT || 4000);
app.listen(PORT, "0.0.0.0", () => {
  console.log(`[malmoum-api] ready on http://localhost:${PORT}`);
});
