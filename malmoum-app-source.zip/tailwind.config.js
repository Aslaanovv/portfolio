/** @type {import('tailwindcss').Config} */
// Malmoum design system — see portfolio case study / Figma design system board.
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Primary palette
        primary: {
          DEFAULT: "#675FFF",
          light: "#A9A1FF",
          lighter: "#E4E1FF",
          dark: "#5C57F2",
          deep: "#362D73",
          fg: "#FFFFFF",
        },
        // Secondary palette
        ink: "#0F1621", // near-black text
        night: "#141C26", // dark navy
        paper: "#FCFCFC",
        coral: "#F29999",
        peach: "#F2AD94",
        // Neutrals
        line: "#ECEAF6",
        muted: "#6B7280",
        surface: "#FFFFFF",
        lavender: "#F3F1FC",
      },
      fontFamily: {
        sans: ["Inter", "Cairo", "system-ui", "sans-serif"],
        display: ["Inter", "Cairo", "system-ui", "sans-serif"],
      },
      fontSize: {
        // Design-system type scale
        h1: ["32px", { lineHeight: "1.2", fontWeight: "700", letterSpacing: "-0.5px" }],
        h2: ["24px", { lineHeight: "1.25", fontWeight: "600", letterSpacing: "-0.3px" }],
        h3: ["20px", { lineHeight: "1.3", fontWeight: "600", letterSpacing: "0px" }],
        sub1: ["16px", { lineHeight: "1.4", fontWeight: "500", letterSpacing: "0.15px" }],
        sub2: ["14px", { lineHeight: "1.4", fontWeight: "400", letterSpacing: "0.1px" }],
        body1: ["16px", { lineHeight: "1.5", fontWeight: "400", letterSpacing: "0.15px" }],
        body2: ["14px", { lineHeight: "1.5", fontWeight: "400", letterSpacing: "0.1px" }],
        caption: ["12px", { lineHeight: "1.4", fontWeight: "400", letterSpacing: "0.4px" }],
      },
      borderRadius: {
        card: "16px",
        xl: "20px",
        "2xl": "24px",
        "3xl": "32px",
        pill: "999px",
      },
      spacing: {
        18: "72px",
        30: "120px",
      },
      boxShadow: {
        card: "0 2px 12px rgba(54, 45, 115, 0.06)",
        float: "0 8px 30px rgba(54, 45, 115, 0.14)",
        pin: "0 6px 14px rgba(87, 76, 255, 0.35)",
      },
      keyframes: {
        pulseRing: {
          "0%": { transform: "scale(0.6)", opacity: "0.8" },
          "100%": { transform: "scale(1.8)", opacity: "0" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-400px 0" },
          "100%": { backgroundPosition: "400px 0" },
        },
        speak: {
          "0%, 100%": { transform: "scaleY(0.4)" },
          "50%": { transform: "scaleY(1)" },
        },
      },
      animation: {
        pulseRing: "pulseRing 1.8s cubic-bezier(0.2,0.6,0.4,1) infinite",
        shimmer: "shimmer 1.4s linear infinite",
        speak: "speak 0.9s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
