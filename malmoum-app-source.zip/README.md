# Malmoum — Get it done! 📱💜

> **ملموم — خلّصها!** A full-stack home-services marketplace MVP for Egypt:
> trusted technicians on a live map, video diagnosis before booking, chat,
> bookings, and a hardware-store marketplace with delivery — in one connected
> ecosystem.

Built as the working app for the **Malmoum graduation project (V1)** —
companion to the [case study & design system](https://github.com/Aslaanovv/portfolio) in the portfolio.

---

## ⚡ Quick start

```bash
npm install
npm run dev        # API on :4000 + web on :5173 (proxied)
```

Open **http://localhost:5173** → tap a demo button:

| Role | Email | Password |
|---|---|---|
| 🏠 Homeowner | `homeowner@malmoum.app` | `123456` |
| 🔧 Technician | `technician@malmoum.app` | `123456` |

**Best demo:** open two browser windows side by side, log in as the homeowner
in one and the technician in the other — bookings, chat and status changes
flow between them live. (Sessions are per-tab, so this just works.)

## ✨ Features

### 🏠 Homeowner
- **Live Cairo map** — Uber-style discovery with technician pins (pan/zoom,
  category filters, Workers ↔ Stores toggle) over a stylized hand-drawn map
- **Video diagnosis** — real camera preview (getUserMedia), simulated remote
  expert, AI-style summary (detected issue + price estimate) that flows into
  the booking
- **4-step booking flow** → live tracking timeline (Requested → Confirmed →
  On the way → In progress → Completed) → star reviews that update real ratings
- **Marketplace** — hardware stores, product catalog (EGP), cart, delivery
  orders with live status progression
- **Chat** with system messages on booking events (request, accepted, on the
  way, completed…)

### 🔧 Technician
- Dashboard with weekly earnings, jobs, rating
- **Availability toggle** — going offline hides your pin from the map
- Incoming job requests with **accept / decline**
- Job lifecycle: accept → on my way → start work → complete (with final price)

### 🌍 Both sides
- **Bilingual English + العربية with full RTL** (Inter + Cairo fonts) — switch
  anywhere from the header or profile
- JWT auth (register / login / one-tap demo), persistent JSON data store
- Desktop shows the app inside a phone frame; on real phones it runs full-bleed

## 🧱 Tech stack

| Layer | Tech |
|---|---|
| Frontend | React 18, TypeScript, Vite, Tailwind CSS, Framer Motion, lucide-react |
| Backend | Node.js, Express, JWT (bcrypt-hashed passwords) |
| Data | Persistent JSON store (zero-config, swap-ready for Postgres/Mongo) |
| Fonts | Inter (LTR) + Cairo (RTL), bundled locally — no CDN |

## 🎨 Design system

Faithful to the Malmoum Figma board:

- Primary `#675FFF` · Light `#A9A1FF` · Deep `#362D73` / `#5C57F2`
- Ink `#0F1621` · Coral `#F29999` · Peach `#F2AD94` · Paper `#FCFCFC`
- Inter type scale (H1 32 → Caption 12), 8px spacing base
- Worker / Service / Store / Product cards, segmented control, category chips,
  bottom navigation — exactly as the design-system board

## 📁 Structure

```
malmoum-app/
├── server/          # Express API — auth, bookings, chat, deliveries
│   ├── index.ts     #   routes
│   ├── seed.ts      #   demo world: 6 technicians, 4 stores, 22 services
│   ├── db.ts        #   JSON persistence
│   └── auth.ts      #   JWT middleware
└── src/
    ├── screens/homeowner/    # map, profile, video, booking, tracking, market
    ├── screens/technician/   # dashboard, job requests, job detail
    ├── MapCanvas.tsx         # stylized Cairo map + pins
    ├── i18n.ts               # full EN/AR dictionary
    └── ui.tsx                # design-system component kit
```

## 🔭 V2 roadmap (from the case study)

Smart AI problem identification · optimal technician matching · dynamic price
estimation · deeper store partnerships.

---

Made with 💜 as a graduation project — *Malmoum: bringing it all together.*
