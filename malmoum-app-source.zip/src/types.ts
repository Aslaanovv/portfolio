// Client-side types mirroring the server API
export type Role = "homeowner" | "technician";
export type Lang = "en" | "ar";

export type Profession = "plumbing" | "electrical" | "carpentry" | "ac" | "painting" | "appliance";

export interface PublicUser {
  id: string;
  name: string;
  nameAr?: string;
  phone: string;
  email: string;
  role: Role;
  avatar?: string;
  avatarColor?: string;
  language: Lang;
  district: string;
  address?: string;
}

export interface TechnicianProfile {
  userId: string;
  professions: Profession[];
  bio: string;
  bioAr: string;
  rating: number;
  ratingCount: number;
  experienceYears: number;
  visitFee: number;
  etaMin: number;
  completedJobs: number;
  verified: boolean;
  available: boolean;
  mapPos: { x: number; y: number };
}

export interface PublicTechnician extends TechnicianProfile {
  user: PublicUser | null;
}

export interface Store {
  id: string;
  name: string;
  nameAr: string;
  category: "tools" | "plumbing" | "electrical" | "paint";
  logoColor: string;
  logoText: string;
  rating: number;
  ratingCount: number;
  etaMin: number;
  deliveryFee: number;
  district: string;
  mapPos: { x: number; y: number };
  products: Product[];
}

export interface Product {
  id: string;
  storeId: string;
  name: string;
  nameAr: string;
  price: number;
  category: string;
  image?: string;
  icon?: string;
  tint?: string;
  rating: number;
  ratingCount: number;
  inStock: boolean;
}

export type BookingStatus = "pending" | "accepted" | "declined" | "enroute" | "inprogress" | "completed" | "cancelled";

export interface TimelineEntry {
  status: BookingStatus | "requested";
  at: number;
}

export interface Booking {
  id: string;
  homeownerId: string;
  technicianId: string;
  profession: Profession;
  serviceKey: string;
  notes?: string;
  address: string;
  district: string;
  scheduledAt: number;
  estimateMin: number;
  estimateMax: number;
  finalPrice?: number;
  status: BookingStatus;
  videoCallDone: boolean;
  createdAt: number;
  timeline: TimelineEntry[];
  service: { key: string; en: string; ar: string; from: number; to: number; profession: string } | null;
  homeowner: { id: string; name: string; nameAr?: string; phone: string; avatar?: string; avatarColor?: string; address?: string } | null;
  technician: { id: string; name: string; nameAr?: string; phone: string; avatar?: string; avatarColor?: string; rating: number; etaMin: number } | null;
  review: { stars: number; comment: string } | null;
  conversationId: string | null;
  isMine: boolean;
}

export interface ServiceDef {
  key: string;
  profession: Profession;
  en: string;
  ar: string;
  from: number;
  to: number;
  minutes: number;
}

export interface District {
  id: string;
  en: string;
  ar: string;
  x: number;
  y: number;
}

export interface ProfessionDef {
  id: Profession;
  en: string;
  ar: string;
  icon: string;
}

export interface ReviewItem {
  id: string;
  stars: number;
  comment: string;
  at: number;
  author: { name: string; nameAr?: string; avatarColor?: string } | null;
}

export interface Catalog {
  professions: ProfessionDef[];
  services: ServiceDef[];
  districts: District[];
  technicians: PublicTechnician[];
  stores: Store[];
}

export interface ConversationItem {
  id: string;
  lastAt: number;
  unread: number;
  counterpart: { id: string; name: string; nameAr?: string; avatar?: string; avatarColor?: string; role: Role; rating?: number } | null;
  lastMessage: { text: string; at: number; kind: "text" | "system"; fromId: string } | null;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  fromId: string;
  text: string;
  at: number;
  kind: "text" | "system";
}

export interface DeliveryOrder {
  id: string;
  storeId: string;
  items: { productId: string; name: string; nameAr: string; price: number; qty: number }[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  address: string;
  createdAt: number;
  status: "confirmed" | "preparing" | "ontheway" | "delivered" | "cancelled";
}

export interface TechStats {
  rating: number;
  ratingCount: number;
  completedJobs: number;
  earningsWeek: number;
  completedWeek: number;
  pending: number;
  active: number;
  todayCount: number;
  available: boolean;
}

export interface CartItem {
  productId: string;
  qty: number;
}
