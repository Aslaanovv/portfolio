import React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AppProvider, useApp } from "./AppContext";
import { NavigationProvider, useNav, type Route } from "./navigation";
import { PhoneShell, StatusBar } from "./PhoneShell";

import Splash from "./screens/Splash";
import AuthScreen from "./screens/AuthScreen";
import HomeScreen from "./screens/homeowner/HomeScreen";
import TechnicianProfileScreen from "./screens/homeowner/TechnicianProfileScreen";
import VideoDiagnosis from "./screens/homeowner/VideoDiagnosis";
import BookingFlow from "./screens/homeowner/BookingFlow";
import BookingSuccess from "./screens/homeowner/BookingSuccess";
import BookingsScreen from "./screens/homeowner/BookingsScreen";
import BookingTracking from "./screens/homeowner/BookingTracking";
import MessagesScreen from "./screens/MessagesScreen";
import ChatScreen from "./screens/ChatScreen";
import MarketplaceScreen from "./screens/homeowner/MarketplaceScreen";
import StoreScreen from "./screens/homeowner/StoreScreen";
import CartScreen from "./screens/homeowner/CartScreen";
import ProfileScreen from "./screens/ProfileScreen";
import TechHome from "./screens/technician/TechHome";
import TechBookingDetail from "./screens/technician/TechBookingDetail";

const TABS_HOMEOWNER = ["home", "bookings", "messages", "profile"];
const TABS_TECH = ["techhome", "bookings", "messages", "profile"];

function ScreenRenderer({ route }: { route: Route }) {
  switch (route.name) {
    case "splash": return <Splash />;
    case "auth": return <AuthScreen />;
    case "home": return <HomeScreen />;
    case "technician": return <TechnicianProfileScreen id={route.params?.id} />;
    case "video": return <VideoDiagnosis params={route.params} />;
    case "booking": return <BookingFlow params={route.params} />;
    case "bookingSuccess": return <BookingSuccess params={route.params} />;
    case "bookings": return <BookingsScreen />;
    case "tracking": return <BookingTracking id={route.params?.id} />;
    case "messages": return <MessagesScreen />;
    case "chat": return <ChatScreen params={route.params} />;
    case "market": return <MarketplaceScreen />;
    case "store": return <StoreScreen id={route.params?.id} />;
    case "cart": return <CartScreen />;
    case "profile": return <ProfileScreen />;
    case "techhome": return <TechHome />;
    case "techBooking": return <TechBookingDetail id={route.params?.id} />;
    default: return <HomeScreen />;
  }
}

const TAB_NAMES = new Set(["home", "bookings", "messages", "profile", "techhome"]);

function BottomTabs() {
  const { me, t } = useApp();
  const { stack, reset } = useNav();
  const current = stack[stack.length - 1];
  if (!current || !TAB_NAMES.has(current.name)) return null;
  const isTech = me?.role === "technician";
  const tabs = isTech ? TABS_TECH : TABS_HOMEOWNER;

  const label = (name: string) =>
    name === "techhome" ? t("techTab.jobs") :
    name === "home" ? t("home.openMap") :
    name === "bookings" ? t("tab.bookings") :
    name === "messages" ? t("tab.messages") : t("tab.profile");

  const icon = (name: string, active: boolean) => {
    const cls = active ? "text-primary" : "text-muted";
    const size = 21;
    switch (name) {
      case "home": return <HomeIcon className={cls} size={size} />;
      case "techhome": return <BriefcaseIcon className={cls} size={size} />;
      case "bookings": return <CalIcon className={cls} size={size} />;
      case "messages": return <MsgIcon className={cls} size={size} />;
      default: return <UserIcon className={cls} size={size} />;
    }
  };

  const active = current.name === "techhome" ? "techhome" : current.name;

  return (
    <div className="shrink-0 bg-white border-t border-line px-2 pt-1.5 pb-5 flex z-40">
      {tabs.map((name) => {
        const isActive = active === name;
        return (
          <button
            key={name}
            onClick={() => isActive || reset([{ name }])}
            className="tap flex-1 flex flex-col items-center gap-0.5 py-0.5"
          >
            <div className="relative">
              {icon(name, isActive)}
              {isActive && <span className="absolute -top-1 start-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary" />}
            </div>
            <span className={`text-[10px] font-semibold ${isActive ? "text-primary" : "text-muted"}`}>{label(name)}</span>
          </button>
        );
      })}
    </div>
  );
}

// inline icons to avoid extra imports cluttering
import { Home as HomeIcon, Briefcase as BriefcaseIcon, CalendarDays as CalIcon, MessageCircle as MsgIcon, User as UserIcon } from "lucide-react";

function Toasts() {
  const { toasts } = useApp();
  return (
    <div className="absolute top-16 inset-x-0 z-[70] flex flex-col items-center gap-2 px-6 pointer-events-none">
      <AnimatePresence>
        {toasts.map((tt) => (
          <motion.div
            key={tt.id}
            initial={{ opacity: 0, y: -14, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            className={`px-4 py-2.5 rounded-pill shadow-float text-sub2 font-semibold max-w-full truncate ${
              tt.kind === "error" ? "bg-[#c0392b] text-white" : tt.kind === "success" ? "bg-ink text-white" : "bg-white text-ink border border-line"
            }`}
          >
            {tt.text}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

function Root() {
  const { me } = useApp();
  const { stack } = useNav();
  const current = stack[stack.length - 1];
  const dark = current?.name === "splash";

  return (
    <PhoneShell>
      <StatusBar dark={dark} />
      <Toasts />
      <div className="relative flex-1 min-h-0">
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.div
            key={current.key}
            initial={{ x: "100%", opacity: 0.6 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: "-18%", opacity: 0 }}
            transition={{ type: "spring", damping: 32, stiffness: 380 }}
            className="absolute inset-0 flex flex-col bg-paper"
            drag="x"
            dragDirectionLock
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.12}
            onDragEnd={(_, info) => {
              // edge-swipe back (from the correct side for LTR/RTL)
              const rtl = document.documentElement.dir === "rtl";
              const ok = rtl ? info.offset.x < 90 : info.offset.x > 90;
              if (ok && stack.length > 1) useNavSafePop();
            }}
          >
            <ScreenRenderer route={current} />
          </motion.div>
        </AnimatePresence>
      </div>
      {me && <BottomTabs />}
    </PhoneShell>
  );
}

// small helper so the drag handler above can call pop without re-subscribing
let popFn: (() => void) | null = null;
function useNavSafePop() {
  popFn?.();
}
function PopBinder() {
  const { pop } = useNav();
  popFn = pop;
  return null;
}

export default function App() {
  return (
    <AppProvider>
      <NavigationProvider>
        <PopBinder />
        <Root />
      </NavigationProvider>
    </AppProvider>
  );
}
