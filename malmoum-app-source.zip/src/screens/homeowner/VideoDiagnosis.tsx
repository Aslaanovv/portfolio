import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mic, MicOff, VideoOff, PhoneOff, Camera, Sparkles, CheckCircle2 } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, Btn } from "@/ui";

// Simulated video-diagnosis call: real local camera preview (getUserMedia) with a
// graceful fallback; the remote side is simulated in this MVP — exactly the
// "video diagnosis before booking" differentiator from the Malmoum case study.

const DIAGNOSES: Record<string, { en: string; ar: string; from: number; to: number }> = {
  "fix-leak": { en: "Leaking drain trap under the basin — worn gasket + loose slip nut", ar: "تسريب في خزانة المجاري تحت الحوض — جوان متآكل وصامولة مفكوكة", from: 250, to: 450 },
  "install-faucet": { en: "Standard faucet replacement — compatible part needed", ar: "استبدال حنفية قياسي — محتاج قطعة متوافقة", from: 200, to: 400 },
  "unclog-drain": { en: "Hair + grease clog in the P-trap, drain snake will clear it", ar: "انسداد شعر ودهون في الخزانة — هيفتح بمسمار السباكة", from: 180, to: 350 },
  "water-heater": { en: "Heating element likely burnt — part replacement required", ar: "غالباً عنصر التسخين محروق — محتاج تغيير قطعة", from: 400, to: 800 },
  default: { en: "Issue identified from video — technician will confirm on site", ar: "تم تحديد المشكلة من الفيديو — الفني هيأكدها في الموقع", from: 250, to: 700 },
};

export default function VideoDiagnosis({ params }: { params?: { techId?: string; serviceKey?: string } }) {
  const { t, lang } = useApp();
  const { push, replace, pop } = useNav();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [phase, setPhase] = useState<"connecting" | "live" | "summary">("connecting");
  const [seconds, setSeconds] = useState(0);
  const [muted, setMuted] = useState(false);
  const [camOff, setCamOff] = useState(false);
  const [hasCam, setHasCam] = useState(true);
  const [diagnosis, setDiagnosis] = useState<(typeof DIAGNOSES)["default"] | null>(null);

  const techId = params?.techId;
  const tech = useApp().catalog?.technicians.find((x) => x.userId === techId);
  const name = ((lang === "ar" ? tech?.user?.nameAr : tech?.user?.name) || "Technician");

  // start camera
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: false });
        if (cancelled) { stream.getTracks().forEach((tr) => tr.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) videoRef.current.srcObject = stream;
        setHasCam(true);
      } catch {
        setHasCam(false); // permission denied or no device → fallback UI
      }
    })();
    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach((tr) => tr.stop());
    };
  }, []);

  // connect → live
  useEffect(() => {
    if (phase !== "connecting") return;
    const id = setTimeout(() => setPhase("live"), 1800);
    return () => clearTimeout(id);
  }, [phase]);

  // timer while live
  useEffect(() => {
    if (phase !== "live") return;
    const id = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, [phase]);

  const endCall = () => {
    streamRef.current?.getTracks().forEach((tr) => tr.stop());
    const d = DIAGNOSES[params?.serviceKey || ""] || DIAGNOSES.default;
    setDiagnosis(d);
    setPhase("summary");
  };

  const mmss = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;

  // ── Summary phase ──
  if (phase === "summary" && diagnosis) {
    return (
      <div className="flex-1 flex flex-col bg-paper overflow-y-auto no-scrollbar">
        <div className="brand-gradient px-6 pt-12 pb-10 rounded-b-[2.5rem] text-white text-center relative overflow-hidden">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", damping: 14 }} className="mx-auto w-16 h-16 rounded-full bg-white/15 flex items-center justify-center mb-4">
            <CheckCircle2 size={30} />
          </motion.div>
          <h2 className="font-extrabold text-h1">{t("call.summary")}</h2>
          <p className="text-white/80 text-sub2 mt-1">{t("call.diagnosedBy", { name })} · {mmss}</p>
          <span className="absolute -end-6 -top-6 opacity-15"><Sparkles size={110} /></span>
        </div>
        <div className="px-5 -mt-6 pb-8">
          <motion.div initial={{ y: 24, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.15 }}>
            <div className="bg-white rounded-2xl border border-line shadow-card p-5 mb-4">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles size={15} className="text-primary" />
                <span className="text-caption font-bold uppercase tracking-widest text-primary">{t("call.detected")}</span>
              </div>
              <p className="font-semibold text-body1 text-ink leading-relaxed">{lang === "ar" ? diagnosis.ar : diagnosis.en}</p>
            </div>
            <div className="bg-white rounded-2xl border border-line shadow-card p-5 mb-6">
              <span className="text-caption font-bold uppercase tracking-widest text-muted">{t("call.estimate")}</span>
              <div className="font-extrabold text-[32px] text-primary mt-1">
                <MoneyRange from={diagnosis.from} to={diagnosis.to} />
              </div>
            </div>
            <Btn
              size="lg" className="w-full"
              onClick={() =>
                replace("booking", { techId, serviceKey: params?.serviceKey, fromVideo: { from: diagnosis.from, to: diagnosis.to, note: lang === "ar" ? diagnosis.ar : diagnosis.en } })
              }
            >
              {t("call.bookWithEstimate")}
            </Btn>
            <button onClick={() => pop()} className="tap w-full text-center text-muted text-sub2 mt-4 py-2">
              {t("common.cancel")}
            </button>
          </motion.div>
        </div>
      </div>
    );
  }

  // ── Call phase ──
  return (
    <div className="flex-1 flex flex-col bg-night relative overflow-hidden">
      {/* remote (simulated) */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1c2333] via-[#141C26] to-[#0d1219]" />
        <motion.div
          animate={{ scale: [1, 1.04, 1] }}
          transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
          className="relative"
        >
          <Avatar name={name} src={tech?.user?.avatar} color={tech?.user?.avatarColor} size={120} />
          {/* speaking bars */}
          <div className="absolute -bottom-8 start-1/2 -translate-x-1/2 flex items-end gap-1 h-4">
            {[0, 1, 2, 3].map((i) => (
              <span key={i} className="w-1 rounded-full bg-primary-light animate-speak" style={{ height: "100%", animationDelay: `${i * 0.15}s` }} />
            ))}
          </div>
        </motion.div>
        <div className="mt-14 text-center px-6">
          <div className="text-white font-bold text-h2">{name}</div>
          <div className="text-white/60 text-sub2 mt-1">{t("call.diagnosisSub")}</div>
        </div>
      </div>

      {/* status chip */}
      <div className="relative z-10 flex justify-center pt-2">
        <span className="flex items-center gap-2 bg-black/35 text-white text-caption font-semibold px-3.5 py-1.5 rounded-pill backdrop-blur">
          {phase === "connecting" ? (
            <><span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" /> {t("call.connecting")}</>
          ) : (
            <><span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> {t("call.live")} · {mmss}</>
          )}
        </span>
      </div>

      {/* local preview */}
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="absolute z-20 top-16 end-5 w-[110px] h-[150px] rounded-2xl overflow-hidden bg-black/60 border-2 border-white/20 shadow-float"
      >
        {hasCam && !camOff ? (
          <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover" style={{ transform: "scaleX(-1)" }} />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-white/50 gap-2">
            <VideoOff size={22} />
            <span className="text-caption">{t("call.camera")}</span>
          </div>
        )}
      </motion.div>

      <p className="absolute z-10 bottom-28 inset-x-0 text-center text-white/40 text-caption">{t("call.simulated")}</p>

      {/* controls */}
      <div className="relative z-20 mt-auto pb-10 flex justify-center gap-4">
        <CtrlBtn active={muted} onClick={() => setMuted(!muted)}>
          {muted ? <MicOff size={20} /> : <Mic size={20} />}
        </CtrlBtn>
        <CtrlBtn active={camOff} onClick={() => setCamOff(!camOff)}>
          <VideoOff size={20} />
        </CtrlBtn>
        <button
          onClick={endCall}
          className="tap w-16 h-16 rounded-full bg-[#e5484d] flex items-center justify-center text-white shadow-float active:scale-95 transition-transform"
        >
          <PhoneOff size={24} />
        </button>
        <CtrlBtn onClick={() => {}}>
          <Camera size={20} />
        </CtrlBtn>
        <CtrlBtn onClick={() => {}}>
          <Mic size={20} opacity={0} />
        </CtrlBtn>
      </div>
    </div>
  );
}

function CtrlBtn({ children, active, onClick }: any) {
  return (
    <button
      onClick={onClick}
      className={`tap w-13 h-13 rounded-full flex items-center justify-center text-white transition-colors ${
        active ? "bg-white text-ink" : "bg-white/15 backdrop-blur"
      }`}
      style={{ width: 52, height: 52 }}
    >
      {children}
    </button>
  );
}

function MoneyRange({ from, to }: { from: number; to: number }) {
  const { t } = useApp();
  return <span>{t("common.egp")} {from.toLocaleString()} – {to.toLocaleString()}</span>;
}
