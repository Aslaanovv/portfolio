import { useMemo, useState } from "react";
import { ShoppingBag, MapPin, Truck } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Btn, EmptyState, Field, Header, Money } from "@/ui";
import { IconByName } from "@/ui";
import type { DeliveryOrder } from "@/types";

export default function CartScreen() {
  const { catalog, me, cart, setCart, t, lang, toast } = useApp();
  const { push } = useNav();
  const [placing, setPlacing] = useState(false);
  const [address, setAddress] = useState(me?.address || "");

  const detailed = useMemo(
    () =>
      cart
        .map((c) => {
          for (const s of catalog?.stores || []) {
            const p = s.products.find((x) => x.id === c.productId);
            if (p) return { ...p, qty: c.qty, store: s };
          }
          return null;
        })
        .filter(Boolean) as any[],
    [cart, catalog]
  );

  // group by store — one delivery per store
  const byStore = useMemo(() => {
    const map = new Map<string, { store: any; items: any[] }>();
    for (const item of detailed) {
      if (!map.has(item.store.id)) map.set(item.store.id, { store: item.store, items: [] });
      map.get(item.store.id)!.items.push(item);
    }
    return [...map.values()];
  }, [detailed]);

  const totals = byStore.map((g) => ({
    store: g.store,
    subtotal: g.items.reduce((s, i) => s + i.price * i.qty, 0),
    fee: g.store.deliveryFee,
  }));
  const grand = totals.reduce((s, g) => s + g.subtotal + g.fee, 0);

  const place = async () => {
    setPlacing(true);
    try {
      for (const g of byStore) {
        await api.post<{ delivery: DeliveryOrder }>("/api/deliveries", {
          storeId: g.store.id,
          items: g.items.map((i) => ({ productId: i.id, qty: i.qty })),
          address,
        });
      }
      setCart([]);
      toast(t("market.orderPlaced"), "success");
      push("market");
    } catch {
      toast(t("common.error"), "error");
      setPlacing(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <Header title={t("market.cart")} />
      {cart.length === 0 ? (
        <EmptyState
          icon={ShoppingBag}
          title={t("market.cartEmpty")}
          body={t("market.cartEmptyBody")}
          actionLabel={t("market.browseStores")}
          onAction={() => push("market")}
        />
      ) : (
        <>
          <div className="flex-1 overflow-y-auto no-scrollbar px-5 py-4">
            {byStore.map((g) => (
              <div key={g.store.id} className="mb-5">
                <div className="flex items-center gap-2.5 mb-2.5">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-[11px] font-extrabold" style={{ background: g.store.logoColor }}>
                    {g.store.logoText}
                  </div>
                  <span className="font-bold text-sub1 text-ink">{lang === "ar" ? g.store.nameAr : g.store.name}</span>
                </div>
                <div className="bg-white rounded-2xl border border-line shadow-card divide-y divide-line">
                  {g.items.map((i) => (
                    <div key={i.id} className="flex items-center gap-3 p-3">
                      <div className="w-14 h-14 rounded-xl overflow-hidden bg-lavender shrink-0">
                        {i.image ? (
                          <img src={i.image} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center" style={{ background: (i.tint || "#E4E1FF") + "55" }}>
                            <IconByName name={i.icon} size={20} className="text-primary-deep/70" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sub2 text-ink truncate">{lang === "ar" ? i.nameAr : i.name}</div>
                        <div className="text-caption text-muted">
                          {i.qty} × <Money amount={i.price} />
                        </div>
                      </div>
                      <Money amount={i.price * i.qty} className="font-bold text-sub2 text-ink shrink-0" />
                    </div>
                  ))}
                </div>
              </div>
            ))}

            <Field icon={MapPin} label={t("market.deliveryTo")} value={address} onChange={(e: any) => setAddress(e.target.value)} />

            <div className="bg-lavender rounded-2xl p-4 mt-4 space-y-2">
              {totals.map((g) => (
                <div key={g.store.id} className="flex justify-between text-body2 text-muted">
                  <span>{lang === "ar" ? g.store.nameAr : g.store.name}</span>
                  <span><Money amount={g.subtotal} /> + <Money amount={g.fee} /> {t("market.deliveryFlat")}</span>
                </div>
              ))}
              <div className="flex justify-between pt-2 border-t border-primary-light/50">
                <span className="font-bold text-sub1 text-ink flex items-center gap-1.5"><Truck size={14} className="text-primary" /> {t("market.total")}</span>
                <Money amount={grand} className="font-extrabold text-h3 text-primary" />
              </div>
            </div>
          </div>

          <div className="shrink-0 bg-white border-t border-line px-5 py-3 pb-5">
            <Btn size="lg" className="w-full" loading={placing} onClick={place}>
              {t("market.placeOrder")} · <Money amount={grand} />
            </Btn>
          </div>
        </>
      )}
    </div>
  );
}
