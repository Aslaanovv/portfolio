import { useEffect, useState } from "react";
import { BadgeCheck, Clock, MessageCircle, Briefcase, Award } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, Btn, Header, Money, SkeletonCard, Stars, fmtDate } from "@/ui";
import type { PublicTechnician, ReviewItem, ServiceDef } from "@/types";

const VideoCallIcon = (props: any) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="m22 8-6 4 6 4V8Z" /><rect width="14" height="12" x="2" y="6" rx="2" />
  </svg>
);

export default function TechnicianProfileScreen({ id }: { id: string }) {
  const { t, lang } = useApp();
  const { push } = useNav();
  const [data, setData] = useState<{ technician: PublicTechnician; reviews: ReviewItem[]; services: ServiceDef[] } | null>(null);

  useEffect(() => {
    api.get(`/api/technicians/${id}`).then(setData).catch(() => {});
  }, [id]);

  if (!data) {
    return (
      <div className="flex-1 flex flex-col">
        <Header />
        <div className="px-5 space-y-4 pt-2"><SkeletonCard h={110} /><SkeletonCard h={200} /><SkeletonCard h={160} /></div>
      </div>
    );
  }

  const { technician: tech, reviews, services } = data;
  const name = (lang === "ar" ? tech.user?.nameAr : tech.user?.name) || "";

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <Header title={name} />
      <div className="flex-1 overflow-y-auto no-scrollbar px-5 pt-4 pb-6">
        {/* identity card */}
        <div className="bg-white rounded-2xl border border-line shadow-card p-5 mb-4">
          <div className="flex items-center gap-4">
            <Avatar name={name} src={tech.user?.avatar} color={tech.user?.avatarColor} size={76} ring />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-h2 text-ink truncate">{name}</span>
                {tech.verified && <BadgeCheck size={18} className="text-primary shrink-0" />}
              </div>
              <div className="text-sub2 text-muted mb-1.5">
                {tech.professions.map((p) => t(`home.cat${p.charAt(0).toUpperCase() + p.slice(1)}`)).join(" · ")}
              </div>
              <Stars value={tech.rating} count={tech.ratingCount} size={13} />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 mt-5">
            <div className="bg-lavender rounded-card py-3 text-center">
              <div className="font-extrabold text-h3 text-ink">{tech.completedJobs}</div>
              <div className="text-caption text-muted">{t("tech.jobsDone")}</div>
            </div>
            <div className="bg-lavender rounded-card py-3 text-center">
              <div className="font-extrabold text-h3 text-ink">{tech.experienceYears}</div>
              <div className="text-caption text-muted">{t("tech.yearsExp")}</div>
            </div>
            <div className="bg-lavender rounded-card py-3 text-center">
              <div className="font-extrabold text-h3 text-ink"><Money amount={tech.visitFee} /></div>
              <div className="text-caption text-muted">{t("tech.visitFee")}</div>
            </div>
          </div>
        </div>

        {/* about */}
        <h3 className="font-bold text-h3 text-ink mb-2">{t("tech.about")}</h3>
        <p className="text-body1 text-muted leading-relaxed mb-5">
          {lang === "ar" ? tech.bioAr : tech.bio}
        </p>

        {/* services */}
        <h3 className="font-bold text-h3 text-ink mb-3">{t("tech.services")}</h3>
        <div className="space-y-2.5 mb-5">
          {services.map((s) => (
            <button
              key={s.key}
              onClick={() => push("booking", { techId: id, serviceKey: s.key })}
              className="tap w-full bg-white rounded-card border border-line shadow-card px-4 py-3.5 flex items-center gap-3 text-start"
            >
              <div className="w-9 h-9 rounded-xl bg-primary-lighter/60 flex items-center justify-center shrink-0">
                <Briefcase size={15} className="text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sub1 text-ink truncate">{lang === "ar" ? s.ar : s.en}</div>
                <div className="text-caption text-muted flex items-center gap-1">
                  <Clock size={10} /> ~{s.minutes} {t("common.min")}
                </div>
              </div>
              <div className="text-end shrink-0">
                <div className="text-caption text-muted">{t("common.from")}</div>
                <div className="font-bold text-sub1 text-primary"><Money amount={s.from} /></div>
              </div>
            </button>
          ))}
        </div>

        {/* reviews */}
        <h3 className="font-bold text-h3 text-ink mb-3">
          {t("tech.reviews")} <span className="text-muted font-normal text-sub2">({reviews.length})</span>
        </h3>
        <div className="space-y-3 pb-2">
          {reviews.map((r) => (
            <div key={r.id} className="bg-white rounded-card border border-line p-4">
              <div className="flex items-center gap-3 mb-2">
                <Avatar name={r.author?.name || "?"} color={r.author?.avatarColor} size={34} />
                <div className="flex-1">
                  <div className="font-semibold text-sub2 text-ink">
                    {(lang === "ar" ? r.author?.nameAr : r.author?.name) || "?"}
                  </div>
                  <div className="text-caption text-muted">{fmtDate(r.at, lang)}</div>
                </div>
                <Stars value={r.stars} size={11} showValue={false} />
              </div>
              {r.comment && <p className="text-body2 text-muted leading-relaxed">{r.comment}</p>}
            </div>
          ))}
          {reviews.length === 0 && <p className="text-center text-muted text-sub2 py-8">{t("tech.noReviews")}</p>}
        </div>
      </div>

      {/* CTA bar */}
      <div className="shrink-0 bg-white border-t border-line px-5 py-3 pb-5 grid grid-cols-3 gap-2.5">
        <Btn
          variant="secondary"
          icon={MessageCircle}
          onClick={async () => {
            const { conversationId } = await api.post("/api/conversations", { withUserId: id });
            push("chat", { conversationId, withUserId: id });
          }}
        >
          {t("tech.message")}
        </Btn>
        <Btn variant="ghost" icon={VideoCallIcon} onClick={() => push("video", { techId: id })}>
          {t("tech.videoDiagnosis")}
        </Btn>
        <Btn icon={Award} onClick={() => push("booking", { techId: id })}>
          {t("tech.bookNow")}
        </Btn>
      </div>
    </div>
  );
}
