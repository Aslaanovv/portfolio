import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Btn } from "@/ui";
import type { Booking } from "@/types";

export default function BookingSuccess({ params }: { params?: { booking: Booking } }) {
  const { t, lang } = useApp();
  const { reset, push } = useNav();
  const booking = params?.booking;
  const techName = ((lang === "ar" ? booking?.technician?.nameAr : booking?.technician?.name) || "");

  return (
    <div className="flex-1 flex flex-col bg-paper overflow-y-auto no-scrollbar">
      <div className="brand-gradient px-6 pt-16 pb-12 rounded-b-[2.5rem] text-center text-white relative overflow-hidden">
        <motion.div
          initial={{ scale: 0, rotate: -30 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", damping: 12, stiffness: 200 }}
          className="mx-auto w-20 h-20 rounded-full bg-white/15 backdrop-blur flex items-center justify-center mb-5"
        >
          <CheckCircle2 size={40} />
        </motion.div>
        <motion.h2 initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="font-extrabold text-[30px]">
          {t("booking.success")}
        </motion.h2>
        <motion.p initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="text-white/85 text-sub1 mt-2 max-w-[280px] mx-auto leading-relaxed">
          {t("booking.successBody", { name: techName })}
        </motion.p>
        <span className="absolute -end-8 -bottom-10 opacity-10"><CheckCircle2 size={160} /></span>
      </div>

      {booking && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="px-5 -mt-6">
          <div className="bg-white rounded-2xl border border-line shadow-card p-5 mb-6">
            <div className="flex items-center justify-between mb-3">
              <span className="font-mono text-caption text-muted">#{booking.id}</span>
              <span className="bg-peach/20 text-[#b06a2a] text-caption font-bold px-2.5 py-1 rounded-pill">
                {t("status.pending")}
              </span>
            </div>
            <div className="font-semibold text-sub1 text-ink">
              {(lang === "ar" ? booking.service?.ar : booking.service?.en)}
            </div>
            <div className="text-caption text-muted mt-1">
              {new Date(booking.scheduledAt).toLocaleString(lang === "ar" ? "ar-EG" : "en-GB", {
                weekday: "long", hour: "2-digit", minute: "2-digit",
              })}
            </div>
          </div>
        </motion.div>
      )}

      <div className="px-5 pb-8 mt-auto space-y-3">
        <Btn size="lg" className="w-full" onClick={() => reset([{ name: "home" }, { name: "bookings" }, { name: "tracking", params: { id: booking?.id } }])}>
          {t("booking.trackOrder")}
        </Btn>
        <Btn size="lg" variant="secondary" className="w-full" onClick={() => reset([{ name: "home" }])}>
          {t("booking.backHome")}
        </Btn>
      </div>
    </div>
  );
}
