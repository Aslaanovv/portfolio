import { Clock, BadgeCheck } from "lucide-react";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, Money, Stars } from "@/ui";

export function TechMiniCard({ id }: { id: string }) {
  const { catalog, t, lang } = useApp();
  const { push } = useNav();
  const tech = catalog?.technicians.find((x) => x.userId === id);
  if (!tech) return null;
  return (
    <button
      onClick={() => push("technician", { id })}
      className="tap shrink-0 w-[172px] bg-white rounded-card border border-line shadow-card p-3.5 text-start"
    >
      <div className="flex items-start justify-between mb-2.5">
        <Avatar name={tech.user?.name || ""} src={tech.user?.avatar} color={tech.user?.avatarColor} size={44} />
        <span className="flex items-center gap-1 bg-lavender rounded-pill px-2 py-0.5 text-caption font-bold text-ink">
          <Clock size={10} className="text-primary" /> {tech.etaMin} {t("common.min")}
        </span>
      </div>
      <div className="flex items-center gap-1">
        <span className="font-bold text-sub1 text-ink truncate">{(lang === "ar" ? tech.user?.nameAr : tech.user?.name) || ""}</span>
        {tech.verified && <BadgeCheck size={13} className="text-primary shrink-0" />}
      </div>
      <div className="text-caption text-muted truncate mb-1.5">
        {tech.professions.map((p) => t(`home.cat${p.charAt(0).toUpperCase() + p.slice(1)}`)).join(" · ")}
      </div>
      <div className="flex items-center justify-between">
        <Stars value={tech.rating} size={11} />
        <span className="text-caption text-primary font-bold">
          <Money amount={tech.visitFee} />
        </span>
      </div>
    </button>
  );
}

export function TechListCard({ id }: { id: string }) {
  const { catalog, t, lang } = useApp();
  const { push } = useNav();
  const tech = catalog?.technicians.find((x) => x.userId === id);
  if (!tech) return null;
  return (
    <button
      onClick={() => push("technician", { id })}
      className="tap w-full bg-white rounded-card border border-line shadow-card p-4 flex items-center gap-4 text-start"
    >
      <Avatar name={tech.user?.name || ""} src={tech.user?.avatar} color={tech.user?.avatarColor} size={54} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="font-bold text-sub1 text-ink truncate">{(lang === "ar" ? tech.user?.nameAr : tech.user?.name) || ""}</span>
          {tech.verified && <BadgeCheck size={14} className="text-primary shrink-0" />}
        </div>
        <div className="text-caption text-muted truncate mb-1">
          {tech.professions.map((p) => t(`home.cat${p.charAt(0).toUpperCase() + p.slice(1)}`)).join(" · ")}
        </div>
        <div className="flex items-center gap-3">
          <Stars value={tech.rating} count={tech.ratingCount} size={11} />
          <span className="text-caption text-muted flex items-center gap-1">
            <Clock size={11} /> ~{tech.etaMin} {t("common.min")}
          </span>
        </div>
      </div>
      <div className="text-end shrink-0">
        <div className="text-caption text-muted">{t("tech.visitFee")}</div>
        <div className="font-bold text-sub1 text-primary">
          <Money amount={tech.visitFee} />
        </div>
      </div>
    </button>
  );
}
