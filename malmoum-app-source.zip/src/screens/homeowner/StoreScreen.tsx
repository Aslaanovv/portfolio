import { Plus, Minus, Clock, Star, ShoppingBag } from "lucide-react";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Btn, Header, Money, Stars } from "@/ui";
import { IconByName } from "@/ui";

export default function StoreScreen({ id }: { id: string }) {
  const { catalog, t, lang, cart, setCart, toast } = useApp();
  const { push } = useNav();
  const store = catalog?.stores.find((s) => s.id === id);
  if (!store) return <div className="flex-1 flex flex-col"><Header /></div>;

  const qtyOf = (pid: string) => cart.find((c) => c.productId === pid)?.qty || 0;
  const add = (pid: string) => {
    setCart((c) => {
      const ex = c.find((x) => x.productId === pid);
      return ex ? c.map((x) => (x.productId === pid ? { ...x, qty: x.qty + 1 } : x)) : [...c, { productId: pid, qty: 1 }];
    });
    toast(t("market.addToCart") + " ✓", "success");
  };
  const dec = (pid: string) =>
    setCart((c) => c.map((x) => (x.productId === pid ? { ...x, qty: x.qty - 1 } : x)).filter((x) => x.qty > 0));

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <Header title={lang === "ar" ? store.nameAr : store.name} />
      <div className="flex-1 overflow-y-auto no-scrollbar px-5 pt-4 pb-6">
        {/* store hero */}
        <div className="rounded-2xl overflow-hidden mb-5 relative brand-gradient p-5 text-white">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/15 backdrop-blur flex items-center justify-center text-white font-extrabold text-xl border border-white/25">
              {store.logoText}
            </div>
            <div>
              <div className="font-extrabold text-h2">{lang === "ar" ? store.nameAr : store.name}</div>
              <div className="flex items-center gap-3 mt-1 text-caption text-white/85">
                <span className="flex items-center gap-1"><Star size={11} className="fill-white" /> {store.rating} ({store.ratingCount})</span>
                <span className="flex items-center gap-1"><Clock size={11} /> {store.etaMin} {t("common.min")}</span>
              </div>
            </div>
          </div>
          <span className="absolute -end-5 -bottom-7 opacity-15"><ShoppingBag size={110} /></span>
        </div>

        <h3 className="font-bold text-h3 text-ink mb-3">{t("store.products")}</h3>
        <div className="grid grid-cols-2 gap-3">
          {store.products.map((p) => {
            const q = qtyOf(p.id);
            return (
              <div key={p.id} className={`bg-white rounded-2xl border border-line shadow-card overflow-hidden ${!p.inStock ? "opacity-60" : ""}`}>
                <div className="h-28 bg-lavender relative">
                  {p.image ? (
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover" loading="lazy" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center" style={{ background: (p.tint || "#E4E1FF") + "55" }}>
                      <IconByName name={p.icon} size={34} className="text-primary-deep/70" />
                    </div>
                  )}
                  {!p.inStock && (
                    <div className="absolute inset-0 bg-white/60 flex items-center justify-center">
                      <span className="bg-ink text-white text-caption font-bold px-3 py-1 rounded-pill">{t("market.outOfStock")}</span>
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <div className="font-semibold text-sub2 text-ink leading-snug line-clamp-2 min-h-[2.4em]">
                    {lang === "ar" ? p.nameAr : p.name}
                  </div>
                  <div className="flex items-center gap-1 mt-1 mb-2">
                    <Star size={10} className="fill-amber-400 text-amber-400" />
                    <span className="text-caption text-muted">{p.rating} ({p.ratingCount})</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <Money amount={p.price} className="font-extrabold text-sub1 text-primary" />
                    {p.inStock && (q === 0 ? (
                      <button onClick={() => add(p.id)} className="tap w-8 h-8 rounded-xl bg-primary text-white flex items-center justify-center shadow-pin active:scale-95">
                        <Plus size={15} />
                      </button>
                    ) : (
                      <div className="flex items-center gap-1 bg-primary rounded-xl px-1 h-8">
                        <button onClick={() => dec(p.id)} className="tap w-7 h-7 flex items-center justify-center text-white"><Minus size={13} /></button>
                        <span className="text-white font-bold text-sub2 w-4 text-center">{q}</span>
                        <button onClick={() => add(p.id)} className="tap w-7 h-7 flex items-center justify-center text-white"><Plus size={13} /></button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {cartCount > 0 && (
        <div className="shrink-0 bg-white border-t border-line px-5 py-3 pb-5">
          <Btn size="lg" className="w-full" icon={ShoppingBag} onClick={() => push("cart")}>
            {t("market.checkout")} · {cartCount}
          </Btn>
        </div>
      )}
    </div>
  );
}
