import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { CalendarDays, SearchX } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, Btn, EmptyState, Money, SkeletonCard, StatusPill, fmtDateTime } from "@/ui";
import type { Booking } from "@/types";

const ACTIVE_STATUSES = ["pending", "accepted", "enroute", "inprogress"];

export default function BookingsScreen() {
  const { me, t, lang } = useApp();
  const { push } = useNav();
  const [tab, setTab] = useState<"upcoming" | "history">("upcoming");
  const [bookings, setBookings] = useState<Booking[] | null>(null);

  useEffect(() => {
    let alive = true;
    const load = () =>
      api.get<{ bookings: Booking[] }>("/api/bookings").then((d) => alive && setBookings(d.bookings)).catch(() => {});
    load();
    const id = setInterval(load, 5000);
    return () => { alive = false; clearInterval(id); };
  }, []);

  const active = (bookings || []).filter((b) => ACTIVE_STATUSES.includes(b.status));
  const past = (bookings || []).filter((b) => !ACTIVE_STATUSES.includes(b.status));
  const list = tab === "upcoming" ? active : past;

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <div className="shrink-0 px-5 pt-4 pb-3 bg-paper">
        <h1 className="font-extrabold text-h1 text-ink mb-4">{t("tab.bookings")}</h1>
        <div className="bg-lavender rounded-pill p-1 flex">
          {(["upcoming", "history"] as const).map((k) => (
            <button
              key={k}
              onClick={() => setTab(k)}
              className={`tap flex-1 h-9 rounded-pill text-sub2 font-semibold transition-all relative ${
                tab === k ? "bg-white text-primary shadow-card" : "text-muted"
              }`}
            >
              {t(`bookings.${k}`)}
              {k === "upcoming" && active.length > 0 && (
                <span className="absolute top-1 end-2 w-4.5 h-4.5 min-w-[18px] h-[18px] rounded-full bg-coral text-white text-[10px] font-bold flex items-center justify-center px-1">
                  {active.length}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-5 pb-6">
        {bookings === null ? (
          <div className="space-y-3 pt-2"><SkeletonCard h={120} /><SkeletonCard h={120} /><SkeletonCard h={120} /></div>
        ) : list.length === 0 ? (
          <EmptyState
            icon={CalendarDays}
            title={t("bookings.empty")}
            body={t("bookings.emptyBody")}
            actionLabel={t("bookings.findTech")}
            onAction={() => push("home")}
          />
        ) : (
          <div className="space-y-3 pt-2">
            {list.map((b, i) => (
              <motion.button
                key={b.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => push("tracking", { id: b.id })}
                className="tap w-full bg-white rounded-card border border-line shadow-card p-4 text-start"
              >
                <div className="flex items-center justify-between mb-3">
                  <StatusPill status={b.status} />
                  <span className="font-mono text-caption text-muted">{b.id}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Avatar
                    name={(lang === "ar" ? b.technician?.nameAr : b.technician?.name) || "?"}
                    src={b.technician?.avatar}
                    color={b.technician?.avatarColor}
                    size={44}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-sub1 text-ink truncate">
                      {(lang === "ar" ? b.service?.ar : b.service?.en)}
                    </div>
                    <div className="text-caption text-muted truncate">
                      {b.technician ? (lang === "ar" ? b.technician.nameAr : b.technician.name) : ""} · {fmtDateTime(b.scheduledAt, lang)}
                    </div>
                  </div>
                  <div className="text-end shrink-0">
                    {b.finalPrice ? (
                      <Money amount={b.finalPrice} className="font-bold text-sub1 text-ink" />
                    ) : (
                      <span className="text-caption text-muted font-semibold">
                        <Money amount={b.estimateMin} />+
                      </span>
                    )}
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
