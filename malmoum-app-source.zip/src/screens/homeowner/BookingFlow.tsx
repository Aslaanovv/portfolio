import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CalendarDays, Clock, MapPin, StickyNote, Wallet, Check, ChevronLeft, ChevronRight, Video } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, Btn, Field, Header, Money, Stars, fmtDate, fmtTime } from "@/ui";
import type { Booking } from "@/types";

// 4-step booking: Service → Schedule → Address → Confirm
export default function BookingFlow({ params }: { params?: { techId: string; serviceKey?: string; fromVideo?: { from: number; to: number; note: string } } }) {
  const { catalog, me, t, lang, toast } = useApp();
  const { pop, replace } = useNav();
  const [step, setStep] = useState(params?.serviceKey ? 1 : 0);
  const [serviceKey, setServiceKey] = useState<string | null>(params?.serviceKey || null);
  const [dayOffset, setDayOffset] = useState(0); // 0 today, 1 tomorrow, 2…
  const [slot, setSlot] = useState<string | null>(null);
  const [address, setAddress] = useState(me?.address || "");
  const [notes, setNotes] = useState(params?.fromVideo ? params.fromVideo.note : "");
  const [placing, setPlacing] = useState(false);

  const tech = catalog?.technicians.find((x) => x.userId === params?.techId);
  const services = useMemo(
    () => (catalog?.services || []).filter((s) => tech?.professions.includes(s.profession)),
    [catalog, tech]
  );
  const service = services.find((s) => s.key === serviceKey);
  const name = ((lang === "ar" ? tech?.user?.nameAr : tech?.user?.name) || "");

  const SLOTS = ["09:00", "11:00", "13:00", "15:00", "17:00", "19:00"];
  const days = [0, 1, 2, 3].map((i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return d;
  });

  if (!tech) return <div className="flex-1" />;

  const estimate = params?.fromVideo || (service ? { from: service.from, to: service.to, note: "" } : null);
  const scheduledAt = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + dayOffset);
    if (slot) {
      const [h, m] = slot.split(":").map(Number);
      d.setHours(h, m, 0, 0);
    } else {
      d.setHours(d.getHours() + 2, 0, 0, 0);
    }
    return d.getTime();
  }, [dayOffset, slot]);

  const canNext = step === 0 ? !!serviceKey : step === 1 ? true : step === 2 ? address.trim().length > 4 : true;

  const place = async () => {
    setPlacing(true);
    try {
      const { booking } = await api.post<{ booking: Booking }>("/api/bookings", {
        technicianId: tech.userId,
        serviceKey,
        notes,
        address,
        district: me?.district,
        scheduledAt,
        videoCallDone: !!params?.fromVideo,
      });
      replace("bookingSuccess", { booking });
    } catch {
      toast(t("common.error"), "error");
      setPlacing(false);
    }
  };

  const steps = [t("booking.step1"), t("booking.step2"), t("booking.step3"), t("booking.step4")];

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <Header title={t("booking.title", { name })} />

      {/* progress */}
      <div className="px-5 pt-4 pb-2 bg-paper">
        <div className="flex items-center gap-1.5 mb-3">
          {steps.map((_, i) => (
            <div key={i} className={`h-1.5 flex-1 rounded-full transition-colors ${i <= step ? "bg-primary" : "bg-line"}`} />
          ))}
        </div>
        <div className="flex items-center gap-3">
          <Avatar name={name} src={tech.user?.avatar} color={tech.user?.avatarColor} size={36} />
          <div>
            <div className="font-bold text-sub1 text-ink leading-tight">{name}</div>
            <Stars value={tech.rating} size={10} />
          </div>
          {params?.fromVideo && (
            <span className="ms-auto flex items-center gap-1 bg-primary-lighter/60 text-primary text-caption font-bold px-2.5 py-1 rounded-pill">
              <Video size={11} /> {t("tech.videoDiagnosis")} ✓
            </span>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-5 py-4">
        <AnimatePresence mode="wait">
          <motion.div key={step} initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} transition={{ duration: 0.22 }}>
            {/* STEP 0 — service */}
            {step === 0 && (
              <div>
                <h3 className="font-bold text-h3 text-ink mb-3">{t("booking.selectService")}</h3>
                <div className="space-y-2.5">
                  {services.map((s) => (
                    <button
                      key={s.key}
                      onClick={() => setServiceKey(s.key)}
                      className={`tap w-full rounded-card border-[1.5px] px-4 py-3.5 text-start transition-all ${
                        serviceKey === s.key ? "border-primary bg-primary-lighter/30 shadow-card" : "border-line bg-white"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-semibold text-sub1 text-ink">{lang === "ar" ? s.ar : s.en}</span>
                        {serviceKey === s.key && <Check size={16} className="text-primary shrink-0" />}
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-caption text-muted">
                        <span className="flex items-center gap-1"><Clock size={10} /> ~{s.minutes} {t("common.min")}</span>
                        <span className="font-bold text-primary"><Money amount={s.from} /> – {s.to.toLocaleString()}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* STEP 1 — schedule */}
            {step === 1 && (
              <div>
                <h3 className="font-bold text-h3 text-ink mb-3">{t("booking.when")}</h3>
                <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 mb-4">
                  {days.map((d, i) => (
                    <button
                      key={i}
                      onClick={() => setDayOffset(i)}
                      className={`tap shrink-0 w-[64px] rounded-card border-[1.5px] py-2.5 text-center transition-all ${
                        dayOffset === i ? "border-primary bg-primary text-white shadow-pin" : "border-line bg-white text-ink"
                      }`}
                    >
                      <div className="text-caption opacity-80">{i === 0 ? t("common.today") : i === 1 ? t("common.tomorrow") : fmtDate(d.getTime(), lang)}</div>
                      <div className="font-extrabold text-h2">{d.getDate()}</div>
                    </button>
                  ))}
                </div>
                <span className="block text-caption font-semibold uppercase tracking-wide text-muted mb-2">{t("booking.timeSlot")}</span>
                <div className="grid grid-cols-3 gap-2.5">
                  {SLOTS.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSlot(s)}
                      className={`tap h-11 rounded-card border-[1.5px] font-semibold text-sub2 transition-all ${
                        slot === s ? "border-primary bg-primary text-white shadow-pin" : "border-line bg-white text-ink"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setSlot(null)}
                  className={`tap mt-3 text-sub2 font-semibold ${!slot ? "text-primary" : "text-muted"}`}
                >
                  {t("track.asap")} ({!slot ? "✓" : "2h"})
                </button>
              </div>
            )}

            {/* STEP 2 — address */}
            {step === 2 && (
              <div className="space-y-4">
                <h3 className="font-bold text-h3 text-ink">{t("booking.address")}</h3>
                <Field
                  icon={MapPin} value={address} onChange={(e: any) => setAddress(e.target.value)}
                  placeholder={t("booking.addressPlaceholder")}
                />
                <Field
                  icon={StickyNote} value={notes} onChange={(e: any) => setNotes(e.target.value)}
                  placeholder={t("booking.notesPlaceholder")}
                />
              </div>
            )}

            {/* STEP 3 — confirm */}
            {step === 3 && service && (
              <div>
                <h3 className="font-bold text-h3 text-ink mb-3">{t("booking.confirmTitle")}</h3>
                <div className="bg-white rounded-2xl border border-line shadow-card divide-y divide-line mb-4">
                  <Row label={t("booking.technician")} value={name} />
                  <Row label={t("booking.step1")} value={lang === "ar" ? service.ar : service.en} />
                  <Row label={t("booking.whenShort")} value={`${dayOffset === 0 ? t("common.today") : dayOffset === 1 ? t("common.tomorrow") : fmtDate(scheduledAt, lang)} · ${slot || fmtTime(scheduledAt, lang)}`} />
                  <Row label={t("booking.place")} value={address} small />
                  <Row label={t("booking.payment")} value={t("booking.cashOnSite")} />
                </div>
                <div className="bg-primary-lighter/40 rounded-2xl p-4">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-2 text-caption font-bold uppercase tracking-widest text-primary">
                      <Wallet size={13} /> {t("booking.estimate")}
                    </span>
                    <span className="font-extrabold text-h2 text-primary">
                      {estimate!.from.toLocaleString()} – {estimate!.to.toLocaleString()} {t("common.egp")}
                    </span>
                  </div>
                  <p className="text-caption text-muted mt-1.5">{t("booking.visitFeeNote", { fee: tech.visitFee })}</p>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* nav buttons */}
      <div className="shrink-0 bg-white border-t border-line px-5 py-3 pb-5 flex items-center gap-3">
        {step > 0 && (
          <Btn variant="secondary" onClick={() => setStep(step - 1)} icon={ChevronLeft} className="flip-rtl-icon" />
        )}
        {step < 3 ? (
          <Btn size="lg" className="flex-1" disabled={!canNext} onClick={() => setStep(step + 1)}>
            {t("common.next")}
            <ChevronRight size={17} className="flip-rtl" />
          </Btn>
        ) : (
          <Btn size="lg" className="flex-1" loading={placing} onClick={place} icon={CalendarDays}>
            {t("booking.confirmBooking")}
          </Btn>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, small }: { label: string; value: string; small?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-4 px-4 py-3">
      <span className="text-caption font-semibold uppercase tracking-wide text-muted pt-0.5 shrink-0">{label}</span>
      <span className={`font-semibold text-ink text-end ${small ? "text-sub2 leading-relaxed" : "text-sub1"}`}>{value}</span>
    </div>
  );
}
