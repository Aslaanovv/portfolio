import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ShoppingBag, Truck, Package, ChevronRight } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { IconByName, Money, SkeletonCard, Stars, fmtDate } from "@/ui";
import type { DeliveryOrder } from "@/types";

export default function MarketplaceScreen() {
  const { catalog, t, lang, me, cart } = useApp();
  const { push } = useNav();
  const [tab, setTab] = useState<"stores" | "deliveries">("stores");
  const [deliveries, setDeliveries] = useState<DeliveryOrder[] | null>(null);

  useEffect(() => {
    if (tab !== "deliveries") return;
    let alive = true;
    const load = () => api.get<{ deliveries: DeliveryOrder[] }>("/api/deliveries").then((d) => alive && setDeliveries(d.deliveries)).catch(() => {});
    load();
    const id = setInterval(load, 3000);
    return () => { alive = false; clearInterval(id); };
  }, [tab]);

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <div className="shrink-0 px-5 pt-4 pb-3 bg-paper">
        <div className="flex items-center justify-between mb-1">
          <h1 className="font-extrabold text-h1 text-ink">{t("market.title")}</h1>
          <button onClick={() => push("cart")} className="tap relative w-10 h-10 rounded-full bg-white border border-line shadow-card flex items-center justify-center">
            <ShoppingBag size={17} className="text-ink" />
            {cart.length > 0 && (
              <span className="absolute -top-1 -end-1 min-w-[19px] h-[19px] px-1 rounded-full bg-primary text-white text-[11px] font-bold flex items-center justify-center border-2 border-paper">
                {cart.reduce((s, i) => s + i.qty, 0)}
              </span>
            )}
          </button>
        </div>
        <p className="text-sub2 text-muted mb-4">{t("market.sub")}</p>
        <div className="bg-lavender rounded-pill p-1 flex">
          {(["stores", "deliveries"] as const).map((k) => (
            <button
              key={k}
              onClick={() => setTab(k)}
              className={`tap flex-1 h-9 rounded-pill text-sub2 font-semibold transition-all ${
                tab === k ? "bg-white text-primary shadow-card" : "text-muted"
              }`}
            >
              {t(`market.${k}`)}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-5 pb-6">
        {tab === "stores" ? (
          !catalog ? (
            <div className="space-y-3"><SkeletonCard h={110} /><SkeletonCard h={110} /><SkeletonCard h={110} /></div>
          ) : (
            <div className="grid grid-cols-1 gap-3 pt-1">
              {catalog.stores.map((s, i) => (
                <motion.button
                  key={s.id}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => push("store", { id: s.id })}
                  className="tap bg-white rounded-2xl border border-line shadow-card p-4 text-start"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-white font-extrabold text-lg" style={{ background: s.logoColor }}>
                      {s.logoText}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-h3 text-ink truncate">{lang === "ar" ? s.nameAr : s.name}</div>
                      <Stars value={s.rating} count={s.ratingCount} size={11} />
                      <div className="flex items-center gap-3 mt-1 text-caption text-muted">
                        <span className="flex items-center gap-1"><Truck size={11} /> {s.etaMin} {t("common.min")}</span>
                        <span>{s.products.length} {t("store.products")}</span>
                      </div>
                    </div>
                    <ChevronRight size={18} className="text-muted flip-rtl" />
                  </div>
                  {/* product strip */}
                  <div className="flex gap-2 mt-3.5">
                    {s.products.slice(0, 4).map((p) => (
                      <div key={p.id} className="flex-1 h-16 rounded-xl overflow-hidden bg-lavender">
                        {p.image ? (
                          <img src={p.image} alt="" className="w-full h-full object-cover" loading="lazy" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center" style={{ background: (p.tint || "#E4E1FF") + "55" }}>
                            <IconByName name={p.icon} size={22} className="text-primary-deep/70" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </motion.button>
              ))}
            </div>
          )
        ) : (
          /* deliveries */
          deliveries === null ? (
            <div className="space-y-3"><SkeletonCard h={110} /></div>
          ) : deliveries.length === 0 ? (
            <div className="flex flex-col items-center text-center py-16">
              <div className="w-16 h-16 rounded-3xl bg-primary-lighter/60 flex items-center justify-center mb-4">
                <Package size={26} className="text-primary" />
              </div>
              <p className="font-bold text-h3 text-ink mb-1">{t("market.noDeliveries")}</p>
              <button onClick={() => setTab("stores")} className="tap text-primary text-sub2 font-semibold mt-1">{t("market.browseStores")}</button>
            </div>
          ) : (
            <div className="space-y-3 pt-1">
              {deliveries.map((o) => (
                <div key={o.id} className="bg-white rounded-2xl border border-line shadow-card p-4">
                  <div className="flex items-center justify-between mb-2.5">
                    <span className="font-mono text-caption text-muted">#{o.id}</span>
                    <DeliveryStatusChip status={o.status} />
                  </div>
                  <div className="space-y-1.5 mb-3">
                    {o.items.map((it) => (
                      <div key={it.productId} className="flex justify-between text-body2">
                        <span className="text-ink truncate">{it.qty}× {(lang === "ar" ? it.nameAr : it.name)}</span>
                        <Money amount={it.price * it.qty} className="text-muted shrink-0" />
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between pt-2.5 border-t border-line">
                    <span className="text-caption text-muted">{fmtDate(o.createdAt, lang)}</span>
                    <Money amount={o.total} className="font-bold text-sub1 text-primary" />
                  </div>
                </div>
              ))}
            </div>
          )
        )}
      </div>
    </div>
  );
}

export function DeliveryStatusChip({ status }: { status: string }) {
  const { t } = useApp();
  const styles: Record<string, string> = {
    confirmed: "bg-peach/20 text-[#b06a2a]",
    preparing: "bg-primary-lighter text-primary",
    ontheway: "bg-primary/15 text-primary-dark",
    delivered: "bg-emerald-50 text-emerald-600",
    cancelled: "bg-coral/10 text-[#c05555]",
  };
  return (
    <span className={`inline-flex items-center px-2.5 h-6 rounded-pill text-caption font-semibold ${styles[status]}`}>
      {t(`dstatus.${status}`)}
    </span>
  );
}
