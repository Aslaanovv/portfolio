import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Phone, MessageCircle, MapPin, Clock, XCircle, Wrench } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, Btn, Header, Money, SkeletonCard, StarInput, StatusPill, fmtDateTime } from "@/ui";
import type { Booking } from "@/types";

const FLOW: { key: string; icon: any }[] = [
  { key: "pending", icon: Clock },
  { key: "accepted", icon: Wrench },
  { key: "enroute", icon: MapPin },
  { key: "inprogress", icon: Wrench },
  { key: "completed", icon: StarIconEmpty },
];
function StarIconEmpty(props: any) {
  return <span className="text-[13px] leading-none">★</span>;
}

const STEPS_ORDER = ["pending", "accepted", "enroute", "inprogress", "completed"];

export default function BookingTracking({ id }: { id: string }) {
  const { t, lang, toast } = useApp();
  const { push } = useNav();
  const [booking, setBooking] = useState<Booking | null>(null);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [reviewing, setReviewing] = useState(false);

  const load = () => api.get<{ bookings: Booking[] }>("/api/bookings").then((d) => {
    const b = d.bookings.find((x) => x.id === id);
    if (b) setBooking(b);
  }).catch(() => {});

  useEffect(() => {
    load();
    const iv = setInterval(load, 4000);
    return () => clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!booking) {
    return (
      <div className="flex-1 flex flex-col">
        <Header title={t("track.title", { id })} />
        <div className="p-5"><SkeletonCard h={280} /></div>
      </div>
    );
  }

  const stepIdx = STEPS_ORDER.indexOf(booking.status);
  const tech = booking.technician;

  const doCancel = async () => {
    if (!confirm(t("track.cancelSure"))) return;
    try {
      await api.patch(`/api/bookings/${booking.id}`, { action: "cancel" });
      toast(t("status.cancelled"), "success");
      load();
    } catch {
      toast(t("common.error"), "error");
    }
  };

  const submitReview = async () => {
    setReviewing(true);
    try {
      await api.post(`/api/bookings/${booking.id}/review`, { stars: rating || 5, comment });
      toast(t("track.thanksReview"), "success");
      load();
    } catch {
      toast(t("common.error"), "error");
    } finally {
      setReviewing(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <Header title={t("track.title", { id: booking.id })} right={<StatusPill status={booking.status} />} />
      <div className="flex-1 overflow-y-auto no-scrollbar px-5 py-4">
        {/* service header */}
        <div className="bg-white rounded-2xl border border-line shadow-card p-4 mb-4">
          <div className="font-bold text-h3 text-ink">{lang === "ar" ? booking.service?.ar : booking.service?.en}</div>
          <div className="text-sub2 text-muted mt-1 flex items-center gap-1.5">
            <Clock size={12} /> {t("track.scheduledFor")} {fmtDateTime(booking.scheduledAt, lang)}
          </div>
          <div className="text-caption text-muted mt-1 flex items-start gap-1.5">
            <MapPin size={12} className="mt-0.5 shrink-0" /> {booking.address}
          </div>
          {booking.notes && (
            <div className="mt-2 text-caption text-muted bg-lavender rounded-xl px-3 py-2 leading-relaxed">"{booking.notes}"</div>
          )}
        </div>

        {/* timeline */}
        {["declined", "cancelled"].includes(booking.status) ? (
          <div className="bg-coral/10 border border-coral/30 rounded-2xl p-4 mb-4 text-center">
            <XCircle size={22} className="mx-auto text-[#c05555] mb-1.5" />
            <p className="font-bold text-sub1 text-[#c05555]">{t(`status.${booking.status}`)}</p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-line shadow-card p-5 mb-4">
            <h3 className="font-bold text-sub1 text-ink mb-4">{t("track.timeline")}</h3>
            <div className="relative">
              {FLOW.map((s, i) => {
                const done = booking.status !== "pending" ? i <= Math.max(stepIdx, 0) && i <= stepIdx : i === 0;
                const isCurrent = i === stepIdx;
                const at = booking.timeline.find((tl) => tl.status === s.key)?.at;
                return (
                  <div key={s.key} className="flex gap-3.5 pb-5 last:pb-0 relative">
                    {i < FLOW.length - 1 && (
                      <span className={`absolute start-[13px] top-7 bottom-0 w-0.5 ${i < stepIdx ? "bg-primary" : "bg-line"}`} />
                    )}
                    <div
                      className={`relative z-10 w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-all ${
                        done ? "bg-primary text-white" : "bg-lavender text-muted"
                      } ${isCurrent ? "ring-4 ring-primary/20" : ""}`}
                    >
                      {isCurrent && booking.status !== "completed" ? (
                        <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                      ) : done ? (
                        <span className="text-[11px]">✓</span>
                      ) : (
                        <s.icon size={13} />
                      )}
                    </div>
                    <div className="flex-1 pt-0.5">
                      <div className={`font-semibold text-sub2 ${done ? "text-ink" : "text-muted/70"}`}>
                        {t(`track.${s.key === "pending" ? "requested" : s.key}`)}
                      </div>
                      {at && <div className="text-caption text-muted">{fmtDateTime(at, lang)}</div>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* technician card */}
        {tech && (
          <div className="bg-white rounded-2xl border border-line shadow-card p-4 mb-4">
            <div className="flex items-center gap-3.5">
              <Avatar name={tech.name} src={tech.avatar} color={tech.avatarColor} size={52} />
              <div className="flex-1 min-w-0">
                <div className="font-bold text-sub1 text-ink truncate">{(lang === "ar" ? tech.nameAr : tech.name)}</div>
                <div className="text-caption text-muted">~{tech.etaMin} {t("common.min")} · ★ {tech.rating.toFixed(1)}</div>
              </div>
              <a href={`tel:${tech.phone}`} className="tap w-10 h-10 rounded-full bg-primary-lighter/60 text-primary flex items-center justify-center">
                <Phone size={16} />
              </a>
              {booking.conversationId && (
                <button
                  onClick={() => push("chat", { conversationId: booking.conversationId, withUserId: tech.id })}
                  className="tap w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center shadow-pin"
                >
                  <MessageCircle size={16} />
                </button>
              )}
            </div>
          </div>
        )}

        {/* total */}
        {booking.status === "completed" && (
          <div className="bg-lavender rounded-2xl p-4 mb-4 flex items-center justify-between">
            <span className="font-semibold text-sub1 text-ink">{t("track.totalPaid")}</span>
            <Money amount={booking.finalPrice || booking.estimateMax} className="font-extrabold text-h2 text-ink" />
          </div>
        )}

        {/* review */}
        {booking.status === "completed" && !booking.review && (
          <div className="bg-white rounded-2xl border border-line shadow-card p-5 mb-4">
            <h3 className="font-bold text-h3 text-ink mb-4 text-center">{t("track.rateTitle")}</h3>
            <StarInput value={rating} onChange={setRating} />
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder={t("track.ratePlaceholder")}
              rows={2}
              className="w-full mt-4 rounded-card border-[1.5px] border-line px-4 py-3 text-body2 text-ink placeholder:text-muted/60 outline-none focus:border-primary resize-none"
            />
            <Btn size="lg" className="w-full mt-3" loading={reviewing} disabled={!rating} onClick={submitReview}>
              {t("track.submitReview")}
            </Btn>
          </div>
        )}
        {booking.review && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-4">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-amber-500">{"★".repeat(booking.review.stars)}</span>
              <span className="text-caption text-amber-600 font-semibold">{t("track.thanksReview")}</span>
            </div>
            {booking.review.comment && <p className="text-body2 text-ink/70">{booking.review.comment}</p>}
          </div>
        )}

        {/* cancel */}
        {["pending", "accepted"].includes(booking.status) && (
          <Btn variant="danger" className="w-full" icon={XCircle} onClick={doCancel}>
            {t("track.cancelBooking")}
          </Btn>
        )}
      </div>
    </div>
  );
}
