import { useMemo, useState, type ReactNode } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MapPin, ChevronDown, List, Map as MapIcon, Gift, Wrench, Zap, Hammer, Wind, PaintRoller,
  WashingMachine, Star, Clock, BadgeCheck, ShoppingBag, MessageCircle,
} from "lucide-react";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, Btn, Chip, IconByName, Money, SearchBar, Sheet, SkeletonCard, Stars } from "@/ui";
import { MapViewport } from "@/MapCanvas";
import { TechMiniCard, TechListCard } from "./TechCards";

const CAT_ICONS: Record<string, any> = {
  plumbing: Wrench, electrical: Zap, carpentry: Hammer, ac: Wind, painting: PaintRoller, appliance: WashingMachine,
};

export default function HomeScreen() {
  const { me, catalog, t, lang } = useApp();
  const { push, reset } = useNav();
  const [view, setView] = useState<"map" | "list">("map");
  const [tab, setTab] = useState<"workers" | "stores">("workers");
  const [filter, setFilter] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [selectedTech, setSelectedTech] = useState<string | null>(null);
  const [selectedStore, setSelectedStore] = useState<string | null>(null);

  const district = catalog?.districts.find((d) => d.id === (me?.district || "nasr"));

  const techs = useMemo(() => {
    if (!catalog) return [];
    return catalog.technicians
      .filter((tt) => tt.available)
      .filter((tt) => !filter || filter === "all" || tt.professions.includes(filter as any))
      .filter((tt) => {
        if (!query.trim()) return true;
        const q = query.toLowerCase();
        const nm = (lang === "ar" ? tt.user?.nameAr : tt.user?.name) || "";
        return nm.toLowerCase().includes(q) || tt.professions.some((p) => t(p).toLowerCase().includes(q)) || t(`home.cat${pascal(tt.professions[0])}`).toLowerCase().includes(q);
      })
      .sort((a, b) => b.rating - a.rating);
  }, [catalog, filter, query, lang, t]);

  const stores = useMemo(() => {
    if (!catalog) return [];
    return catalog.stores.filter((s) => !query.trim() || (lang === "ar" ? s.nameAr : s.name).toLowerCase().includes(query.toLowerCase()));
  }, [catalog, query, lang]);

  const selTech = catalog?.technicians.find((x) => x.userId === selectedTech);
  const selStore = catalog?.stores.find((x) => x.id === selectedStore);

  if (!catalog) {
    return (
      <div className="flex-1 flex flex-col px-5 pt-2 gap-4">
        <SkeletonCard h={44} />
        <SkeletonCard h={300} />
        <SkeletonCard h={120} />
      </div>
    );
  }

  const cats = [{ id: "all", label: t("home.catAll"), icon: null }, ...catalog.professions.map((p) => ({ id: p.id, label: lang === "ar" ? p.ar : p.en, icon: CAT_ICONS[p.id] }))];

  return (
    <div className="flex-1 flex flex-col min-h-0 relative">
      {/* ── Header overlay ── */}
      <div className="absolute top-0 inset-x-0 z-30 px-5 pt-3 pb-4 bg-gradient-to-b from-paper via-paper/95 to-transparent">
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={() => setTab(tab === "workers" ? "stores" : "workers")}
            className="tap flex items-center gap-1.5"
          >
            <MapPin size={16} className="text-primary" />
            <div className="text-start">
              <div className="text-caption text-muted leading-none">{t("home.location")}</div>
              <div className="flex items-center gap-1 font-bold text-h3 text-ink leading-tight">
                {district ? (lang === "ar" ? district.ar : district.en) : "Nasr City"}
                <ChevronDown size={15} className="text-primary" />
              </div>
            </div>
          </button>
          <div className="flex items-center gap-2">
            <button onClick={() => push("market")} className="tap relative w-10 h-10 rounded-full bg-white border border-line shadow-card flex items-center justify-center">
              <ShoppingBag size={17} className="text-ink" />
              <span className="absolute -top-0.5 -end-0.5 w-2.5 h-2.5 rounded-full bg-coral border-2 border-white" />
            </button>
            <button
              onClick={() => setView(view === "map" ? "list" : "map")}
              className="tap w-10 h-10 rounded-full bg-white border border-line shadow-card flex items-center justify-center"
            >
              {view === "map" ? <List size={16} className="text-ink" /> : <MapIcon size={16} className="text-ink" />}
            </button>
          </div>
        </div>
        <SearchBar value={query} onChange={setQuery} placeholder={t("home.searchPlaceholder")} />

        {/* segmented workers | stores */}
        <div className="mt-3 flex justify-center">
          <div className="bg-white border border-line rounded-pill p-1 flex shadow-card w-full max-w-[260px]">
            {(["workers", "stores"] as const).map((k) => (
              <button
                key={k}
                onClick={() => { setTab(k); setSelectedTech(null); setSelectedStore(null); }}
                className={`tap flex-1 h-8 rounded-pill text-sub2 font-semibold transition-all ${
                  tab === k ? "bg-primary text-white shadow-pin" : "text-muted"
                }`}
              >
                {t(`home.${k}`)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── Content ── */}
      {view === "map" ? (
        <>
          <div className="flex-1 min-h-0 relative">
            <MapViewport
              catalog={catalog}
              selectedId={tab === "workers" ? selectedTech : selectedStore}
              showStores={tab === "stores"}
              filter={tab === "workers" ? filter : null}
              onSelect={(id) => setSelectedTech(id)}
              onStoreSelect={(id) => setSelectedStore(id)}
            />
            {/* category chips */}
            {tab === "workers" && (
              <div className="absolute top-2 inset-x-0 z-20 px-5 flex gap-2 overflow-x-auto no-scrollbar">
                {cats.map((c) => (
                  <Chip key={c.id} active={filter === c.id || (c.id === "all" && !filter)} icon={c.icon}
                    onClick={() => setFilter(c.id === "all" ? null : c.id)}>
                    {c.label}
                  </Chip>
                ))}
              </div>
            )}
          </div>

          {/* bottom card carousel */}
          <div className="shrink-0 bg-paper border-t border-line pt-3 pb-2">
            {tab === "workers" ? (
              <div className="flex gap-3 overflow-x-auto no-scrollbar px-5 pb-2">
                {(techs.length ? techs : catalog.technicians.filter((x) => x.available)).slice(0, 6).map((tech) => (
                  <TechMiniCard key={tech.userId} id={tech.userId} />
                ))}
              </div>
            ) : (
              <div className="flex gap-3 overflow-x-auto no-scrollbar px-5 pb-2">
                {stores.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => push("store", { id: s.id })}
                    className="tap shrink-0 w-[200px] bg-white rounded-card border border-line shadow-card p-3.5 text-start"
                  >
                    <div className="flex items-center gap-3 mb-2.5">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center text-white font-extrabold text-[14px]" style={{ background: s.logoColor }}>
                        {s.logoText}
                      </div>
                      <div className="min-w-0">
                        <div className="font-bold text-sub1 text-ink truncate">{lang === "ar" ? s.nameAr : s.name}</div>
                        <Stars value={s.rating} count={s.ratingCount} />
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-caption text-muted">
                      <span className="flex items-center gap-1"><Clock size={12} /> {s.etaMin} {t("common.min")}</span>
                      <span className="font-semibold text-primary">{t("market.openStore")} →</span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </>
      ) : (
        /* ── List view ── */
        <div className="flex-1 min-h-0 overflow-y-auto no-scrollbar px-5 pt-[168px] pb-4">
          {tab === "workers" ? (
            <>
              {/* special offers banner */}
              <div className="brand-gradient rounded-2xl p-4 mb-5 flex items-center gap-4 text-white relative overflow-hidden">
                <div className="w-12 h-12 rounded-2xl bg-white/15 flex items-center justify-center shrink-0">
                  <Gift size={22} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-h3">{t("home.specialOffers")}</div>
                  <div className="text-caption text-white/85">{t("home.specialOffersBody")}</div>
                </div>
                <span className="absolute -end-4 -bottom-5 opacity-20"><Gift size={80} /></span>
              </div>
              <h3 className="font-bold text-h3 text-ink mb-3">{t("home.nearbyTechs")}</h3>
              <div className="space-y-3">
                {techs.map((tech) => (
                  <TechListCard key={tech.userId} id={tech.userId} />
                ))}
                {techs.length === 0 && (
                  <p className="text-center text-muted text-sub2 py-10">{t("home.noResults")}</p>
                )}
              </div>
            </>
          ) : (
            <>
              <h3 className="font-bold text-h3 text-ink mb-3">{t("home.storesNearby")}</h3>
              <div className="space-y-3">
                {stores.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => push("store", { id: s.id })}
                    className="tap w-full bg-white rounded-card border border-line shadow-card p-4 flex items-center gap-4 text-start"
                  >
                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-white font-extrabold" style={{ background: s.logoColor }}>
                      {s.logoText}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-sub1 text-ink">{lang === "ar" ? s.nameAr : s.name}</div>
                      <div className="text-caption text-muted mb-1">
                        {t(`home.${s.category === "paint" ? "catpainting" : s.category === "plumbing" ? "catplumbing" : s.category === "electrical" ? "catelectrical" : "catcarpentry"}`)}
                      </div>
                      <div className="flex items-center gap-3">
                        <Stars value={s.rating} count={s.ratingCount} />
                        <span className="text-caption text-muted flex items-center gap-1"><Clock size={11} /> {s.etaMin} {t("common.min")}</span>
                      </div>
                    </div>
                    <span className="text-primary font-bold text-sub2">→</span>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* ── Technician bottom sheet ── */}
      <Sheet open={!!selTech} onClose={() => setSelectedTech(null)}>
        {selTech && (
          <div className="pb-2">
            <div className="flex items-center gap-4 mb-5">
              <Avatar name={selTech.user?.name || ""} src={selTech.user?.avatar} color={selTech.user?.avatarColor} size={64} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-h2 text-ink truncate">{(lang === "ar" ? selTech.user?.nameAr : selTech.user?.name) || ""}</span>
                  {selTech.verified && <BadgeCheck size={17} className="text-primary shrink-0" />}
                </div>
                <div className="text-sub2 text-muted mb-1">
                  {selTech.professions.map((p) => t(`home.cat${pascal(p)}`)).join(" · ")}
                </div>
                <div className="flex items-center gap-3">
                  <Stars value={selTech.rating} count={selTech.ratingCount} />
                  <span className="text-caption text-muted flex items-center gap-1">
                    <Clock size={11} /> ~{selTech.etaMin} {t("common.min")}
                  </span>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 mb-5">
              <Stat label={String(selTech.completedJobs)} sub={t("tech.jobsDone")} />
              <Stat label={String(selTech.experienceYears)} sub={t("tech.yearsExp")} />
              <Stat label={<Money amount={selTech.visitFee} />} sub={t("tech.visitFee")} />
            </div>
            <div className="grid grid-cols-3 gap-2.5">
              <Btn
                variant="secondary"
                onClick={() => { setSelectedTech(null); push("chat", { withUserId: selTech.userId }); }}
                icon={MessageCircle}
              >
                {t("tech.message")}
              </Btn>
              <Btn
                variant="ghost"
                onClick={() => { setSelectedTech(null); push("video", { techId: selTech.userId }); }}
                icon={VideoCallIcon}
              >
                {t("tech.videoDiagnosis")}
              </Btn>
              <Btn onClick={() => { setSelectedTech(null); push("booking", { techId: selTech.userId }); }}>
                {t("tech.bookNow")}
              </Btn>
            </div>
          </div>
        )}
      </Sheet>

      {/* ── Store bottom sheet ── */}
      <Sheet open={!!selStore} onClose={() => setSelectedStore(null)}>
        {selStore && (
          <div className="pb-2">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-white font-extrabold text-xl" style={{ background: selStore.logoColor }}>
                {selStore.logoText}
              </div>
              <div>
                <div className="font-bold text-h2 text-ink">{lang === "ar" ? selStore.nameAr : selStore.name}</div>
                <Stars value={selStore.rating} count={selStore.ratingCount} />
                <div className="text-caption text-muted mt-1">
                  {selStore.products.length} {t("store.products")} · {selStore.etaMin} {t("common.min")}
                </div>
              </div>
            </div>
            <div className="flex -space-x-3 mb-5 rtl:space-x-reverse">
              {selStore.products.slice(0, 5).map((p) => (
                <div key={p.id} className="w-14 h-14 rounded-xl border-[3px] border-white overflow-hidden bg-lavender shadow-card">
                  {p.image ? (
                    <img src={p.image} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center" style={{ background: (p.tint || "#E4E1FF") + "55" }}>
                      <IconByName name={p.icon} size={20} className="text-primary-deep" />
                    </div>
                  )}
                </div>
              ))}
            </div>
            <Btn size="lg" className="w-full" onClick={() => { setSelectedStore(null); push("store", { id: selStore.id }); }}>
              {t("market.openStore")}
            </Btn>
          </div>
        )}
      </Sheet>
    </div>
  );
}

function pascal(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function Stat({ label, sub }: { label: React.ReactNode; sub: string }) {
  return (
    <div className="bg-lavender rounded-card py-3 text-center">
      <div className="font-extrabold text-h3 text-ink truncate px-1">{label}</div>
      <div className="text-caption text-muted">{sub}</div>
    </div>
  );
}

const VideoCallIcon = (props: any) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="m22 8-6 4 6 4V8Z" /><rect width="14" height="12" x="2" y="6" rx="2" />
  </svg>
);

