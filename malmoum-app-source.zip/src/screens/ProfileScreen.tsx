import { useEffect, useState } from "react";
import {
  MapPin, Globe, LogOut, Repeat, Info, BadgeCheck, Star, Pencil, Check,
} from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, Btn, Field, Money, Sheet, Stars } from "@/ui";
import { Wordmark } from "@/PhoneShell";

export default function ProfileScreen() {
  const { me, tech, t, lang, setLang, logout, demoLogin, toast, refreshMe, catalog } = useApp();
  const { reset, push } = useNav();
  const [confirmLogout, setConfirmLogout] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", address: "", bio: "", visitFee: 80, etaMin: 30 });

  useEffect(() => {
    if (me) setForm({
      name: me.name, phone: me.phone, address: me.address || "",
      bio: tech ? (lang === "ar" ? tech.bioAr : tech.bio) : "",
      visitFee: tech?.visitFee || 80, etaMin: tech?.etaMin || 30,
    });
  }, [me, tech, lang]);

  if (!me) return <div className="flex-1" />;
  const name = (lang === "ar" ? me.nameAr : me.name) || me.name;
  const isTech = me.role === "technician";

  const save = async () => {
    try {
      const body: any = { name: form.name, phone: form.phone, address: form.address };
      if (isTech) {
        body.visitFee = Number(form.visitFee);
        body.etaMin = Number(form.etaMin);
        if (lang === "ar") body.bioAr = form.bio; else body.bio = form.bio;
      }
      await api.patch("/api/me", body);
      await refreshMe();
      setEditOpen(false);
      toast(t("profile.saved"), "success");
    } catch {
      toast(t("common.error"), "error");
    }
  };

  const switchRole = async () => {
    await demoLogin(isTech ? "homeowner" : "technician");
    reset([{ name: isTech ? "home" : "techhome" }]);
  };

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <div className="flex-1 overflow-y-auto no-scrollbar pb-6">
        {/* header card */}
        <div className="brand-gradient px-5 pt-8 pb-16 rounded-b-[2.2rem] text-white relative overflow-hidden">
          <div className="flex items-center gap-4">
            <Avatar name={name} src={me.avatar} color={me.avatarColor} size={70} ring />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-h2 truncate">{name}</span>
                {isTech && tech?.verified && <BadgeCheck size={17} className="text-white/90 shrink-0" />}
              </div>
              <div className="text-white/80 text-caption" dir="ltr">{me.phone}</div>
              {isTech && tech && (
                <div className="text-white/85 text-caption mt-0.5">
                  {t("t.ratingsAndJobs", { rating: tech.rating.toFixed(1), jobs: tech.completedJobs })}
                </div>
              )}
            </div>
            <button onClick={() => setEditOpen(true)} className="tap ms-auto w-10 h-10 rounded-full bg-white/15 backdrop-blur flex items-center justify-center shrink-0">
              <Pencil size={16} />
            </button>
          </div>
          <span className="absolute -end-6 -bottom-9 opacity-10"><Info size={130} /></span>
        </div>

        <div className="px-5 -mt-10">
          {/* address */}
          <div className="bg-white rounded-2xl border border-line shadow-card p-4 mb-3 flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-primary-lighter/60 flex items-center justify-center shrink-0">
              <MapPin size={17} className="text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-caption text-muted">{t("profile.myAddresses")}</div>
              <div className="font-semibold text-sub2 text-ink truncate">{me.address || "—"}</div>
            </div>
          </div>

          {/* language */}
          <div className="bg-white rounded-2xl border border-line shadow-card p-4 mb-3 flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-primary-lighter/60 flex items-center justify-center shrink-0">
              <Globe size={17} className="text-primary" />
            </div>
            <div className="flex-1">
              <div className="text-caption text-muted">{t("profile.language")}</div>
              <div className="font-semibold text-sub2 text-ink">{lang === "en" ? "English" : "العربية"}</div>
            </div>
            <button
              onClick={() => setLang(lang === "en" ? "ar" : "en")}
              className="tap h-9 px-4 rounded-pill bg-primary text-white text-caption font-bold"
            >
              {lang === "en" ? "العربية" : "English"}
            </button>
          </div>

          {/* my bookings shortcut (homeowner) */}
          {!isTech && (
            <button
              onClick={() => push("bookings")}
              className="tap w-full bg-white rounded-2xl border border-line shadow-card p-4 mb-3 flex items-center gap-3.5 text-start"
            >
              <div className="w-10 h-10 rounded-xl bg-primary-lighter/60 flex items-center justify-center shrink-0">
                <Star size={17} className="text-primary" />
              </div>
              <div className="flex-1 font-semibold text-sub1 text-ink">{t("profile.myBookings")}</div>
              <span className="text-muted">›</span>
            </button>
          )}

          {/* tech public profile shortcut */}
          {isTech && (
            <button
              onClick={() => push("technician", { id: me.id })}
              className="tap w-full bg-white rounded-2xl border border-line shadow-card p-4 mb-3 flex items-center gap-3.5 text-start"
            >
              <div className="w-10 h-10 rounded-xl bg-primary-lighter/60 flex items-center justify-center shrink-0">
                <BadgeCheck size={17} className="text-primary" />
              </div>
              <div className="flex-1 font-semibold text-sub1 text-ink">{t("t.viewProfile")}</div>
              <span className="text-muted">›</span>
            </button>
          )}

          {/* demo switch */}
          <button
            onClick={switchRole}
            className="tap w-full bg-white rounded-2xl border-[1.5px] border-dashed border-primary/40 p-4 mb-3 flex items-center gap-3.5 text-start"
          >
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Repeat size={17} className="text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-sub1 text-ink">{t("profile.switchDemo")}</div>
              <div className="text-caption text-muted leading-snug">{t("profile.switchDemoBody")}</div>
            </div>
            <span className="shrink-0 bg-primary text-white text-caption font-bold px-3 py-1.5 rounded-pill">
              {isTech ? t("role.homeowner") : t("role.technician")}
            </span>
          </button>

          {/* about */}
          <div className="bg-white rounded-2xl border border-line shadow-card p-4 mb-3">
            <div className="flex items-center gap-3.5 mb-2">
              <div className="w-10 h-10 rounded-xl bg-primary-lighter/60 flex items-center justify-center shrink-0">
                <Info size={17} className="text-primary" />
              </div>
              <div className="font-semibold text-sub1 text-ink">{t("profile.about")}</div>
            </div>
            <div className="ps-[52px]">
              <p className="text-caption text-muted leading-relaxed">
                {t("auth.onboard3.body")}
              </p>
              <div className="mt-2" style={{ direction: "ltr" }}>
                <Wordmark size={22} />
              </div>
            </div>
          </div>

          <Btn variant="danger" className="w-full mt-2" icon={LogOut} onClick={() => setConfirmLogout(true)}>
            {t("profile.logout")}
          </Btn>

          <p className="text-center text-caption text-muted/70 mt-4">
            {t("profile.memberSince", { date: new Date(me.id === "u-home" ? Date.now() - 30 * 86400000 : Date.now()).toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { month: "long", year: "numeric" }) })}
          </p>
        </div>
      </div>

      {/* logout confirm */}
      <Sheet open={confirmLogout} onClose={() => setConfirmLogout(false)}>
        <div className="pb-4 text-center">
          <p className="font-bold text-h3 text-ink mb-5">{t("profile.logoutSure")}</p>
          <div className="grid grid-cols-2 gap-3">
            <Btn variant="secondary" onClick={() => setConfirmLogout(false)}>{t("common.cancel")}</Btn>
            <Btn variant="danger" onClick={() => { logout(); setConfirmLogout(false); reset([{ name: "auth" }]); }}>
              {t("profile.logout")}
            </Btn>
          </div>
        </div>
      </Sheet>

      {/* edit sheet */}
      <Sheet open={editOpen} onClose={() => setEditOpen(false)} title={t("profile.editProfile")}>
        <div className="space-y-4 pb-4">
          <Field label={t("auth.fullName")} value={form.name} onChange={(e: any) => setForm({ ...form, name: e.target.value })} />
          <Field label={t("auth.phone")} value={form.phone} dir="ltr" onChange={(e: any) => setForm({ ...form, phone: e.target.value })} />
          <Field label={t("booking.address")} value={form.address} onChange={(e: any) => setForm({ ...form, address: e.target.value })} />
          {isTech && (
            <>
              <Field label={t("tech.about")} value={form.bio} onChange={(e: any) => setForm({ ...form, bio: e.target.value })} />
              <div className="grid grid-cols-2 gap-3">
                <Field label={t("tech.visitFee")} type="number" value={form.visitFee} dir="ltr" onChange={(e: any) => setForm({ ...form, visitFee: e.target.value })} />
                <Field label={t("home.eta")} type="number" value={form.etaMin} dir="ltr" onChange={(e: any) => setForm({ ...form, etaMin: e.target.value })} />
              </div>
            </>
          )}
          <Btn size="lg" className="w-full" icon={Check} onClick={save}>{t("profile.saveChanges")}</Btn>
        </div>
      </Sheet>
    </div>
  );
}
