import { useEffect } from "react";
import { motion } from "framer-motion";
import { useApp } from "../AppContext";
import { useNav } from "../navigation";
import { Wordmark } from "../PhoneShell";

export default function Splash() {
  const { me, catalog } = useApp();
  const { reset } = useNav();

  useEffect(() => {
    const id = setTimeout(() => {
      if (me) {
        reset([{ name: me.role === "technician" ? "techhome" : "home" }]);
      } else {
        reset([{ name: "auth" }]);
      }
    }, 2100);
    return () => clearTimeout(id);
  }, [me, reset, catalog]);

  return (
    <div className="flex-1 brand-gradient flex flex-col items-center justify-center relative overflow-hidden">
      {/* decorative circles */}
      <motion.div
        initial={{ scale: 0, opacity: 0.4 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1.2, ease: "easeOut" }}
        className="absolute -top-24 -start-24 w-72 h-72 rounded-full bg-white/8"
      />
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 1.4, delay: 0.15, ease: "easeOut" }}
        className="absolute -bottom-28 -end-20 w-80 h-80 rounded-full bg-primary-light/20"
      />

      <motion.div
        initial={{ scale: 0.6, opacity: 0, y: 30 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ type: "spring", damping: 16, stiffness: 200, delay: 0.15 }}
        className="relative z-10 text-center"
      >
        <div style={{ direction: "ltr" }}>
          <Wordmark size={64} light />
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.5 }}
        className="relative z-10 mt-8 text-white/85 text-sub1"
      >
        Technicians · Stores · Delivery
      </motion.div>

      {/* loading dots */}
      <div className="absolute bottom-16 flex gap-2">
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            animate={{ scale: [1, 1.5, 1], opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 1, repeat: Infinity, delay: i * 0.18 }}
            className="w-2 h-2 rounded-full bg-white"
          />
        ))}
      </div>
    </div>
  );
}
