import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { SendHorizonal, Phone } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, Header, fmtTime } from "@/ui";
import { useAutoScroll } from "@/ui";
import type { ChatMessage } from "@/types";

const QUICK = ["quick1", "quick2", "quick3"];

export default function ChatScreen({ params }: { params?: { conversationId?: string; withUserId?: string } }) {
  const { me, t, lang, catalog } = useApp();
  const { replace } = useNav();
  const [messages, setMessages] = useState<ChatMessage[] | null>(null);
  const [text, setText] = useState("");
  const [convId, setConvId] = useState<string | null>(params?.conversationId || null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  // ensure conversation exists when opened from a profile
  useEffect(() => {
    if (!convId && params?.withUserId) {
      api.post("/api/conversations", { withUserId: params.withUserId })
        .then((d) => setConvId(d.conversationId))
        .catch(() => {});
    }
  }, [convId, params?.withUserId]);

  // poll messages
  useEffect(() => {
    if (!convId) return;
    let alive = true;
    const load = () =>
      api.get<{ messages: ChatMessage[] }>(`/api/conversations/${convId}/messages`)
        .then((d) => alive && setMessages(d.messages))
        .catch(() => {});
    load();
    const id = setInterval(load, 2200);
    return () => { alive = false; clearInterval(id); };
  }, [convId]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messages?.length]);

  const counterpart = (() => {
    const withUserId = params?.withUserId;
    if (withUserId) {
      const tech = catalog?.technicians.find((x) => x.userId === withUserId);
      if (tech?.user) return { name: tech.user.name, nameAr: tech.user.nameAr, avatar: tech.user.avatar, color: tech.user.avatarColor, id: tech.userId };
    }
    return null;
  })();

  const send = async (msg?: string) => {
    const body = (msg ?? text).trim();
    if (!body || !convId) return;
    setText("");
    // optimistic
    setMessages((m) => [...(m || []), { id: "tmp" + Date.now(), conversationId: convId, fromId: me?.id || "", text: body, at: Date.now(), kind: "text" }]);
    try {
      await api.post(`/api/conversations/${convId}/messages`, { text: body });
    } catch {}
    const d = await api.get<{ messages: ChatMessage[] }>(`/api/conversations/${convId}/messages`);
    setMessages(d.messages);
  };

  const name = ((lang === "ar" ? counterpart?.nameAr : counterpart?.name) || "");

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <Header
        title={
          counterpart ? (
            <span className="flex items-center gap-2.5">
              <Avatar name={name || "?"} src={counterpart.avatar} color={counterpart.color} size={32} />
              <span className="truncate">{name}</span>
            </span>
          ) : (
            t("tab.messages")
          )
        }
        right={
          counterpart ? (
            <a href={`tel:+201005551010`} className="tap w-9 h-9 rounded-full bg-primary-lighter/60 text-primary flex items-center justify-center">
              <Phone size={15} />
            </a>
          ) : undefined
        }
      />

      <div ref={scrollRef} className="flex-1 overflow-y-auto no-scrollbar px-4 py-4 bg-lavender/60">
        {messages === null ? (
          <div className="text-center text-muted text-caption py-10">{t("common.loading")}</div>
        ) : (
          <div className="space-y-2">
            <AnimatePresence initial={false}>
              {messages.map((m) =>
                m.kind === "system" ? (
                  <motion.div key={m.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex justify-center py-1.5">
                    <span className="bg-white/80 border border-line text-muted text-caption px-3.5 py-1.5 rounded-pill text-center max-w-[85%]">
                      {m.text}
                    </span>
                  </motion.div>
                ) : (
                  <motion.div
                    key={m.id}
                    initial={{ opacity: 0, y: 10, scale: 0.97 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    className={`flex ${m.fromId === me?.id ? "justify-end" : "justify-start"}`}
                  >
                    <div className={`max-w-[78%] px-3.5 py-2.5 ${m.fromId === me?.id ? "bubble-me" : "bubble-them shadow-card"}`}>
                      <p className="text-body2 leading-relaxed break-words">{m.text}</p>
                      <div className={`text-[10px] mt-1 text-end ${m.fromId === me?.id ? "text-white/60" : "text-muted/70"}`}>
                        {fmtTime(m.at, lang)}
                      </div>
                    </div>
                  </motion.div>
                )
              )}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* quick replies */}
      {messages?.length === 0 && (
        <div className="shrink-0 px-4 pb-2 flex gap-2 overflow-x-auto no-scrollbar">
          {QUICK.map((q) => (
            <button key={q} onClick={() => send(t(`messages.${q}`))} className="tap shrink-0 h-8 px-3.5 rounded-pill bg-white border border-primary/30 text-primary text-caption font-semibold">
              {t(`messages.${q}`)}
            </button>
          ))}
        </div>
      )}

      {/* composer */}
      <div className="shrink-0 bg-white border-t border-line px-3 py-2.5 pb-4 flex items-center gap-2">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder={t("messages.typePlaceholder")}
          className="flex-1 h-11 rounded-pill bg-lavender border border-line px-4 text-body2 text-ink placeholder:text-muted/60 outline-none focus:border-primary"
        />
        <button
          onClick={() => send()}
          disabled={!text.trim()}
          className={`tap w-11 h-11 rounded-full flex items-center justify-center shrink-0 transition-all ${
            text.trim() ? "bg-primary text-white shadow-pin" : "bg-lavender text-muted"
          }`}
        >
          <SendHorizonal size={17} className="flip-rtl" />
        </button>
      </div>
    </div>
  );
}
