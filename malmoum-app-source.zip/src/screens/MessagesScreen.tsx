import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, EmptyState, SkeletonCard, fmtTime } from "@/ui";
import type { ConversationItem } from "@/types";

export default function MessagesScreen() {
  const { t, lang } = useApp();
  const { push } = useNav();
  const [conversations, setConversations] = useState<ConversationItem[] | null>(null);

  useEffect(() => {
    let alive = true;
    const load = () =>
      api.get<{ conversations: ConversationItem[] }>("/api/conversations")
        .then((d) => alive && setConversations(d.conversations))
        .catch(() => {});
    load();
    const id = setInterval(load, 3000);
    return () => { alive = false; clearInterval(id); };
  }, []);

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <div className="shrink-0 px-5 pt-4 pb-3">
        <h1 className="font-extrabold text-h1 text-ink">{t("tab.messages")}</h1>
      </div>
      <div className="flex-1 overflow-y-auto no-scrollbar px-5 pb-6">
        {conversations === null ? (
          <div className="space-y-3"><SkeletonCard h={72} /><SkeletonCard h={72} /><SkeletonCard h={72} /></div>
        ) : conversations.length === 0 ? (
          <EmptyState icon={MessageCircle} title={t("messages.empty")} body={t("messages.emptyBody")} />
        ) : (
          <div className="space-y-1.5">
            {conversations.map((c, i) => (
              <motion.button
                key={c.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                onClick={() => push("chat", { conversationId: c.id, withUserId: c.counterpart?.id })}
                className="tap w-full flex items-center gap-3.5 p-3 rounded-2xl hover:bg-white text-start"
              >
                <div className="relative">
                  <Avatar
                    name={c.counterpart?.name || "?"}
                    src={c.counterpart?.avatar}
                    color={c.counterpart?.avatarColor}
                    size={50}
                  />
                  {c.counterpart?.role === "technician" && (
                    <span className="absolute -bottom-0.5 -end-0.5 w-4 h-4 rounded-full bg-primary border-2 border-paper flex items-center justify-center">
                      <WrenchTiny />
                    </span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-sub1 text-ink truncate">
                      {((lang === "ar" ? c.counterpart?.nameAr : c.counterpart?.name) || "")}
                    </span>
                    {c.lastMessage && <span className="text-caption text-muted shrink-0">{fmtTime(c.lastMessage.at, lang)}</span>}
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className={`text-sub2 truncate ${c.unread ? "font-semibold text-ink" : "text-muted"}`}>
                      {c.lastMessage?.kind === "system" ? c.lastMessage.text : c.lastMessage?.text || "…"}
                    </span>
                    {c.unread > 0 && (
                      <span className="shrink-0 min-w-[19px] h-[19px] px-1.5 rounded-full bg-primary text-white text-[11px] font-bold flex items-center justify-center">
                        {c.unread}
                      </span>
                    )}
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const WrenchTiny = () => (
  <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
  </svg>
);
