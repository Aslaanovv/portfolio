import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MapPinned, Video, Blocks, Globe, Wrench, Home as HomeIcon, Mail, Lock, Phone, User as UserIcon, ArrowRight } from "lucide-react";
import { useApp } from "../AppContext";
import { useNav } from "../navigation";
import { Btn, Field } from "../ui";
import { Wordmark } from "../PhoneShell";

const SLIDES = [
  { icon: MapPinned, key: "onboard1" },
  { icon: Video, key: "onboard2" },
  { icon: Blocks, key: "onboard3" },
];

export default function AuthScreen() {
  const { t, lang, setLang, login, register, demoLogin } = useApp();
  const [mode, setMode] = useState<"welcome" | "login" | "register">("welcome");
  const [slide, setSlide] = useState(0);
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", phone: "", email: "", password: "", role: "homeowner" as "homeowner" | "technician" });

  const SlideIcon = SLIDES[slide].icon;

  const run = async (label: string, fn: () => Promise<void>) => {
    setErr(null);
    setBusy(label);
    try {
      await fn();
    } catch (e: any) {
      const code = e?.message;
      setErr(code === "invalid_credentials" ? t("auth.invalid") : code === "email_exists" ? t("auth.emailTaken") : t("common.error"));
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-paper overflow-y-auto no-scrollbar relative">
      {/* language toggle */}
      <button
        onClick={() => setLang(lang === "en" ? "ar" : "en")}
        className="tap absolute top-4 end-4 z-20 flex items-center gap-1.5 h-9 px-3.5 rounded-pill bg-white border border-line shadow-card text-caption font-bold text-ink"
      >
        <Globe size={13} className="text-primary" />
        {lang === "en" ? "العربية" : "English"}
      </button>

      <AnimatePresence mode="wait">
        {mode === "welcome" ? (
          <motion.div
            key="welcome"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, y: -20 }}
            className="flex-1 flex flex-col px-7 pt-20 pb-8"
          >
            <div style={{ direction: "ltr" }} className="mb-12">
              <Wordmark size={54} />
            </div>

            {/* slide */}
            <div className="flex-1 flex flex-col justify-center min-h-[300px]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={slide}
                  initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="w-16 h-16 rounded-3xl bg-primary-lighter/70 flex items-center justify-center mb-6">
                    <SlideIcon size={28} className="text-primary" />
                  </div>
                  <h2 className="font-extrabold text-[26px] leading-snug text-ink mb-3">
                    {t(`auth.${SLIDES[slide].key}.title`)}
                  </h2>
                  <p className="text-body1 text-muted leading-relaxed">{t(`auth.${SLIDES[slide].key}.body`)}</p>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* dots */}
            <div className="flex justify-center gap-2 mb-6">
              {SLIDES.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setSlide(i)}
                  className={`h-2 rounded-full transition-all ${i === slide ? "w-7 bg-primary" : "w-2 bg-line"}`}
                />
              ))}
            </div>

            <div className="space-y-3">
              <Btn size="lg" className="w-full" onClick={() => setMode("register")}>
                {t("auth.getStarted")}
                <ArrowRight size={18} className="flip-rtl" />
              </Btn>
              <Btn size="lg" variant="secondary" className="w-full" onClick={() => setMode("login")}>
                {t("auth.iHaveAccount")}
              </Btn>

              {/* demo shortcuts */}
              <div className="pt-4">
                <div className="flex items-center gap-3 mb-3">
                  <span className="flex-1 h-px bg-line" />
                  <span className="text-caption font-semibold uppercase tracking-widest text-muted">{t("auth.demoTry")}</span>
                  <span className="flex-1 h-px bg-line" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Btn variant="ghost" loading={busy === "h"} onClick={() => run("h", () => demoLogin("homeowner"))}>
                    <HomeIcon size={16} /> {t("auth.homeowner")}
                  </Btn>
                  <Btn variant="ghost" loading={busy === "t"} onClick={() => run("t", () => demoLogin("technician"))}>
                    <Wrench size={16} /> {t("auth.technician")}
                  </Btn>
                </div>
                <p className="text-caption text-muted/80 text-center mt-3 leading-relaxed">{t("auth.twoTabsHint")}</p>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key={mode}
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}
            className="flex-1 flex flex-col px-7 pt-16 pb-8"
          >
            <h1 className="font-extrabold text-[28px] text-ink mb-1">
              {mode === "login" ? t("auth.login") : t("auth.register")}
            </h1>
            <p className="text-sub2 text-muted mb-7">
              {mode === "login" ? t("auth.welcome") + " " + t("brand.name") : t("brand.tagline") + " ✨"}
            </p>

            <div className="space-y-4 flex-1">
              {mode === "register" && (
                <>
                  <Field
                    label={t("auth.fullName")} icon={UserIcon} value={form.name}
                    onChange={(e: any) => setForm({ ...form, name: e.target.value })}
                  />
                  <Field
                    label={t("auth.phone")} icon={Phone} value={form.phone} dir="ltr" placeholder="+20 1X XXX XXXX"
                    onChange={(e: any) => setForm({ ...form, phone: e.target.value })}
                  />
                  {/* role picker */}
                  <div>
                    <span className="block text-caption font-semibold uppercase tracking-wide text-muted mb-1.5">{t("auth.iAmA")}</span>
                    <div className="grid grid-cols-2 gap-3">
                      {(["homeowner", "technician"] as const).map((r) => (
                        <button
                          key={r}
                          onClick={() => setForm({ ...form, role: r })}
                          className={`tap rounded-card border-[1.5px] p-3.5 text-start transition-all ${
                            form.role === r ? "border-primary bg-primary-lighter/40 shadow-card" : "border-line bg-white"
                          }`}
                        >
                          {r === "homeowner" ? <HomeIcon size={20} className={form.role === r ? "text-primary" : "text-muted"} /> : <Wrench size={20} className={form.role === r ? "text-primary" : "text-muted"} />}
                          <div className="font-bold text-sub1 text-ink mt-2">{t(`auth.${r}`)}</div>
                          <div className="text-caption text-muted">{t(`auth.${r}Desc`)}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
              <Field
                label={t("auth.email")} icon={Mail} type="email" value={form.email} dir="ltr"
                placeholder="you@example.com"
                onChange={(e: any) => setForm({ ...form, email: e.target.value })}
              />
              <Field
                label={t("auth.password")} icon={Lock} type="password" value={form.password} dir="ltr"
                placeholder="••••••"
                onChange={(e: any) => setForm({ ...form, password: e.target.value })}
              />

              {err && <p className="text-sub2 text-[#c0392b] bg-coral/10 rounded-card px-4 py-2.5">{err}</p>}
            </div>

            <div className="pt-5 space-y-3">
              <Btn
                size="lg" className="w-full"
                loading={!!busy}
                onClick={() =>
                  run(mode, async () => {
                    if (mode === "login") await login(form.email, form.password);
                    else {
                      if (!form.name || !form.email || !form.password) throw new Error("missing");
                      await register(form);
                    }
                  })
                }
              >
                {mode === "login" ? t("auth.login") : t("auth.register")}
              </Btn>
              <div className="flex items-center justify-between text-sub2">
                <button onClick={() => { setMode(mode === "login" ? "register" : "login"); setErr(null); }} className="tap text-primary font-semibold">
                  {mode === "login" ? t("auth.noAccount") : t("auth.haveAccount")}
                </button>
                <button onClick={() => setMode("welcome")} className="tap text-muted">
                  {t("common.back")}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
