import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Wrench, CalendarDays, Wallet, Star, TrendingUp, Bell, Video,
} from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, EmptyState, Money, SkeletonCard, Toggle, fmtDateTime } from "@/ui";
import type { Booking, TechStats } from "@/types";

export default function TechHome() {
  const { me, tech, t, lang, toast, refreshMe } = useApp();
  const { push } = useNav();
  const [stats, setStats] = useState<TechStats | null>(null);
  const [bookings, setBookings] = useState<Booking[] | null>(null);

  useEffect(() => {
    if (me?.role !== "technician") return;
    let alive = true;
    const load = async () => {
      try {
        const [s, b] = await Promise.all([
          api.get<TechStats>("/api/tech/stats"),
          api.get<{ bookings: Booking[] }>("/api/bookings"),
        ]);
        if (!alive) return;
        setStats(s);
        setBookings(b.bookings);
      } catch {}
    };
    load();
    const id = setInterval(load, 4000);
    return () => { alive = false; clearInterval(id); };
  }, [me?.role]);

  const pending = useMemo(() => (bookings || []).filter((b) => b.status === "pending"), [bookings]);
  const activeJobs = useMemo(
    () => (bookings || []).filter((b) => ["accepted", "enroute", "inprogress"].includes(b.status))
      .sort((a, b) => a.scheduledAt - b.scheduledAt),
    [bookings]
  );
  const completed = useMemo(() => (bookings || []).filter((b) => b.status === "completed"), [bookings]);

  const setAvailability = async (available: boolean) => {
    await api.patch("/api/me", { available });
    await refreshMe();
    toast(available ? t("t.availableOn") : t("t.availableOff"), "success");
  };

  if (me?.role !== "technician") {
    return <div className="flex-1 flex items-center justify-center text-muted">{t("common.loading")}</div>;
  }

  return (
    <div className="flex-1 flex flex-col min-h-0">
      {/* header */}
      <div className="shrink-0 bg-gradient-to-b from-primary to-primary-dark px-5 pt-5 pb-6 rounded-b-[2rem] text-white relative overflow-hidden">
        <div className="flex items-center justify-between mb-5">
          <div>
            <p className="text-white/75 text-caption">{t("t.dashboard")}</p>
            <h1 className="font-extrabold text-h1 leading-tight">
              {t("home.greeting", { name: (lang === "ar" ? me.nameAr : me.name)?.split(" ")[0] || "" })}
            </h1>
          </div>
          <button onClick={() => push("messages")} className="tap relative w-10 h-10 rounded-full bg-white/15 backdrop-blur flex items-center justify-center">
            <Bell size={17} />
            {pending.length > 0 && (
              <span className="absolute -top-0.5 -end-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-coral text-white text-[10px] font-bold flex items-center justify-center border-2 border-primary">
                {pending.length}
              </span>
            )}
          </button>
        </div>

        {/* stats row */}
        <div className="grid grid-cols-3 gap-2.5">
          <StatTile icon={<Wallet size={15} />} label={t("t.thisWeek")} value={stats ? <Money amount={stats.earningsWeek} /> : "…"} />
          <StatTile icon={<Wrench size={15} />} label={t("tech.jobsDone")} value={String(stats?.completedJobs ?? "…")} />
          <StatTile icon={<Star size={15} />} label={t("tech.reviews")} value={stats ? `${stats.rating.toFixed(1)} ★` : "…"} />
        </div>
        <span className="absolute -end-8 -bottom-12 opacity-10"><TrendingUp size={150} /></span>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-5 py-4">
        {/* availability */}
        <div className="bg-white rounded-2xl border border-line shadow-card p-4 mb-4 flex items-center gap-3.5">
          <span className={`relative flex w-2.5 h-2.5 shrink-0 ${tech?.available ? "" : "opacity-40"}`}>
            {tech?.available && <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping" />}
            <span className={`relative inline-flex rounded-full w-2.5 h-2.5 ${tech?.available ? "bg-emerald-500" : "bg-muted"}`} />
          </span>
          <div className="flex-1 min-w-0">
            <div className="font-bold text-sub1 text-ink">{t("t.availability")}</div>
            <div className="text-caption text-muted truncate">
              {tech?.available ? t("t.availableOn") : t("t.availableOff")}
            </div>
          </div>
          <Toggle checked={!!tech?.available} onChange={setAvailability} />
        </div>

        {/* job requests */}
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-h3 text-ink">{t("t.requests")}</h3>
          {pending.length > 0 && (
            <span className="bg-coral text-white text-caption font-bold px-2.5 py-1 rounded-pill">
              {t("t.pendingRequests", { n: pending.length })}
            </span>
          )}
        </div>
        {bookings === null ? (
          <div className="space-y-3 mb-6"><SkeletonCard h={120} /></div>
        ) : pending.length === 0 ? (
          <div className="bg-white rounded-2xl border border-dashed border-line rounded-2xl p-5 mb-6 text-center">
            <p className="font-semibold text-sub2 text-ink">{t("t.noRequests")}</p>
            <p className="text-caption text-muted mt-0.5">{t("t.noRequestsBody")}</p>
          </div>
        ) : (
          <div className="space-y-3 mb-6">
            {pending.map((b, i) => (
              <RequestCard key={b.id} booking={b} index={i} onChanged={load} />
            ))}
          </div>
        )}

        {/* today's schedule */}
        <h3 className="font-bold text-h3 text-ink mb-3">{t("t.todayJobs")}</h3>
        {activeJobs.length === 0 ? (
          <div className="bg-white rounded-2xl border border-dashed border-line p-5 text-center mb-6">
            <CalendarDays size={20} className="mx-auto text-muted mb-1.5" />
            <p className="text-caption text-muted">{t("t.noToday")}</p>
          </div>
        ) : (
          <div className="space-y-3 mb-6">
            {activeJobs.map((b) => (
              <button
                key={b.id}
                onClick={() => push("techBooking", { id: b.id })}
                className="tap w-full bg-white rounded-2xl border border-line shadow-card p-4 text-start"
              >
                <div className="flex items-center gap-3.5">
                  <Avatar
                    name={(lang === "ar" ? b.homeowner?.nameAr : b.homeowner?.name) || "?"}
                    color={b.homeowner?.avatarColor}
                    size={44}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-sub1 text-ink truncate">
                      {lang === "ar" ? b.service?.ar : b.service?.en}
                    </div>
                    <div className="text-caption text-muted truncate">
                      {(lang === "ar" ? b.homeowner?.nameAr : b.homeowner?.name)} · {fmtDateTime(b.scheduledAt, lang)}
                    </div>
                  </div>
                  <StatusChip status={b.status} />
                </div>
              </button>
            ))}
          </div>
        )}

        {/* completed history */}
        <h3 className="font-bold text-h3 text-ink mb-3">{t("t.completed")}</h3>
        <div className="space-y-2.5 pb-4">
          {completed.slice(0, 5).map((b) => (
            <button
              key={b.id}
              onClick={() => push("techBooking", { id: b.id })}
              className="tap w-full bg-white/70 rounded-2xl border border-line p-3.5 flex items-center gap-3 text-start"
            >
              <div className="w-9 h-9 rounded-xl bg-emerald-50 flex items-center justify-center shrink-0">
                <Wrench size={15} className="text-emerald-500" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sub2 text-ink truncate">{lang === "ar" ? b.service?.ar : b.service?.en}</div>
                <div className="text-caption text-muted">{fmtDateTime(b.scheduledAt, lang)}</div>
              </div>
              <Money amount={b.finalPrice || b.estimateMax} className="font-bold text-sub2 text-ink shrink-0" />
            </button>
          ))}
          {completed.length === 0 && <p className="text-caption text-muted text-center py-4">—</p>}
        </div>
      </div>
    </div>
  );

  async function load() {
    try {
      const [s, b] = await Promise.all([
        api.get<TechStats>("/api/tech/stats"),
        api.get<{ bookings: Booking[] }>("/api/bookings"),
      ]);
      setStats(s);
      setBookings(b.bookings);
    } catch {}
  }
}

function StatTile({ icon, label, value }: { icon: React.ReactNode; label: string; value: React.ReactNode }) {
  return (
    <div className="bg-white/12 backdrop-blur rounded-2xl p-3 border border-white/10">
      <div className="flex items-center gap-1.5 text-white/75 text-caption mb-1">{icon}{label}</div>
      <div className="font-extrabold text-h3 text-white truncate">{value}</div>
    </div>
  );
}

function StatusChip({ status }: { status: string }) {
  const { t } = useApp();
  const styles: Record<string, string> = {
    accepted: "bg-primary-lighter text-primary",
    enroute: "bg-primary/15 text-primary-dark",
    inprogress: "bg-primary-deep/10 text-primary-deep",
  };
  return (
    <span className={`shrink-0 inline-flex items-center px-2.5 h-6 rounded-pill text-caption font-semibold ${styles[status]}`}>
      {t(`status.${status}`)}
    </span>
  );
}

function RequestCard({ booking: b, index, onChanged }: { booking: Booking; index: number; onChanged: () => void }) {
  const { t, lang, toast } = useApp();
  const [busy, setBusy] = useState<string | null>(null);

  const act = async (action: "accept" | "decline") => {
    setBusy(action);
    try {
      await api.patch(`/api/bookings/${b.id}`, { action });
      toast(action === "accept" ? t("status.accepted") : t("status.declined"), "success");
      onChanged();
    } catch {
      toast(t("common.error"), "error");
    } finally {
      setBusy(null);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 16, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay: index * 0.06 }}
      className="bg-white rounded-2xl border-[1.5px] border-primary/30 shadow-float p-4"
    >
      <div className="flex items-center justify-between mb-3">
        <span className="font-mono text-caption text-muted">{b.id}</span>
        {b.videoCallDone ? (
          <span className="flex items-center gap-1 bg-primary-lighter/70 text-primary text-caption font-bold px-2.5 py-1 rounded-pill">
            <Video size={11} /> {t("t.videoDone")}
          </span>
        ) : (
          <span className="text-caption text-muted">{t("t.noVideo")}</span>
        )}
      </div>
      <div className="flex items-center gap-3.5 mb-3">
        <Avatar
          name={(lang === "ar" ? b.homeowner?.nameAr : b.homeowner?.name) || "?"}
          color={b.homeowner?.avatarColor}
          size={46}
        />
        <div className="flex-1 min-w-0">
          <div className="font-bold text-sub1 text-ink truncate">
            {lang === "ar" ? b.service?.ar : b.service?.en}
          </div>
          <div className="text-caption text-muted truncate">
            {t("t.requestFrom", { name: (lang === "ar" ? b.homeowner?.nameAr : b.homeowner?.name) || "" })} · {fmtDateTime(b.scheduledAt, lang)}
          </div>
        </div>
        <div className="text-end shrink-0">
          <Money amount={b.estimateMin} className="font-bold text-sub1 text-primary" />
          <div className="text-caption text-muted">– {b.estimateMax.toLocaleString()}</div>
        </div>
      </div>
      {b.notes && (
        <div className="text-caption text-muted bg-lavender rounded-xl px-3 py-2 mb-3 leading-relaxed">"{b.notes}"</div>
      )}
      <div className="grid grid-cols-2 gap-2.5">
        <button onClick={() => act("decline")} disabled={!!busy} className="tap h-11 rounded-pill border-[1.5px] border-coral/50 text-[#c05555] font-semibold text-sub2 bg-coral/5 disabled:opacity-50">
          {busy === "decline" ? "…" : t("t.decline")}
        </button>
        <button onClick={() => act("accept")} disabled={!!busy} className="tap h-11 rounded-pill bg-primary text-white font-semibold text-sub2 shadow-pin disabled:opacity-50">
          {busy === "accept" ? "…" : t("t.accept")}
        </button>
      </div>
    </motion.div>
  );
}
