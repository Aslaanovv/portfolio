import { useEffect, useState } from "react";
import { Phone, MessageCircle, MapPin, Wrench, Navigation, CheckCircle2 } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/AppContext";
import { useNav } from "@/navigation";
import { Avatar, Btn, Header, Money, SkeletonCard, StatusPill, fmtDateTime } from "@/ui";
import type { Booking } from "@/types";

const NEXT_ACTION: Record<string, { action: string; label: string; icon: any } | null> = {
  accepted: { action: "enroute", label: "t.startEnroute", icon: Navigation },
  enroute: { action: "inprogress", label: "t.startWork", icon: Wrench },
  inprogress: { action: "complete", label: "t.completeJob", icon: CheckCircle2 },
  completed: null,
};

export default function TechBookingDetail({ id }: { id: string }) {
  const { t, lang, toast } = useApp();
  const { push } = useNav();
  const [booking, setBooking] = useState<Booking | null>(null);
  const [price, setPrice] = useState("");
  const [busy, setBusy] = useState(false);

  const load = () =>
    api.get<{ bookings: Booking[] }>("/api/bookings")
      .then((d) => {
        const b = d.bookings.find((x) => x.id === id);
        if (b) {
          setBooking(b);
          setPrice((prev) => prev || String(b.finalPrice || b.estimateMax));
        }
      })
      .catch(() => {});

  useEffect(() => {
    load();
    const iv = setInterval(load, 5000);
    return () => clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!booking) {
    return (
      <div className="flex-1 flex flex-col">
        <Header title={t("t.jobDetails")} />
        <div className="p-5"><SkeletonCard h={280} /></div>
      </div>
    );
  }

  const next = NEXT_ACTION[booking.status];
  const customer = booking.homeowner;

  const act = async () => {
    if (!next) return;
    setBusy(true);
    try {
      await api.patch(`/api/bookings/${booking.id}`, {
        action: next.action,
        finalPrice: next.action === "complete" ? Number(price) || booking.estimateMax : undefined,
      });
      toast(t(`status.${next.action === "complete" ? "completed" : next.action}`), "success");
      await load();
    } catch {
      toast(t("common.error"), "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <Header title={`${t("t.jobDetails")} · ${booking.id}`} right={<StatusPill status={booking.status} />} />
      <div className="flex-1 overflow-y-auto no-scrollbar px-5 py-4">
        {/* job card */}
        <div className="bg-white rounded-2xl border border-line shadow-card p-4 mb-4">
          <div className="font-bold text-h3 text-ink">{lang === "ar" ? booking.service?.ar : booking.service?.en}</div>
          <div className="text-sub2 text-muted mt-1">{fmtDateTime(booking.scheduledAt, lang)}</div>
          {booking.notes && (
            <div className="mt-3 text-caption text-muted bg-lavender rounded-xl px-3 py-2.5 leading-relaxed">
              "{booking.notes}"
            </div>
          )}
          <div className="mt-3 pt-3 border-t border-line flex items-start gap-2 text-caption text-muted">
            <MapPin size={13} className="mt-0.5 shrink-0 text-primary" />
            <span className="leading-relaxed">{booking.address}</span>
          </div>
          <div className="mt-3 pt-3 border-t border-line flex items-center justify-between">
            <span className="text-caption font-semibold uppercase tracking-wide text-muted">{t("booking.estimate")}</span>
            <Money amount={booking.estimateMin} className="font-bold text-sub1 text-primary" />
            <span className="text-caption text-muted">–</span>
            <Money amount={booking.estimateMax} className="font-bold text-sub1 text-primary" />
          </div>
          {booking.videoCallDone && (
            <div className="mt-3 flex items-center gap-1.5 text-caption font-bold text-primary">
              📹 {t("t.videoDone")}
            </div>
          )}
        </div>

        {/* customer */}
        {customer && (
          <div className="bg-white rounded-2xl border border-line shadow-card p-4 mb-4">
            <div className="text-caption font-semibold uppercase tracking-wide text-muted mb-3">{t("t.customer")}</div>
            <div className="flex items-center gap-3.5">
              <Avatar name={customer.name} color={customer.avatarColor} size={50} />
              <div className="flex-1 min-w-0">
                <div className="font-bold text-sub1 text-ink truncate">{(lang === "ar" ? customer.nameAr : customer.name)}</div>
                <div className="text-caption text-muted" dir="ltr">{customer.phone}</div>
              </div>
              <a href={`tel:${customer.phone}`} className="tap w-10 h-10 rounded-full bg-primary-lighter/60 text-primary flex items-center justify-center">
                <Phone size={16} />
              </a>
              {booking.conversationId && (
                <button
                  onClick={() => push("chat", { conversationId: booking.conversationId, withUserId: customer.id })}
                  className="tap w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center shadow-pin"
                >
                  <MessageCircle size={16} />
                </button>
              )}
            </div>
          </div>
        )}

        {/* final price input for completion */}
        {booking.status === "inprogress" && (
          <div className="bg-white rounded-2xl border border-line shadow-card p-4 mb-4">
            <span className="block text-caption font-semibold uppercase tracking-wide text-muted mb-2">{t("t.finalPrice")}</span>
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              dir="ltr"
              className="w-full h-12 rounded-card border-[1.5px] border-line px-4 text-body1 font-bold text-ink outline-none focus:border-primary"
            />
          </div>
        )}

        {booking.status === "completed" && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between">
            <span className="font-semibold text-sub1 text-emerald-700">{t("status.completed")}</span>
            <Money amount={booking.finalPrice || booking.estimateMax} className="font-extrabold text-h3 text-emerald-700" />
          </div>
        )}
      </div>

      {/* action bar */}
      {next && (
        <div className="shrink-0 bg-white border-t border-line px-5 py-3 pb-5">
          <Btn size="lg" className="w-full" loading={busy} onClick={act} icon={next.icon}>
            {t(next.label)}
          </Btn>
        </div>
      )}
    </div>
  );
}
