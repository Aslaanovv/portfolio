import React, { useEffect, useState } from "react";
import { Signal, Wifi, BatteryFull } from "lucide-react";

// ─── Status bar (inside the phone) ─────────────────────────────────────────
export function StatusBar({ dark = false }: { dark?: boolean }) {
  const [time, setTime] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 20000);
    return () => clearInterval(id);
  }, []);
  const hhmm = time.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  const color = dark ? "text-white" : "text-ink";
  return (
    <div className={`relative z-50 flex items-center justify-between px-7 pt-3.5 pb-1 pointer-events-none ${color}`}>
      <span className="text-[13px] font-semibold tracking-wide">{hhmm}</span>
      <div className="flex items-center gap-1.5">
        <Signal size={14} strokeWidth={2.5} />
        <Wifi size={14} strokeWidth={2.5} />
        <BatteryFull size={16} strokeWidth={2} />
      </div>
    </div>
  );
}

// ─── Phone shell — device frame on desktop, full-bleed on mobile ───────────
export function PhoneShell({ children }: { children: React.ReactNode }) {
  const [isCompact, setIsCompact] = useState(() => window.innerWidth < 1024 || window.innerHeight < 760);

  useEffect(() => {
    const mq = window.matchMedia("(max-width: 1023px), (max-height: 759px)");
    const fn = () => setIsCompact(mq.matches);
    mq.addEventListener("change", fn);
    return () => mq.removeEventListener("change", fn);
  }, []);

  if (isCompact) {
    return (
      <div className="h-full w-full bg-paper relative overflow-hidden">
        <div className="absolute inset-0 flex flex-col">{children}</div>
        <div className="absolute bottom-1.5 start-1/2 -translate-x-1/2 w-32 h-1 rounded-full bg-ink/20 z-50 pointer-events-none" />
      </div>
    );
  }

  return (
    <div className="h-full w-full overflow-auto lavender-gradient flex items-center justify-center gap-16 py-10 px-6">
      {/* Left brand panel */}
      <div className="hidden xl:block max-w-[360px]">
        <Wordmark size={64} />
        <h1 className="mt-6 text-[44px] leading-[1.05] font-extrabold text-ink tracking-tight">
          Home services,
          <br />
          <span className="text-primary">finally connected.</span>
        </h1>
        <p className="mt-5 text-[16px] leading-relaxed text-muted">
          Technicians, hardware stores and delivery — one ecosystem for every fix. Find who's
          nearby on the live map, video-diagnose the problem, book with confidence.
        </p>
        <div className="mt-8 flex flex-col gap-3 text-[13.5px] text-ink/80">
          <Hint n="1">Pick the <b>homeowner</b> demo — requests land on the technician side live</Hint>
          <Hint n="2">Open a <b>second browser window</b> and log in as the technician demo</Hint>
          <Hint n="3">Flip the language to <b>العربية</b> — full RTL support</Hint>
        </div>
        <div className="mt-10 flex items-center gap-2 text-caption text-muted/70 uppercase tracking-[0.2em]">
          Graduation project · V1 MVP
        </div>
      </div>

      {/* Device */}
      <div className="phone-device shrink-0">
        <div className="phone-screen">
          <div className="dynamic-island" />
          <div className="absolute inset-0 flex flex-col">{children}</div>
          <div className="absolute bottom-1.5 start-1/2 -translate-x-1/2 w-32 h-1 rounded-full bg-ink/20 z-50 pointer-events-none" />
        </div>
      </div>
    </div>
  );
}

function Hint({ n, children }: { n: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3">
      <span className="w-7 h-7 shrink-0 rounded-full bg-primary text-white text-[12px] font-bold flex items-center justify-center">{n}</span>
      <span>{children}</span>
    </div>
  );
}

// ─── Brand wordmark ────────────────────────────────────────────────────────
export function Wordmark({ size = 40, light = false }: { size?: number; light?: boolean }) {
  return (
    <div className="select-none leading-none">
      <div
        className="font-extrabold tracking-tight lowercase"
        style={{
          fontSize: size,
          fontFamily: "'Cairo', 'Inter', sans-serif",
          color: light ? "#fff" : "#675FFF",
          letterSpacing: "-0.02em",
        }}
      >
        malmoum
        <span style={{ color: light ? "#A9A1FF" : "#A9A1FF" }}>.</span>
      </div>
      <div
        className={`font-bold uppercase ${light ? "text-white/70" : "text-ink/50"}`}
        style={{ fontSize: size * 0.2, letterSpacing: "0.42em", marginTop: size * 0.1, direction: "ltr" }}
      >
        Get it done!
      </div>
    </div>
  );
}
