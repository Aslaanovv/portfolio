import React, { useRef, useState } from "react";
import { Plus, Minus, LocateFixed, SlidersHorizontal } from "lucide-react";
import type { Catalog } from "./types";

// ─── Stylized Cairo map — hand-drawn SVG, matches the Malmoum mockup look ──
// viewBox is 0..100 so pin coordinates (mapPos %) align exactly.

const BLOCKS: [number, number, number, number][] = [
  // Heliopolis blocks (NE)
  [58, 4, 14, 9], [73, 4, 12, 9], [58, 14, 12, 8], [71, 14, 15, 8],
  [62, 23, 12, 7], [75, 23, 11, 6], [86, 12, 10, 9], [86, 22, 10, 8],
  // Nasr City grid
  [38, 26, 9, 7], [48, 26, 8, 7], [38, 34, 9, 6], [48, 34, 8, 6],
  [57, 30, 9, 6], [57, 37, 9, 5], [67, 34, 10, 7], [67, 42, 10, 6],
  [38, 41, 9, 6], [48, 41, 8, 5], [57, 43, 9, 6], [78, 32, 12, 7], [78, 40, 12, 6],
  // Downtown / Zamalek
  [30, 44, 8, 5], [30, 50, 8, 5], [39, 47, 8, 5], [39, 53, 8, 5],
  [33, 58, 9, 6], [43, 59, 9, 6], [25, 66, 9, 6], [35, 65, 9, 6],
  // Mohandessin / Dokki
  [10, 36, 9, 6], [10, 43, 9, 6], [19, 52, 8, 5], [10, 50, 8, 6],
  [14, 58, 9, 6], [24, 58, 8, 5],
  // South / Maadi
  [40, 72, 10, 7], [51, 72, 10, 7], [40, 80, 10, 7], [51, 80, 10, 7],
  [45, 88, 11, 7], [57, 88, 10, 7], [62, 72, 10, 7], [62, 80, 10, 7],
  // Far corners
  [86, 34, 10, 8], [86, 43, 10, 7], [86, 56, 10, 8], [86, 65, 10, 7],
  [10, 12, 10, 9], [21, 12, 10, 9], [10, 22, 10, 8], [21, 22, 10, 8], [32, 8, 10, 9], [44, 8, 12, 9], [44, 18, 12, 6], [32, 18, 10, 6],
];

const ROADS_H = [12.5, 21.5, 25.5, 32.5, 40, 47, 53.5, 58.5, 64.5, 71, 78.5, 86];
const ROADS_V = [9.5, 19, 29.5, 37.5, 46, 55.5, 65.5, 75.5, 85];

export function CairoMapBase() {
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 w-full h-full">
      {/* base */}
      <rect width="100" height="100" fill="#EFECFA" />
      {/* Nile — stylized band on the west with a curve */}
      <path
        d="M 7,-2 C 9,12 4,22 6,32 C 8,42 3,52 5,62 C 7,74 4,88 7,102 L -4,102 L -4,-2 Z"
        fill="#CFD9F6"
      />
      {/* Zamalek island */}
      <path d="M 8.5,45 C 14,43 20,45 20.5,49 C 21,53 15,56 10,55 C 6.5,54.3 6.5,46.5 8.5,45 Z" fill="#E4E0F8" stroke="#C9D3F3" strokeWidth="0.18" />
      {/* Ismailia canal through Nasr City */}
      <path d="M 30,30 C 42,29.2 58,31.5 74,29.8 C 84,28.8 92,30 101,29.4" fill="none" stroke="#C9D3F3" strokeWidth="1.5" strokeLinecap="round" opacity="0.9" />
      {/* park patches */}
      <rect x="59" y="14.5" width="10" height="6.5" rx="1" fill="#D8EBD3" />
      <rect x="87" y="57" width="8" height="6" rx="1" fill="#D8EBD3" />
      <rect x="41" y="73" width="8" height="5.5" rx="1" fill="#D8EBD3" />
      {/* blocks */}
      {BLOCKS.map(([x, y, w, h], i) => (
        <rect key={i} x={x} y={y} width={w} height={h} rx="0.9" fill="#E6E2F7" stroke="#DBD6F1" strokeWidth="0.12" />
      ))}
      {/* road casing */}
      <g stroke="#D9D4EE" strokeWidth="2.6" strokeLinecap="round" fill="none">
        {ROADS_H.map((y, i) => <path key={`hc${i}`} d={`M -2,${y} H 102`} />)}
        {ROADS_V.map((x, i) => <path key={`vc${i}`} d={`M ${x},-2 V 102`} />)}
      </g>
      {/* diagonal avenues */}
      <g stroke="#D9D4EE" strokeWidth="2.4" fill="none">
        <path d="M -2,68 L 40,26 L 78,-2" />
        <path d="M 55,102 L 84,58 L 102,40" />
      </g>
      {/* road fill */}
      <g stroke="#FFFFFF" strokeWidth="1.7" strokeLinecap="round" fill="none">
        {ROADS_H.map((y, i) => <path key={`h${i}`} d={`M -2,${y} H 102`} />)}
        {ROADS_V.map((x, i) => <path key={`v${i}`} d={`M ${x},-2 V 102`} />)}
      </g>
      <g stroke="#FFFFFF" strokeWidth="1.5" fill="none">
        <path d="M -2,68 L 40,26 L 78,-2" />
        <path d="M 55,102 L 84,58 L 102,40" />
      </g>
      {/* district labels — always Arabic, like the mockup */}
      <g fontSize="3" fill="#8F89B8" fontWeight="600" textAnchor="middle">
        <text x="66" y="10.8">مصر الجديدة</text>
        <text x="52" y="31">مدينة نصر</text>
        <text x="14.8" y="41.6">مدينة نصر</text>
        <text x="37.5" y="62.8">وسط البلد</text>
        <text x="14.5" y="49.4">الزمالك</text>
        <text x="50.5" y="77.8">المعادي</text>
        <text x="18.5" y="55.8">الدقي</text>
        <text x="15" y="26.8">المهندسين</text>
      </g>
      {/* subtle street name */}
      <g fontSize="1.6" fill="#A49FCB" fontWeight="500">
        <text x="44" y="28.9">ترعة الإسماعيلية</text>
        <text x="41.2" y="24.2" transform="rotate(-45 41.2 24.2)">شارع عباس العقاد</text>
      </g>
    </svg>
  );
}

// ─── Pin components ────────────────────────────────────────────────────────
export function WorkerPin({
  name, avatar, color, selected, onClick, index,
}: { name: string; avatar?: string; color?: string; selected?: boolean; onClick: () => void; index: number }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      className="map-pin pin-drop absolute tap"
      style={{
        left: 0, top: 0,
        transform: `translate(-50%, -88%) scale(${selected ? 1.18 : 1})`,
        zIndex: selected ? 30 : 10 + (index % 9),
        animationDelay: `${index * 60}ms`,
      }}
      aria-label={name}
    >
      <div className="relative">
        {/* white teardrop */}
        <svg width="46" height="54" viewBox="0 0 46 54">
          <path
            d="M23 53 C23 53 4 30 4 18.5 C4 8.3 12.3 0.5 23 0.5 C33.7 0.5 42 8.3 42 18.5 C42 30 23 53 23 53 Z"
            fill="#675FFF"
          />
          <circle cx="23" cy="18.5" r="15.5" fill="#FFFFFF" />
        </svg>
        <div className="absolute rounded-full overflow-hidden" style={{ left: 8, top: 3.5, width: 30, height: 30, background: avatar ? "#E4E1FF" : color || "#675FFF" }}>
          {avatar ? (
            <img src={avatar} alt="" className="w-full h-full object-cover" draggable={false} />
          ) : (
            <span className="w-full h-full flex items-center justify-center text-white text-[11px] font-bold">
              {name.slice(0, 1)}
            </span>
          )}
        </div>
        {selected && <span className="absolute -bottom-1 start-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-primary/40 animate-pulseRing" />}
      </div>
    </button>
  );
}

export function StorePin({
  name, logoColor, logoText, selected, onClick, index,
}: { name: string; logoColor: string; logoText: string; selected?: boolean; onClick: () => void; index: number }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      className="map-pin pin-drop absolute tap"
      style={{
        left: 0, top: 0,
        transform: `translate(-50%, -50%) scale(${selected ? 1.15 : 1})`,
        zIndex: selected ? 30 : 10 + (index % 9),
        animationDelay: `${index * 60}ms`,
      }}
      aria-label={name}
    >
      <div
        className="w-11 h-11 rounded-2xl border-[2.5px] border-white flex items-center justify-center text-white text-[13px] font-extrabold shadow-float"
        style={{ background: logoColor }}
      >
        {logoText}
      </div>
    </button>
  );
}

export function UserDot() {
  return (
    <div className="absolute z-20" style={{ left: "52.5%", top: "38.5%", transform: "translate(-50%,-50%)" }}>
      <span className="absolute inset-0 -m-2 rounded-full bg-blue-400/25 animate-ping" />
      <span className="relative block w-[16px] h-[16px] rounded-full bg-[#3B82F6] border-[3px] border-white shadow-float" />
    </div>
  );
}

// ─── Map viewport with pan/zoom ────────────────────────────────────────────
export function MapViewport({
  catalog, selectedId, onSelect, filter, showStores, onStoreSelect,
}: {
  catalog: Catalog;
  selectedId: string | null;
  onSelect: (techId: string | null) => void;
  filter: string | null;
  showStores: boolean;
  onStoreSelect: (storeId: string) => void;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [scale, setScale] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const drag = useRef<{ sx: number; sy: number; px: number; py: number } | null>(null);

  const clampPan = (p: { x: number; y: number }, s: number) => {
    const el = ref.current;
    if (!el) return p;
    const maxX = ((s - 1) * el.clientWidth) / 2;
    const maxY = ((s - 1) * el.clientHeight) / 2;
    return {
      x: Math.max(-maxX, Math.min(maxX, p.x)),
      y: Math.max(-maxY, Math.min(maxY, p.y)),
    };
  };

  const onPointerDown = (e: React.PointerEvent) => {
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    drag.current = { sx: e.clientX, sy: e.clientY, px: pan.x, py: pan.y };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag.current) return;
    const nx = drag.current.px + (e.clientX - drag.current.sx);
    const ny = drag.current.py + (e.clientY - drag.current.sy);
    setPan(clampPan({ x: nx, y: ny }, scale));
  };
  const onPointerUp = () => {
    if (drag.current) {
      drag.current = null;
      onSelect(null);
    }
  };

  const zoom = (dir: 1 | -1) => {
    setScale((s) => {
      const ns = Math.max(1, Math.min(2.4, s + dir * 0.4));
      setPan((p) => clampPan(p, ns));
      return ns;
    });
  };

  const visibleTechs = catalog.technicians.filter(
    (tt) => tt.available && (!filter || filter === "all" || tt.professions.includes(filter as any))
  );

  return (
    <div
      ref={ref}
      className="absolute inset-0 overflow-hidden touch-none"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
    >
      <div
        className="absolute inset-0"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${scale})`,
          transformOrigin: "center center",
          transition: drag.current ? "none" : "transform 0.25s ease-out",
        }}
      >
        <CairoMapBase />
        <UserDot />
        {visibleTechs.map((tech, i) => (
          <div key={tech.userId} className="absolute" style={{ left: `${tech.mapPos.x}%`, top: `${tech.mapPos.y}%` }}>
            <WorkerPin
              name={tech.user?.name || "?"}
              avatar={tech.user?.avatar}
              color={tech.user?.avatarColor}
              selected={selectedId === tech.userId}
              index={i}
              onClick={() => onSelect(tech.userId)}
            />
          </div>
        ))}
        {showStores &&
          catalog.stores.map((store, i) => (
            <div key={store.id} className="absolute" style={{ left: `${store.mapPos.x}%`, top: `${store.mapPos.y}%` }}>
              <StorePin
                name={store.name}
                logoColor={store.logoColor}
                logoText={store.logoText}
                selected={selectedId === store.id}
                index={i}
                onClick={() => onStoreSelect(store.id)}
              />
            </div>
          ))}
      </div>

      {/* zoom controls */}
      <div className="absolute end-4 bottom-40 z-30 flex flex-col gap-2">
        <button onClick={(e) => { e.stopPropagation(); zoom(1); }} className="tap w-10 h-10 rounded-xl bg-white shadow-float border border-line flex items-center justify-center">
          <Plus size={17} className="text-ink" />
        </button>
        <button onClick={(e) => { e.stopPropagation(); zoom(-1); }} className="tap w-10 h-10 rounded-xl bg-white shadow-float border border-line flex items-center justify-center">
          <Minus size={17} className="text-ink" />
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); setScale(1); setPan({ x: 0, y: 0 }); }}
          className="tap w-10 h-10 rounded-xl bg-white shadow-float border border-line flex items-center justify-center"
        >
          <LocateFixed size={16} className="text-primary" />
        </button>
      </div>
    </div>
  );
}

export { SlidersHorizontal };
