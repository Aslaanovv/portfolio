import React, { createContext, useContext, useMemo, useState } from "react";

export interface Route {
  name: string;
  params?: any;
  key?: string;
}

interface NavState {
  stack: Route[];
  push: (name: string, params?: any) => void;
  pop: () => void;
  replace: (name: string, params?: any) => void;
  reset: (routes: Route[]) => void;
  popTo: (name: string) => void;
}

const NavCtx = createContext<NavState | null>(null);
export const useNav = () => {
  const v = useContext(NavCtx);
  if (!v) throw new Error("useNav outside NavigationProvider");
  return v;
};

let keyCounter = 1;

export function NavigationProvider({ children }: { children: React.ReactNode }) {
  const [stack, setStack] = useState<Route[]>([{ name: "splash", key: "k0" }]);

  const value = useMemo<NavState>(
    () => ({
      stack,
      push: (name, params) => setStack((s) => [...s, { name, params, key: `k${keyCounter++}` }]),
      pop: () => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)),
      replace: (name, params) =>
        setStack((s) => [...s.slice(0, -1), { name, params, key: `k${keyCounter++}` }]),
      reset: (routes) => setStack(routes.map((r) => ({ ...r, key: `k${keyCounter++}` }))),
      popTo: (name) =>
        setStack((s) => {
          const idx = s.findIndex((r) => r.name === name);
          return idx >= 0 ? s.slice(0, idx + 1) : s;
        }),
    }),
    [stack]
  );

  return <NavCtx.Provider value={value}>{children}</NavCtx.Provider>;
}
