import React, { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Wrench, Zap, Hammer, Wind, PaintRoller, WashingMachine, Lightbulb, Activity,
  GitBranch, Cable, Layers, Scissors, Plug, Bell, Star, ChevronLeft, Store as StoreIcon,
  Search, Inbox, X, Loader2,
} from "lucide-react";
import { useApp } from "./AppContext";
import { useNav } from "./navigation";

// ─── Icon registry (design-system icon set) ────────────────────────────────
const ICONS: Record<string, any> = {
  wrench: Wrench, zap: Zap, hammer: Hammer, wind: Wind, "paint-roller": PaintRoller,
  "washing-machine": WashingMachine, lightbulb: Lightbulb, activity: Activity,
  "git-branch": GitBranch, cable: Cable, layers: Layers, scissors: Scissors,
  plug: Plug, bell: Bell, store: StoreIcon,
};
export const IconByName = ({ name, ...props }: { name?: string } & any) => {
  const Cmp = ICONS[name || ""] || Wrench;
  return <Cmp {...props} />;
};

// ─── Avatar ────────────────────────────────────────────────────────────────
export function Avatar({
  name, src, color = "#675FFF", size = 44, ring = false,
}: { name: string; src?: string; color?: string; size?: number; ring?: boolean }) {
  const initials = name?.trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
  return (
    <div
      className={`relative shrink-0 rounded-full overflow-hidden flex items-center justify-center text-white font-semibold ${ring ? "ring-2 ring-white shadow-md" : ""}`}
      style={{ width: size, height: size, background: src ? "#E4E1FF" : color, fontSize: size * 0.36 }}
    >
      {src ? (
        <img src={src} alt={name} className="w-full h-full object-cover" loading="lazy" />
      ) : (
        <span>{initials}</span>
      )}
    </div>
  );
}

// ─── Stars ─────────────────────────────────────────────────────────────────
export function Stars({ value, size = 12, showValue = true, count }: { value: number; size?: number; showValue?: boolean; count?: number }) {
  return (
    <span className="inline-flex items-center gap-1">
      <Star size={size} className="fill-amber-400 text-amber-400" />
      {showValue && (
        <span className="font-semibold text-ink" style={{ fontSize: size + 2 }}>
          {value.toFixed(1)}
          {count !== undefined && <span className="text-muted font-normal"> ({count})</span>}
        </span>
      )}
    </span>
  );
}

// ─── Button ────────────────────────────────────────────────────────────────
export function Btn({
  children, variant = "primary", size = "md", loading, icon: Icon, disabled, className = "", ...props
}: any) {
  const base = "tap inline-flex items-center justify-center gap-2 font-semibold rounded-pill transition-all select-none";
  const sizes = { sm: "h-9 px-4 text-sub2", md: "h-11 px-5 text-sub1", lg: "h-[52px] px-6 text-sub1" };
  const variants: Record<string, string> = {
    primary: "bg-primary text-white shadow-pin hover:bg-primary-dark active:scale-[0.98]",
    secondary: "bg-white text-primary border-[1.5px] border-primary hover:bg-primary-lighter/40 active:scale-[0.98]",
    ghost: "bg-primary-lighter/60 text-primary hover:bg-primary-lighter active:scale-[0.98]",
    danger: "bg-coral/15 text-[#d05c5c] border border-coral/40 hover:bg-coral/25 active:scale-[0.98]",
    dark: "bg-ink text-white hover:bg-night active:scale-[0.98]",
  };
  return (
    <button
      className={`${base} ${sizes[size as "sm"]} ${variants[variant as "primary"]} ${disabled || loading ? "opacity-50 pointer-events-none" : ""} ${className}`}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? <Loader2 size={18} className="animate-spin" /> : Icon ? <Icon size={18} /> : null}
      {children}
    </button>
  );
}

// ─── Chip ──────────────────────────────────────────────────────────────────
export function Chip({ active, icon: Icon, children, ...props }: any) {
  return (
    <button
      className={`tap shrink-0 inline-flex items-center gap-1.5 h-9 px-3.5 rounded-pill text-sub2 font-medium border transition-all ${
        active
          ? "bg-primary text-white border-primary shadow-pin"
          : "bg-white text-ink border-line hover:border-primary/40"
      }`}
      {...props}
    >
      {Icon && <Icon size={14} />}
      {children}
    </button>
  );
}

// ─── Header (stack screens) ────────────────────────────────────────────────
export function Header({ title, right, transparent }: { title?: React.ReactNode; right?: React.ReactNode; transparent?: boolean }) {
  const { pop } = useNav();
  return (
    <div className={`sticky top-0 z-30 flex items-center gap-2 px-4 h-14 ${transparent ? "" : "bg-paper/90 backdrop-blur border-b border-line"}`}>
      <button onClick={pop} className="tap w-9 h-9 rounded-full bg-white border border-line flex items-center justify-center shadow-sm">
        <ChevronLeft size={18} className="text-ink flip-rtl" />
      </button>
      <div className="flex-1 min-w-0 font-semibold text-h3 text-ink truncate">{title}</div>
      {right}
    </div>
  );
}

// ─── Section title ─────────────────────────────────────────────────────────
export function SectionTitle({ children, action, onAction }: { children: React.ReactNode; action?: string; onAction?: () => void }) {
  const { t } = useApp();
  return (
    <div className="flex items-center justify-between mb-3">
      <h3 className="font-bold text-h3 text-ink">{children}</h3>
      {action && (
        <button onClick={onAction} className="tap text-primary text-caption font-semibold uppercase tracking-wide">
          {action || t("common.viewAll")}
        </button>
      )}
    </div>
  );
}

// ─── Money ─────────────────────────────────────────────────────────────────
export function Money({ amount, className = "" }: { amount: number; className?: string }) {
  const { t, lang } = useApp();
  const num = amount.toLocaleString("en-US");
  return (
    <span className={className}>
      {lang === "ar" ? `${num} ${t("common.egp")}` : `${t("common.egp")} ${num}`}
    </span>
  );
}

// ─── Status pill ───────────────────────────────────────────────────────────
const STATUS_STYLES: Record<string, string> = {
  pending: "bg-peach/20 text-[#b06a2a]",
  accepted: "bg-primary-lighter text-primary",
  declined: "bg-coral/15 text-[#c05555]",
  enroute: "bg-primary/15 text-primary-dark",
  inprogress: "bg-primary-deep/10 text-primary-deep",
  completed: "bg-emerald-50 text-emerald-600",
  cancelled: "bg-coral/10 text-[#c05555]",
};
export function StatusPill({ status }: { status: string }) {
  const { t } = useApp();
  return (
    <span className={`inline-flex items-center px-2.5 h-6 rounded-pill text-caption font-semibold ${STATUS_STYLES[status] || "bg-muted/10 text-muted"}`}>
      {t(`status.${status}`)}
    </span>
  );
}

// ─── Bottom sheet ──────────────────────────────────────────────────────────
export function Sheet({ open, onClose, children, title }: { open: boolean; onClose: () => void; children: React.ReactNode; title?: string }) {
  useEffect(() => {
    if (open) {
      const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
      window.addEventListener("keydown", onKey);
      return () => window.removeEventListener("keydown", onKey);
    }
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-ink/40 z-40"
          />
          <motion.div
            initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 350 }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.6 }}
            onDragEnd={(_, info) => info.offset.y > 90 && onClose()}
            className="absolute inset-x-0 bottom-0 z-50 bg-white rounded-t-3xl max-h-[78%] flex flex-col"
          >
            <div className="pt-3 pb-1 flex justify-center shrink-0 cursor-grab active:cursor-grabbing">
              <div className="w-10 h-1.5 rounded-full bg-line" />
            </div>
            {title && <div className="px-5 pb-2 font-bold text-h3 text-ink shrink-0">{title}</div>}
            <div className="overflow-y-auto no-scrollbar px-5 pb-8">{children}</div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ─── Empty state ───────────────────────────────────────────────────────────
export function EmptyState({ icon: Icon = Inbox, title, body, actionLabel, onAction }: any) {
  return (
    <div className="flex flex-col items-center text-center py-16 px-8">
      <div className="w-16 h-16 rounded-3xl bg-primary-lighter/60 flex items-center justify-center mb-4">
        <Icon size={26} className="text-primary" />
      </div>
      <p className="font-bold text-h3 text-ink mb-1">{title}</p>
      {body && <p className="text-sub2 text-muted mb-5 max-w-[240px]">{body}</p>}
      {actionLabel && <Btn onClick={onAction}>{actionLabel}</Btn>}
    </div>
  );
}

// ─── Input field ───────────────────────────────────────────────────────────
export function Field({
  label, error, icon: Icon, ...props
}: { label?: string; error?: string; icon?: any } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      {label && <span className="block text-caption font-semibold uppercase tracking-wide text-muted mb-1.5">{label}</span>}
      <span className="relative block">
        {Icon && <Icon size={16} className="absolute start-3.5 top-1/2 -translate-y-1/2 text-muted" />}
        <input
          className={`w-full h-12 rounded-card border-[1.5px] border-line bg-white px-4 ${Icon ? "ps-10" : ""} text-body1 text-ink placeholder:text-muted/60 outline-none focus:border-primary transition-colors ${error ? "border-coral" : ""}`}
          {...props}
        />
      </span>
      {error && <span className="block text-caption text-[#c05555] mt-1">{error}</span>}
    </label>
  );
}

// ─── Toggle ────────────────────────────────────────────────────────────────
export function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`tap relative w-[46px] h-[27px] rounded-pill transition-colors ${checked ? "bg-primary" : "bg-line"}`}
    >
      <motion.span
        animate={{ x: checked ? 19 : 0 }}
        transition={{ type: "spring", stiffness: 500, damping: 32 }}
        className={`absolute top-[3px] start-[3px] w-[21px] h-[21px] rounded-full bg-white shadow ${checked ? "" : "rtl-start"}`}
      />
    </button>
  );
}

// ─── Search bar ────────────────────────────────────────────────────────────
export function SearchBar({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  return (
    <div className="relative">
      <Search size={17} className="absolute start-4 top-1/2 -translate-y-1/2 text-muted" />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full h-11 rounded-pill bg-white border border-line ps-11 pe-10 text-sub1 text-ink placeholder:text-muted/70 outline-none focus:border-primary shadow-card"
      />
      {value && (
        <button onClick={() => onChange("")} className="tap absolute end-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-line flex items-center justify-center">
          <X size={12} className="text-muted" />
        </button>
      )}
    </div>
  );
}

// ─── Rating stars input ────────────────────────────────────────────────────
export function StarInput({ value, onChange, size = 34 }: { value: number; onChange: (v: number) => void; size?: number }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex justify-center gap-2" onMouseLeave={() => setHover(0)}>
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          onMouseEnter={() => setHover(n)}
          onClick={() => onChange(n)}
          className="tap"
        >
          <Star
            size={size}
            className={`transition-all ${n <= (hover || value) ? "fill-amber-400 text-amber-400 scale-110" : "text-line"}`}
          />
        </button>
      ))}
    </div>
  );
}

// ─── Skeleton card ─────────────────────────────────────────────────────────
export function SkeletonCard({ h = 90 }: { h?: number }) {
  return <div className="skeleton rounded-card" style={{ height: h }} />;
}

// ─── Format helpers ────────────────────────────────────────────────────────
export function fmtTime(ts: number, lang: string) {
  return new Date(ts).toLocaleTimeString(lang === "ar" ? "ar-EG" : "en-GB", { hour: "2-digit", minute: "2-digit" });
}
export function fmtDate(ts: number, lang: string) {
  return new Date(ts).toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { weekday: "short", day: "numeric", month: "short" });
}
export function fmtDateTime(ts: number, lang: string) {
  return `${fmtDate(ts, lang)} · ${fmtTime(ts, lang)}`;
}

// ─── Auto-scroll ref helper ────────────────────────────────────────────────
export function useAutoScroll<T extends HTMLElement>(dep: any) {
  const ref = useRef<T | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [dep]);
  return ref;
}
