import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { api, getToken, setToken } from "./api";
import { translate, type Lang } from "./i18n";
import type { Catalog, PublicUser, TechnicianProfile, CartItem } from "./types";

interface Toast {
  id: number;
  text: string;
  kind: "success" | "error" | "info";
}

interface AppState {
  me: PublicUser | null;
  tech: TechnicianProfile | null;
  lang: Lang;
  dir: "ltr" | "rtl";
  t: (key: string, vars?: Record<string, string | number>) => string;
  catalog: Catalog | null;
  reloadCatalog: () => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  demoLogin: (role: "homeowner" | "technician") => Promise<void>;
  logout: () => void;
  refreshMe: () => Promise<void>;
  setLang: (l: Lang) => void;
  toast: (text: string, kind?: Toast["kind"]) => void;
  toasts: Toast[];
  cart: CartItem[];
  setCart: React.Dispatch<React.SetStateAction<CartItem[]>>;
}

export interface RegisterData {
  name: string;
  phone?: string;
  email: string;
  password: string;
  role: "homeowner" | "technician";
}

const Ctx = createContext<AppState | null>(null);
export const useApp = () => {
  const v = useContext(Ctx);
  if (!v) throw new Error("useApp outside provider");
  return v;
};

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [me, setMe] = useState<PublicUser | null>(null);
  const [tech, setTech] = useState<TechnicianProfile | null>(null);
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [lang, setLangState] = useState<Lang>(() => (localStorage.getItem("malmoum_lang") as Lang) || "en");
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("malmoum_cart") || "[]");
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("malmoum_cart", JSON.stringify(cart));
  }, [cart]);

  const dir = lang === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
    localStorage.setItem("malmoum_lang", lang);
  }, [lang, dir]);

  const t = useCallback(
    (key: string, vars?: Record<string, string | number>) => translate(lang, key, vars),
    [lang]
  );

  const toast = useCallback((text: string, kind: Toast["kind"] = "info") => {
    const id = Date.now() + Math.random();
    setToasts((ts) => [...ts, { id, text, kind }]);
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== id)), 2600);
  }, []);

  const reloadCatalog = useCallback(async () => {
    const data = await api.get<Catalog>("/api/catalog");
    setCatalog(data);
  }, []);

  const refreshMe = useCallback(async () => {
    if (!getToken()) return;
    try {
      const data = await api.get("/api/me");
      setMe(data.user);
      setTech(data.technician);
      if (data.user?.language && data.user.language !== localStorage.getItem("malmoum_lang")) {
        setLangState(data.user.language);
      }
    } catch {
      setToken(null);
      setMe(null);
      setTech(null);
    }
  }, []);

  useEffect(() => {
    reloadCatalog().catch(() => {});
    if (getToken()) refreshMe();
  }, [reloadCatalog, refreshMe]);

  const applySession = useCallback((data: { token: string; user: PublicUser }) => {
    setToken(data.token);
    setMe(data.user);
    setLangState(data.user.language || "en");
  }, []);

  const login = useCallback(
    async (email: string, password: string) => {
      const data = await api.post("/api/auth/login", { email, password });
      applySession(data);
      await refreshMe();
    },
    [applySession, refreshMe]
  );

  const register = useCallback(
    async (data: RegisterData) => {
      const res = await api.post("/api/auth/register", { ...data, language: lang });
      applySession(res);
      await refreshMe();
      await reloadCatalog();
    },
    [applySession, refreshMe, reloadCatalog, lang]
  );

  const demoLogin = useCallback(
    async (role: "homeowner" | "technician") => {
      const data = await api.post("/api/auth/demo", { role });
      applySession(data);
      await refreshMe();
    },
    [applySession, refreshMe]
  );

  const logout = useCallback(() => {
    setToken(null);
    setMe(null);
    setTech(null);
    setCart([]);
  }, []);

  const setLang = useCallback(
    (l: Lang) => {
      setLangState(l);
      if (getToken()) api.patch("/api/me", { language: l }).catch(() => {});
    },
    []
  );

  const value = useMemo<AppState>(
    () => ({
      me, tech, lang, dir, t, catalog, reloadCatalog,
      login, register, demoLogin, logout, refreshMe, setLang, toast, toasts, cart, setCart,
    }),
    [me, tech, lang, dir, t, catalog, reloadCatalog, login, register, demoLogin, logout, refreshMe, setLang, toast, toasts, cart]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
